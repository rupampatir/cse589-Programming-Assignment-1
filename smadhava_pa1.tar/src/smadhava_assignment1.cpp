/**
 * @smadhava_assignment1
 * @author  Sai Kiran Madhavaram <smadhava@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <typeinfo>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <set>
#include <bits/stdc++.h>

#define STDIN 0
#define TRUE 1
#define SIZE_CMD 100
#define SIZE_BUFFER 256
#define GOOGLE_DNS "8.8.8.8"
#define UBITNAME "smadhava"
#define BROADCAST_IP "255.255.255.255"

#include "../include/global.h"
#include "../include/logger.h"

int connectSocket(char *server_ip_address, char *server_port_no);
void refreshClientList(std::vector<struct ClientNode> *clientsList, char *list);
bool checkIPInList(char *ip_address, std::vector<struct ClientNode> *clientsList);
int loginClient(char *cmd, char *port_no, std::vector<struct ClientNode> *clientsList, fd_set *masterList);
int clientAccept(int serverSkt);
void splitListToVector(std::string const &str, const char delim, std::vector<std::string> &out);
void printIPAddress();
int createClient(int serverSkt, std::vector<struct ClientNode> *clientsList);
void serverList(int acceptorFD, std::vector<struct ClientNode> *clientsList, char *list);
void sendingFromServer(int sockIdx, char *cmd, std::vector<struct ClientNode> *clientsList);
void broadcastFromServer(int sockIdx, char *cmd, std::vector<struct ClientNode> *clientsList);
void removeClient(int sockIdx, std::vector<struct ClientNode> *clientsList);
int validateAndConvertPort(char *portNo);
void unblockClient(int sockIdx, char *buffer, std::vector<struct ClientNode> *clientsList);
void showBlockedList(std::vector<struct ClientNode> *clientsList, char *buffer);
bool IPValidation(char *ipaddress);
void blockClient(int sockIdx, char *buffer, std::vector<struct ClientNode> *clientsList);
int sendMessage(int s, char *buf);
char *tokenizeCommand(char **cmd, int commandLength);

using namespace std;
unordered_map<string, vector<string>> messageBuffer;

struct ClientNode
{
	int isLoggedIn;
	int portno;
	int numOfMsgsSent;
	int numOfMsgsRecvd;
	int acceptorFD;
	int fdWithServer;
	char IP[INET_ADDRSTRLEN];
	char hostName[128];
	vector<string> blockedIPS;
};

char *tokenizeCommand(char **cmd, int commandLength)
{
	char *cmdRef = *cmd;
	char *actingCmnd = (char *)malloc(sizeof(char) * SIZE_CMD);
	memset(actingCmnd, '\0', SIZE_CMD);
	char *temp = (char *)malloc(sizeof(char) * SIZE_CMD);
	for (int i = 0; i < commandLength; i++)
	{
		if (cmdRef[i] == ' ' || cmdRef[i] == '\0')
		{
			temp = cmdRef + i + 1;
			cmdRef = temp;
			actingCmnd[i] = '\0';
			break;
		}
		else
		{
			actingCmnd[i] = cmdRef[i];
		}
	}
	*cmd = cmdRef;
	return actingCmnd;
}

void displayList(char *actionCmnd, std::vector<struct ClientNode> *clientsList)
{
	vector<struct ClientNode>::iterator i = clientsList->begin();
	int serialNo = 0;
	cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
	while (i != clientsList->end())
	{
		if (i->isLoggedIn == 1)
		{
			cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", ++serialNo, i->hostName, i->IP, i->portno);
		}
		i++;
	}
	cse4589_print_and_log("[%s:END]\n", actionCmnd);
}
int connectSocket(char *server_ip_address, char *server_port_no)
{
	struct addrinfo hints, *result;
	int socketFD;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if (getaddrinfo(server_ip_address, server_port_no, &hints, &result) != 0)
		perror("Error at getting address info");

	if ((socketFD = socket(result->ai_family, result->ai_socktype, result->ai_protocol)) < 0)
		perror("Socket creation failed");

	if (connect(socketFD, result->ai_addr, result->ai_addrlen) < 0)
	{
		perror("Connect failed");
		return 0;
	}
	freeaddrinfo(result);
	return socketFD;
}

void splitListToVector(std::string const &str, const char delim,
					   std::vector<std::string> &out)
{
	size_t start;
	size_t end = 0;
	while ((start = str.find_first_not_of(delim, end)) != std::string::npos)
	{
		end = str.find(delim, start);
		out.push_back(str.substr(start, end - start));
	}
}

void refreshClientList(std::vector<struct ClientNode> *clientsList, char *list)
{
	clientsList->clear();
	vector<string> resultList;
	const char delim = ',';
	splitListToVector(list, delim, resultList);
	for (int i = 0; i < resultList.size(); i++)
	{
		struct ClientNode *newClient = new ClientNode;
		memset(&newClient->IP, '\0', INET_ADDRSTRLEN);
		memset(&newClient->hostName, '\0', 128);
		newClient->portno = stoi(resultList[i]);
		int j = 0;
		i++;
		while (resultList[i][j] != '\0')
		{
			newClient->IP[j] = resultList[i][j];
			j++;
		}
		i++;
		int k = 0;
		while (resultList[i][k] != '\0')
		{
			newClient->hostName[k] = resultList[i][k];
			k++;
		}
		newClient->isLoggedIn = 1;
		clientsList->push_back(*newClient);
	}
}

bool checkIPInList(char *ip_address, std::vector<struct ClientNode> *clientsList, int socketFD)
{
	if (socketFD != -1)
	{
		char *list = (char *)malloc(sizeof(char) * SIZE_BUFFER);
		memset(list, '\0', SIZE_BUFFER);
		int refresh_sent = send(socketFD, "REFRESH", strlen("REFRESH"), 0);
		if (refresh_sent == -1)
			perror("failed to send refresh");
		if (int recv_bytes = recv(socketFD, list, SIZE_BUFFER - 1, 0) != 0)
			refreshClientList(clientsList, list);
	}
	vector<struct ClientNode>::iterator i;
	for (i = clientsList->begin(); i != clientsList->end(); i++)
	{
		if (strcmp(i->IP, ip_address) == 0)
		{
			return true;
		}
	}
	return false;
}

int loginClient(char *cmd, char *port_no, std::vector<struct ClientNode> *clientsList, fd_set *masterList)
{
	int commandLength = strlen(cmd);
	char *serverIP = tokenizeCommand(&cmd, commandLength);
	commandLength = strlen(cmd);
	char *serverPort = tokenizeCommand(&cmd, commandLength);
	if ((IPValidation(serverIP) == false) || validateAndConvertPort(serverPort) == -1)
		return -1;
	int socketFD = connectSocket(serverIP, serverPort);
	if (socketFD != 0)
	{
		send(socketFD, port_no, 6, 0);
		char *list = (char *)malloc(sizeof(char) * SIZE_BUFFER);
		memset(list, '\0', SIZE_BUFFER);
		if (recv(socketFD, list, SIZE_BUFFER - 1, 0) != 0)
		{
			refreshClientList(clientsList, list);
		}
	}
	return socketFD;
}

int clientAccept(int serverSkt)
{
	struct sockaddr_in client_addr;
	int len_client_addr = sizeof(client_addr);
	int acceptorFD = accept(serverSkt, (struct sockaddr *)&client_addr, (socklen_t *)&len_client_addr);
	if (acceptorFD < 0)
		perror("Accept failed.");
	return acceptorFD;
}

void removeClient(int sockIdx, std::vector<struct ClientNode> *clientsList)
{
	vector<struct ClientNode>::iterator itr1;
	for (itr1 = clientsList->begin(); itr1 != clientsList->end(); itr1++)
	{
		if (sockIdx == itr1->acceptorFD)
		{
			clientsList->erase(itr1);
			break;
		}
	}
}

int validateAndConvertPort(char *portNo)
{
	int i = 0;
	while (portNo[i] != '\0')
	{
		if (portNo[i] > '9' || portNo[i] < '0')
			return -1;
		i++;
	}
	return stoi(portNo);
}

int sendMessage(int s, char *buf)
{
	int sent_total = 0;
	int n;
	int remaining_bytes = strlen(buf);
	while (sent_total < remaining_bytes)
	{
		n = send(s, buf + sent_total, remaining_bytes, 0);
		if (n == -1)
		{
			break;
		}
		sent_total += n;
		remaining_bytes -= n;
	}

	return n == -1 ? -1 : 0;
}

bool IPValidation(char *ipaddress)
{
	return inet_pton(AF_INET, ipaddress, (char *)malloc(INET_ADDRSTRLEN));
}

bool portComparator(struct ClientNode list1, struct ClientNode list2)
{
	return (list1.portno < list2.portno);
}

void serverList(int acceptorFD, vector<struct ClientNode> *clientsList, char *list)
{
	vector<struct ClientNode>::iterator clItr;
	char portno[5];

	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		char temp[100];
		sprintf(temp, "%d,%s,%s,", clItr->portno, clItr->IP, clItr->hostName);
		strcat(list, temp);
	}
	sendMessage(acceptorFD, list);
}

void printIPAddress()
{
	char ip_addr[INET_ADDRSTRLEN];
	char commandString[3] = "IP";
	struct sockaddr_in udp;
	int udp_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	int len = sizeof(udp);
	int error = 0;

	if (udp_socket == -1)
	{
		perror("Socket creation failed!\n");
	}

	memset((char *)&udp, 0, sizeof(udp));
	udp.sin_family = AF_INET;
	udp.sin_port = htons(53);
	inet_pton(AF_INET, GOOGLE_DNS, &udp.sin_addr);

	if (connect(udp_socket, (struct sockaddr *)&udp, sizeof(udp)) < 0)
	{
		perror("Connection Failed!\n");
		error = 1;
	}
	if (getsockname(udp_socket, (struct sockaddr *)&udp, (unsigned int *)&len) == -1)
	{
		perror("Command to getsockname Failed!");
		error = 1;
	}

	inet_ntop(AF_INET, &(udp.sin_addr), ip_addr, len);

	if (error == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", commandString);
		cse4589_print_and_log("IP:%s\n", ip_addr);
		cse4589_print_and_log("[%s:END]\n", commandString);
	}

	else
	{
		cse4589_print_and_log("[%s:ERROR]\n", commandString);
		cse4589_print_and_log("[%s:END]\n", commandString);
	}
}

int createClient(int serverSkt, vector<struct ClientNode> *clientsList)
{

	struct sockaddr_in c_addr;
	int len_c_addr = sizeof(c_addr);
	char *refreshedList = (char *)malloc(SIZE_BUFFER);
	memset(refreshedList, '\0', SIZE_BUFFER);
	char portNo[6] = {'\0'};
	int acceptorFd = accept(serverSkt, (struct sockaddr *)&c_addr, (socklen_t *)&len_c_addr);
	if (acceptorFd < 0)
		perror("Accept failed.");
	recv(acceptorFd, &portNo, 6, 0);
	struct sockaddr_in *ipv4 = (struct sockaddr_in *)&c_addr;
	char serverIP[INET_ADDRSTRLEN];
	char hostname[NI_MAXHOST];
	char *ipv4Address;
	socklen_t len_sockaddr_in = sizeof(&ipv4);
	inet_ntop(AF_INET, &ipv4Address, serverIP, sizeof(serverIP));
	ipv4Address = inet_ntoa(c_addr.sin_addr);

	getnameinfo((struct sockaddr *)&c_addr, len_c_addr, hostname, (socklen_t)sizeof(hostname), NULL, 0, NI_NAMEREQD);
	struct ClientNode *newClient = new ClientNode;
	strcpy(newClient->IP, ipv4Address);
	strcpy(newClient->hostName, hostname);
	newClient->portno = stoi(portNo);
	newClient->acceptorFD = acceptorFd;
	newClient->isLoggedIn = 1;
	newClient->fdWithServer = -1;
	newClient->numOfMsgsSent = 0;
	newClient->numOfMsgsRecvd = 0;
	clientsList->push_back(*newClient);
	messageBuffer.insert(pair<string, vector<string>>(newClient->IP, {}));
	sort(clientsList->begin(), clientsList->end(), portComparator);
	serverList(acceptorFd, clientsList, refreshedList);
	return acceptorFd;
}

void sendingFromServer(int sockIdx, char *cmd, std::vector<struct ClientNode> *clientsList)
{
	vector<struct ClientNode>::iterator clItr;
	char sourceIP[INET_ADDRSTRLEN];

	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		if (sockIdx == clItr->acceptorFD)
			strcpy(sourceIP, clItr->IP);
	}
	int commandLength = strlen(cmd);
	char *actionCmnd = tokenizeCommand(&cmd, commandLength);
	char *buffer_send = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
	memset(buffer_send, '\0', SIZE_BUFFER * 2);
	strcat(buffer_send, sourceIP);
	strcat(buffer_send, " ");
	strcat(buffer_send, cmd);
	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		if ((strcmp(((const char *)(clItr->IP)), ((const char *)(actionCmnd)))) == 0)
		{
			for (auto i : clItr->blockedIPS)
			{
				if (strcmp(i.c_str(), sourceIP) == 0)
				{
					return;
				}
			}
			if (clItr->fdWithServer == -1)
			{
				char server_port_no[6];
				sprintf(server_port_no, "%d", clItr->portno);
				clItr->fdWithServer = connectSocket(clItr->IP, server_port_no);
			}
			if (clItr->isLoggedIn == 1)
			{
				sendMessage(clItr->fdWithServer, buffer_send);
				cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
				cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sourceIP, actionCmnd, cmd);
				cse4589_print_and_log("[%s:END]\n", "RELAYED");
				clItr->numOfMsgsRecvd++;
				break;
			}
		}
	}
}

void broadcastFromServer(int sockIdx, char *cmd, std::vector<struct ClientNode> *clientsList)
{
	char *buffer_send = (char *)malloc(sizeof(char) * SIZE_BUFFER);
	memset(buffer_send, '\0', SIZE_BUFFER * 2);
	char sourceIP[INET_ADDRSTRLEN];
	vector<struct ClientNode>::iterator clItr;
	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		if (clItr->acceptorFD == sockIdx)
			strcpy(sourceIP, clItr->IP);
	}
	strcpy(buffer_send, sourceIP);
	strcat(buffer_send, " ");
	strcat(buffer_send, cmd);
	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		if ((strcmp(((const char *)(clItr->IP)), ((const char *)(sourceIP)))) != 0)
		{
			if (clItr->fdWithServer == -1)
			{
				char server_port_no[6];
				sprintf(server_port_no, "%d", clItr->portno);
				clItr->fdWithServer = connectSocket(clItr->IP, server_port_no);
			}
			if (clItr->isLoggedIn == 1)
			{
				sendMessage(clItr->fdWithServer, buffer_send);
				cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
				cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sourceIP, BROADCAST_IP, cmd);
				cse4589_print_and_log("[%s:END]\n", "RELAYED");
				clItr->numOfMsgsRecvd++;
			}
			else if (clItr->isLoggedIn == 2)
			{
				unordered_map<string, vector<string>>::iterator messageBufferItr;
				for (messageBufferItr = messageBuffer.begin(); messageBufferItr != messageBuffer.end(); messageBufferItr++)
				{
					if (strcmp(messageBufferItr->first.c_str(), clItr->IP) == 0)
					{
						messageBufferItr->second.push_back(cmd);
					}
				}
			}
		}
	}
}

void unblockClient(int sockIdx, char *buffer, std::vector<struct ClientNode> *clientsList)
{
	vector<struct ClientNode>::iterator clItr;
	for (clItr = clientsList->begin(); clItr != clientsList->end(); clItr++)
	{
		if (clItr->acceptorFD == sockIdx)
		{
			int j = 0;
			for (auto i : clItr->blockedIPS)
			{
				if (strcmp(i.c_str(), buffer) == 0)
				{
					clItr->blockedIPS.erase(clItr->blockedIPS.begin() + j);
					return;
				}
				j++;
			}
		}
	}
}

void printBlockedList(std::vector<string> blockedIPS, std::vector<struct ClientNode> *clientsList)
{
	vector<struct ClientNode>::iterator itr;
	int count = 1;
	for (auto i : blockedIPS)
	{
		for (itr = clientsList->begin(); itr != clientsList->end(); itr++)
		{
			if (strcmp(itr->IP, i.c_str()) == 0)
			{
				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", count++, itr->hostName, itr->IP, itr->portno);
			}
		}
	}
}

void showBlockedList(std::vector<struct ClientNode> *clientsList, char *buffer)
{
	vector<struct ClientNode>::iterator tempItr;
	cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCKED");
	for (tempItr = clientsList->begin(); tempItr != clientsList->end(); tempItr++)
	{
		if (strcmp(tempItr->IP, buffer) == 0)
		{
			printBlockedList(tempItr->blockedIPS, clientsList);
			break;
		}
	}
	cse4589_print_and_log("[%s:END]\n", "BLOCKED");
}

void blockClient(int sockIdx, char *buffer, std::vector<struct ClientNode> *clientsList)
{
	int commandLength = strlen(buffer);
	char *newip = tokenizeCommand(&buffer, commandLength);
	vector<struct ClientNode>::iterator clItr = clientsList->begin();
	;
	while (clItr != clientsList->end())
	{
		if (clItr->acceptorFD == sockIdx)
		{
			bool ipExists = false;
			for (auto i : clItr->blockedIPS)
			{
				if (strcmp(i.c_str(), newip) == 0)
				{
					ipExists = true;
					break;
				}
			}
			if (!ipExists)
				clItr->blockedIPS.push_back(newip);
		}
		clItr++;
	}
}

void getIPFromClientCommand(char *actionCmnd, char *ip)
{
	int len_cmnd = strlen(actionCmnd);
	for (int i = 0; i < len_cmnd; i++)
	{
		if (actionCmnd[i] == ' ')
		{
			ip[i] = '\0';
			break;
		}
		else
		{
			ip[i] = actionCmnd[i];
		}
	}
}

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0
 */
int main(int argc, char *argv[])
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	if (argc != 3)
	{
		exit(-1);
	}
	int headSkt, serverSkt, selret, sockIdx, acceptorFD = 0;
	char *port = argv[2];
	struct addrinfo hints, *res;
	fd_set masterList, watchList;
	vector<struct ClientNode> clientsList;
	vector<struct ClientNode>::iterator clItr;
	vector<string> myblocklist;
	bool isLoggedIn = false;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	int yes = 1;

	if (validateAndConvertPort(argv[2]) != -1)
	{
		if (getaddrinfo(NULL, argv[2], &hints, &res) != 0)
			perror("getaddrinfo failed");

		/* Socket */
		serverSkt = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
		if (serverSkt < 0)
			perror("Cannot create socket");
		setsockopt(serverSkt, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
		/* Bind */
		if (bind(serverSkt, res->ai_addr, res->ai_addrlen) < 0)
			perror("Bind failed");

		freeaddrinfo(res);
		/* Listen */
		if (listen(serverSkt, 100) < 0)
			perror("Unable to listen on port");
	}
	/* ---------------------------------------------------------------------------- */

	/* Zero select FD sets */
	FD_ZERO(&masterList);
	FD_ZERO(&watchList);

	/* Register the listening socket */
	FD_SET(serverSkt, &masterList);
	/* Register STDIN */
	FD_SET(STDIN, &masterList);

	headSkt = serverSkt;

	if (strcmp(argv[1], "s") == 0)
	{
		while (TRUE)
		{
			memcpy(&watchList, &masterList, sizeof(masterList));

			printf("\n[PA1-Server@CSE489/589]$ ");
			fflush(stdout);

			/* select() system call. This will BLOCK */
			selret = select(headSkt + 1, &watchList, NULL, NULL, NULL);
			if (selret < 0)
				perror("select failed.");
			/* Check if we have sockets/STDIN to process */
			if (selret > 0)
			{
				/* Loop through socket descriptors to check which ones are ready */
				for (sockIdx = 0; sockIdx <= headSkt; sockIdx += 1)
				{
					if (FD_ISSET(sockIdx, &watchList))
					{
						/* Check if new actionCmnd on STDIN */
						if (sockIdx == STDIN)
						{
							char *cmd = (char *)malloc(sizeof(char) * SIZE_CMD);
							memset(cmd, '\0', SIZE_CMD);
							if (fgets(cmd, SIZE_CMD - 1, stdin) == NULL) /*Mind the newline character that will be written to cmd*/
								exit(-1);
							int commandLength = strlen(cmd);
							cmd[commandLength - 1] = '\0';
							commandLength--;
							/*Process PA1 commands here ...*/
							char *actionCmnd = tokenizeCommand(&cmd, commandLength);
							if (strcmp(actionCmnd, "AUTHOR") == 0)
							{
								cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
								cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", UBITNAME);
								cse4589_print_and_log("[%s:END]\n", "AUTHOR");
							}
							if (strcmp(actionCmnd, "IP") == 0)
							{
								printIPAddress();
							}
							else if (strcmp(actionCmnd, "PORT") == 0)
							{
								int portNo;
								if ((portNo = validateAndConvertPort(port)) == -1)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
								else
								{
									cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
									cse4589_print_and_log("PORT:%d\n", portNo);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
							}
							else if (strcmp(actionCmnd, "LIST") == 0)
							{
								displayList(actionCmnd, &clientsList);
							}
							else if (strcmp(actionCmnd, "BLOCKED") == 0)
							{
								if (IPValidation(cmd) == false || checkIPInList(cmd, &clientsList, -1) == false)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								showBlockedList(&clientsList, cmd);
							}
							else if (strcmp(actionCmnd, "STATISTICS") == 0)
							{
								vector<struct ClientNode>::iterator clItr;
								int j = 1;
								cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
								for (clItr = clientsList.begin(); clItr != clientsList.end(); clItr++)
								{
									const char *loginstatus = clItr->isLoggedIn ? "logged-in" : "logged-out";
									cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", j++, clItr->hostName, clItr->numOfMsgsSent, clItr->numOfMsgsRecvd, loginstatus);
								}
								cse4589_print_and_log("[%s:END]\n", actionCmnd);
							}
						}

						/* Check if new client is requesting connection */
						else if (sockIdx == serverSkt)
						{
							int acceptorFD = createClient(serverSkt, &clientsList);
							FD_SET(acceptorFD, &masterList);
							if (acceptorFD > headSkt)
								headSkt = acceptorFD;
						}
						/* Read from existing clients */
						else
						{
							/* Initialize buffer to receieve response */
							char *buffer = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
							memset(buffer, '\0', SIZE_BUFFER * 2);
							if (recv(sockIdx, buffer, SIZE_BUFFER * 2, 0) <= 0)
							{
								close(sockIdx);
								printf("Remote Host terminated connection!\n");
								removeClient(sockIdx, &clientsList);
								FD_CLR(sockIdx, &masterList);
							}
							else
							{
								/*Process incoming data from existing clients here ...*/
								for (clItr = clientsList.begin(); clItr != clientsList.end(); clItr++)
								{
									if (clItr->acceptorFD == sockIdx)
									{
										clItr->numOfMsgsSent++;
										break;
									}
								}
								int commandLength = strlen(buffer);
								char *actionCmnd = tokenizeCommand(&buffer, commandLength);
								if (strcmp(actionCmnd, "REFRESH") == 0)
								{
									for (clItr = clientsList.begin(); clItr != clientsList.end(); clItr++)
									{
										if (clItr->acceptorFD == sockIdx)
										{
											clItr->numOfMsgsSent--;
											break;
										}
									}
									char *refreshedList = (char *)malloc(SIZE_BUFFER);
									memset(refreshedList, '\0', SIZE_BUFFER);
									serverList(sockIdx, &clientsList, refreshedList);
								}
								else if (strcmp(actionCmnd, "SEND") == 0)
								{
									sendingFromServer(sockIdx, buffer, &clientsList);
								}
								else if (strcmp(actionCmnd, "LOGIN") == 0)
								{
									for (clItr = clientsList.begin(); clItr != clientsList.end(); clItr++)
									{
										if (clItr->acceptorFD == sockIdx)
										{
											clItr->isLoggedIn = 1;
											clItr->numOfMsgsSent--;
											break;
										}
									}
								}
								else if (strcmp(actionCmnd, "LOGOUT") == 0)
								{
									for (clItr = clientsList.begin(); clItr != clientsList.end(); clItr++)
									{
										if (clItr->acceptorFD == sockIdx)
										{
											clItr->isLoggedIn = 0;
											clItr->numOfMsgsSent--;
											break;
										}
									}
								}
								else if (strcmp(actionCmnd, "BLOCK") == 0)
								{
									blockClient(sockIdx, buffer, &clientsList);
								}
								else if (strcmp(actionCmnd, "UNBLOCK") == 0)
								{
									unblockClient(sockIdx, buffer, &clientsList);
								}
								else if (strcmp(actionCmnd, "BROADCAST") == 0)
								{
									broadcastFromServer(sockIdx, buffer, &clientsList);
								}
							}
						}
					}
				}
			}
		}
	}
	else
	{
		int isLoggedIn = 0;
		while (TRUE)
		{
			memcpy(&watchList, &masterList, sizeof(masterList));
			selret = select(headSkt + 1, &watchList, NULL, NULL, NULL);
			int socketFD;
			if (selret < 0)
				perror("select failed.");
			if (selret > 0)
			{
				/* Loop through socket descriptors to check which ones are ready */
				for (int sockIdx = 0; sockIdx <= headSkt; sockIdx += 1)
				{
					if (FD_ISSET(sockIdx, &watchList))
					{
						/* Check if new actionCmnd on STDIN */
						if (sockIdx == STDIN)
						{
							vector<string> recvd_cmnd;
							char *cmd = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
							splitListToVector(cmd, ' ', recvd_cmnd);
							for (auto i : recvd_cmnd)
								memset(cmd, '\0', SIZE_BUFFER * 2);
							char *originalCommand = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
							memset(originalCommand, '\0', SIZE_BUFFER * 2);
							if (fgets(cmd, SIZE_BUFFER * 2 - 1, stdin) == NULL)
								exit(-1);
							int commandLength = strlen(cmd);
							cmd[commandLength - 1] = '\0';
							commandLength--;
							strcpy(originalCommand, cmd);
							char *actionCmnd = tokenizeCommand(&cmd, commandLength);
							char *iparg = (char *)malloc(INET_ADDRSTRLEN);
							getIPFromClientCommand(cmd, iparg);
							/*Process PA1 commands here ...*/
							if (strcmp(actionCmnd, "IP") == 0)
							{
								printIPAddress();
							}
							else if (strcmp(actionCmnd, "AUTHOR") == 0)
							{
								cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
								cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", UBITNAME);
								cse4589_print_and_log("[%s:END]\n", "AUTHOR");
							}
							else if (strcmp(actionCmnd, "PORT") == 0)
							{
								int portNo;
								if ((portNo = validateAndConvertPort(port)) == -1)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
								else
								{
									cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
									cse4589_print_and_log("PORT:%d\n", portNo);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
							}
							else if (strcmp(actionCmnd, "EXIT") == 0)
							{
								return 0;
							}
							else if (strcmp(actionCmnd, "LIST") == 0)
							{
								if (isLoggedIn)
								{
									displayList(actionCmnd, &clientsList);
								}
								else
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
							}
							else if (strcmp(actionCmnd, "REFRESH") == 0)
							{
								char *list = (char *)malloc(sizeof(char) * SIZE_BUFFER);
								memset(list, '\0', SIZE_BUFFER);
								if (send(socketFD, actionCmnd, strlen(actionCmnd), 0) == -1)
									perror("failed to send refresh");
								if (recv(socketFD, list, SIZE_BUFFER - 1, 0) != 0)
									refreshClientList(&clientsList, list);
							}
							else if (strcmp(actionCmnd, "LOGIN") == 0)
							{
								if (isLoggedIn == 0)
								{
									socketFD = loginClient(cmd, argv[2], &clientsList, &masterList);
								}
								if (isLoggedIn == 2)
								{
									send(socketFD, actionCmnd, strlen(actionCmnd), 0);
									isLoggedIn = 1;
								}
								if (socketFD > headSkt)
								{
									headSkt = socketFD;
								}
								if (socketFD <= 0)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								isLoggedIn = 1;
								cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
								cse4589_print_and_log("[%s:END]\n", actionCmnd);
							}
							else if (strcmp(actionCmnd, "LOGOUT") == 0)
							{
								send(socketFD, originalCommand, commandLength, 0);
								isLoggedIn = 2;
								cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
								cse4589_print_and_log("[%s:END]\n", actionCmnd);
							}
							else if (strcmp(actionCmnd, "SEND") == 0)
							{
								commandLength = strlen(originalCommand);
								if (IPValidation(iparg) == false)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								if (checkIPInList(iparg, &clientsList, socketFD) == false)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								sendMessage(socketFD, originalCommand);
								cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
								cse4589_print_and_log("[%s:END]\n", actionCmnd);
							}
							else if (strcmp(actionCmnd, "BROADCAST") == 0)
							{
								int sentBytes = 0;
								commandLength = strlen(originalCommand);
								sentBytes = send(socketFD, originalCommand, commandLength, 0);
								if (sentBytes < commandLength)
								{
									sentBytes = sentBytes + send(socketFD, originalCommand, commandLength, 0);
									if (sentBytes == -1)
									{
										perror("failed to send broadcast message");
									}
								}
							}
							else if (strcmp(actionCmnd, "BLOCK") == 0)
							{
								int blockedFlag = 0;
								commandLength = strlen(originalCommand);
								for (auto i : myblocklist)
								{
									if (strcmp(i.c_str(), cmd) == 0)
									{
										cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
										cse4589_print_and_log("[%s:END]\n", actionCmnd);
										blockedFlag = 1;
										break;
									}
								}
								if (IPValidation(cmd) == 0 || checkIPInList(cmd, &clientsList, socketFD) == false)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								if (blockedFlag == 0)
								{
									int sentBytes = 0;
									if (sentBytes < commandLength)
									{
										sentBytes += send(socketFD, originalCommand, commandLength, 0);
										if (sentBytes == -1)
										{
											perror("failed to block message");
										}
									}
									cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
								}
								myblocklist.push_back(cmd);
							}
							else if (strcmp(actionCmnd, "UNBLOCK") == 0)
							{
								int sentBytes = 0;
								commandLength = strlen(originalCommand);
								if (IPValidation(cmd) == false || checkIPInList(cmd, &clientsList, socketFD) == false)
								{
									cse4589_print_and_log("[%s:ERROR]\n", actionCmnd);
									cse4589_print_and_log("[%s:END]\n", actionCmnd);
									break;
								}
								if (sentBytes < commandLength)
								{
									sentBytes += send(socketFD, originalCommand, commandLength, 0);
									if (sentBytes == -1)
									{
										perror("failed to unblock");
									}
								}
								cse4589_print_and_log("[%s:SUCCESS]\n", actionCmnd);
								cse4589_print_and_log("[%s:END]\n", actionCmnd);
							}
							else if (strcmp(actionCmnd, "BLOCKED") == 0)
							{
								int sentBytes = 0;
								commandLength = strlen(originalCommand);
								if (sentBytes < commandLength)
								{
									sentBytes += send(socketFD, originalCommand, commandLength, 0);
									if (sentBytes == -1)
									{
										perror("failed to send message");
									}
								}
							}
						}
						else if (sockIdx == serverSkt)
						{
							int acceptorFD = clientAccept(serverSkt);
							if (acceptorFD < 0)
								perror("Accept failed.");
							printf("\nRemote Host connected!\n");
							FD_SET(acceptorFD, &masterList);
							if (acceptorFD > headSkt)
								headSkt = acceptorFD;
							char *buffer = (char *)malloc(SIZE_BUFFER);
						}
						else
						{
							char *buffer = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
							memset(buffer, '\0', SIZE_BUFFER * 2);
							char *message = (char *)malloc(sizeof(char) * SIZE_BUFFER * 2);
							memset(message, '\0', SIZE_BUFFER * 2);
							recv(sockIdx, buffer, SIZE_BUFFER * 2, 0);
							char sourceIP[INET_ADDRSTRLEN];
							for (int i = 0; i < strlen(buffer); i++)
							{
								if (buffer[i] == ' ')
								{
									message = buffer + i + 1;
									break;
								}
								else
								{
									sourceIP[i] = buffer[i];
								}
							}
							cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
							cse4589_print_and_log("msg from:%s\n[msg]:%s\n", sourceIP, message);
							cse4589_print_and_log("[%s:END]\n", "RECEIVED");
						}
					}
				}
			}
		}
	}
	return 0;
}
