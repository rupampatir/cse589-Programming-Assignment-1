#include <string>
#include <vector>

#define TRUE 1
#define FALSE 0
#define MSG_SIZE 256
#define BUFFER_SIZE 256

#define MAX_NODES 5
struct host
{
	std::string hostname;
	std::string ip;
	int port;
	int socket;
	int is_active;
	int rcvd_msgs;
	int sent_msgs;
	std::vector<std::string> blocked_clients;
	std::vector<std::string> blocked_msgs;
};

extern struct host clients[MAX_NODES];

extern std::string blocked_msgs[102];

extern int PORT;
extern char MODE;
extern int client_scock;
extern int login_status;
extern int maxfd;
extern int toggle;


std::string IntToString(int);
int StringtoInt(std::string);
std::vector<std::string> tokenize(std::string s, std::string del = " ");
std::vector<std::string> tokenize2(std::string s, int count, std::string del = " ");
int get_sock(std::string ip);
int get_client(std::string ip);
int loginstat(std::string ip);
void sort_list();
void common_cmd(char* s,int node);
void other_cmd(char* s, int node);
bool validateIP(std::string);
bool active_client(std::string);
std::string mystrop(std::string original_str, std::string replaced, std::string replace_with);
int server_sock();
void update_all();
void upldate1(int socket);
int login(std::string ip, std::string port);
void clientcall(std::string acl_str);
void unblock(std::string ip);
void send_file(std::string ip, std::string filename);
void client_function(int portnum);
std::string fetch_ip(void);
void message_display(std::string s);

void client_msg(const char* buffer);
void track_msg(std::string ip, int type);
bool is_blocked(std::string blking, std::string blkd);
void server(int portnum);
void broadcast(char* buffer);
void updatecport(char* buffer, int i);
void relay(int i);
void block_sock(std::string blking_client, char* buffer);
void unblock_sock(std::string blking_client, char* buffer);