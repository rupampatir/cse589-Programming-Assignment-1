/**
 * @hramadas_assignment1
 * @author  Harshavardan Ramadas <hramadas@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>
#include <vector>
#include <sstream>
#include <algorithm>
#include <sys/ioctl.h>
#include <net/if.h>

#include "../include/global.h"
#include "../include/logger.h"
#include "header.h"

using namespace std;

struct host clients[MAX_NODES];

int PORT;
int maxfd = 0;
int toggle = 1;
std::vector<std::string> blocked_sockets;
int client_scock = -1;
int LOGGED_IN = FALSE;

#define FILE_RECV_PORT 6969
#define LEN_BUFFER 4096


/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);
	/* Clear LOGFILE*/
	
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	if (strcmp(argv[1], "c") == 0)
	{
		client_function(atoi(argv[2]));
	}
	else if (strcmp(argv[1], "s") == 0)
	{
		server(atoi(argv[2]));
	}
	else
	{
		cout << "Usage : <executable> [s|c] [PORT]";
		exit(1);
	}

	return EXIT_SUCCESS;
}


//helper functions
string IntToString(int a)
{
	ostringstream temp;
	temp << a;
	return temp.str();
}

int StringtoInt(string s1)
{
	int x = 0;
	stringstream geek(s1);
	geek >> x;
	return x;
}

std::vector<std::string> tokenize(string s, string del)
{
	std::vector<std::string> arr;
	int start = 0;
	int end = s.find(del);
	while (end != -1)
	{
		arr.push_back(s.substr(start, end - start));
		start = end + del.size();
		end = s.find(del, start);
	}
	arr.push_back(s.substr(start, end - start));
	return arr;
}
std::vector<std::string> tokenize2(std::string s, int count, std::string del)
{
	std::vector<std::string> arr;
	int start = 0;
	int end = s.find(del);
	while (count)
	{
		--count;
		arr.push_back(s.substr(start, end - start));
		start = end + del.size();
		end = s.find(del, start);
	}
	arr.push_back(s.substr(start));
	return arr;
}

string fetch_ip()
{
	struct sockaddr_in ip_addr;
	char ip[INET_ADDRSTRLEN];
	int sock_curr = socket(AF_INET, SOCK_DGRAM, 0);
	int length_address = sizeof(ip_addr);
	memset((char *)&ip_addr, 0, sizeof(ip_addr));
	ip_addr.sin_family = AF_INET;
	ip_addr.sin_port = htons(53);
	inet_pton(AF_INET, "8.8.4.4", &ip_addr.sin_addr); //info about inet_pton from https://man7.org/linux/man-pages/man3/inet_pton.3.html
	connect(sock_curr, (struct sockaddr*)&ip_addr, sizeof(ip_addr));
	getsockname(sock_curr, (struct sockaddr*)&ip_addr, (unsigned int*)&length_address);
	inet_ntop(AF_INET, &(ip_addr.sin_addr), ip, length_address);
	std::string str1(ip);
	return str1;
}

int get_sock(std::string ip)
{
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == ip)
		{
			return clients[i].socket;
		}
	}
	return -1;
}
int get_client(std::string ip)
{
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == ip)
		{
			return i;
		}
	}
	return -1;
}
int loginstat(std::string ip)
{
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == ip)
		{
			return clients[i].is_active;
		}
	}
	return -1;
}

bool compare(host a, host b)
{
	if (a.port < b.port)
		return 1;
	else
		return 0;
}

void sort_list()
{
	sort(clients, clients + MAX_NODES - 1, compare);
}

std::string mystrop(std::string original_str, std::string replaced, std::string replace_with)
{
	int pos = 0;
	int len = replaced.length();
	while (true)
	{
		pos = original_str.find(replaced, (size_t)pos);
		if ((size_t)pos == std::string::npos)
			break;
		original_str.replace((size_t)pos, len, replace_with);
		pos += len;
	}
	return original_str;
}


bool validateIP(std::string ip){
	struct sockaddr_in sa;
	if(inet_pton(AF_INET, ip.c_str(), &(sa.sin_addr)) == 1)
		return true;
	return false;
}

bool active_client(std::string ip){
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == ip)
		{
			return true;
		}
	}
	return false;
}


//update client
void upldate1(int socket)
{
	for (int j = 0; j < MAX_NODES; j++)
	{
		if (!(clients[j].ip.empty()) && (clients[j].socket == socket))
		{
			if (send(clients[j].socket, "ACL;EMPTY;", strlen("ACL;EMPTY;"), 0) != strlen("ACL;EMPTY;"))
			{
				perror("send");
			}
			else
				for (int i = 0; i < MAX_NODES; i++)
				{
					if (clients[i].socket != -1)
					{
						string acl_str = "";
						acl_str += "ACL;ADD:" + clients[i].ip + ":" +
								   clients[i].hostname + ":" +
								   IntToString(clients[i].port) + ":" +
								   IntToString(clients[i].socket) + ":" +
								   IntToString(clients[i].is_active);
						if (send(clients[j].socket, acl_str.c_str(), acl_str.length(), 0) != acl_str.length())
						{
							perror("send");
						}
					}
				}
			break;
		}
	}
}

//update all clients
void update_all()
{
	for (int j = 0; j < MAX_NODES; j++)
	{
		if (!(clients[j].ip.empty()) && !(clients[j].socket == -1))
		{
			if (send(clients[j].socket, "ACL;EMPTY;", strlen("ACL;EMPTY;"), 0) != strlen("ACL;EMPTY;"))
			{
				perror("send");
			}
			else
				for (int i = 0; i < MAX_NODES; i++)
				{
					if (clients[i].socket != -1)
					{
						string acl_str = "";
						acl_str += "ACL;ADD:" + clients[i].ip + ":" +
								   clients[i].hostname + ":" +
								   IntToString(clients[i].port) + ":" +
								   IntToString(clients[i].socket) + ":" +
								   IntToString(clients[i].is_active);
						if (send(clients[j].socket, acl_str.c_str(), acl_str.length(), 0) != acl_str.length())
						{
							perror("send");
						}
					}
				}
		}
	}
}

//connect to a socket
int connect_to_host(const char *server_ip, const char *server_port)
{
	int fdsocket;
	struct addrinfo hints, *res;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if (getaddrinfo(server_ip, server_port, &hints, &res) != 0)
		perror("getaddrinfo failed");

	fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if (fdsocket < 0)
		perror("Failed to create socket");

	if (connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0)
	{
		perror("connect failed");
		freeaddrinfo(res);
		return -1;
	}

	freeaddrinfo(res);

	return fdsocket;
}

//new socket for client
int login(std::string ip, std::string port)
{
	struct sockaddr_in sa;
	int socket;
	if( client_scock != -1){
		LOGGED_IN = TRUE;
		std::string send_str = "";
		send_str += "CL_LOGIN;FROM:" + fetch_ip();

		if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
		{
			perror("send");
		}
		send_str = "";
		send_str += "REQ_ACL;FROM:" + fetch_ip() + ";";

		if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
		{
			perror("send");
		}
		return client_scock;
	}
	socket = connect_to_host(ip.c_str(), port.c_str());
	if (socket != -1)
	{
		LOGGED_IN = TRUE;
		if (socket > maxfd)
		{
			maxfd = socket;
		}
	}
	return socket;
}


//client side operations
void clientcall(std::string acl_str)
{
	std::vector<std::string> client_input;
	client_input = tokenize(acl_str, ";");
	for (int i = 0; i < client_input.size(); i++)
	{
		std::string s = client_input[i];
		if (s == "EMPTY")
		{
			for (int i = 0; i < MAX_NODES; i++)
			{
				clients[i].hostname = "";
				clients[i].ip = "";
				clients[i].port = -1;
				clients[i].socket = -1;
				clients[i].is_active = FALSE;
				clients[i].rcvd_msgs = 0;
				clients[i].sent_msgs = 0;
			}
		}
		else if (s.rfind("ADD:", 0) == 0)
		{
			std::vector<std::string> cl_info;
			cl_info = tokenize(s.substr(4), ":");
			for (int i = 0; i < MAX_NODES; i++)
			{
				if (clients[i].ip.empty())
				{
					clients[i].ip = cl_info[0];
					clients[i].hostname = cl_info[1];
					clients[i].port = StringtoInt(cl_info[2]);
					clients[i].socket = StringtoInt(cl_info[3]);
					clients[i].is_active = StringtoInt(cl_info[4]);
					break;
				}
			}
		}
		else if (s.rfind("REMOVE:", 0) == 0)
		{
			std::vector<std::string> remove_info;
			remove_info = tokenize(s.substr(4), ":");
			for (int i = 0; i < MAX_NODES; i++)
			{
				if (clients[i].ip == remove_info[0] &&
					clients[i].port == StringtoInt(remove_info[1]) &&
					clients[i].socket == StringtoInt(remove_info[2]))
				{
					clients[i].ip = "";
					clients[i].hostname = "";
					clients[i].port = -1;
					clients[i].socket = -1;
					clients[i].is_active = FALSE;
					break;
				}
			}
		}
		
	}
}

void unblock(std::string ip_addr){
	std::string blk_str = "";
	blk_str += "UNBLK_CL;BLKD_IP:" + ip_addr;
	if ((std::count(
			blocked_sockets.begin(),
			blocked_sockets.end(),
			ip_addr)))
	{
		std::vector<std::string>::iterator itr = std::find(
			blocked_sockets.begin(),
			blocked_sockets.end(),
			ip_addr);
		if (itr != blocked_sockets.end())
			blocked_sockets.erase(itr);
		cse4589_print_and_log("[%s:SUCCESS]\n", "UNBLOCK");
	}
	else{
		cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
		return;
	}

	if (send(client_scock, blk_str.c_str(), blk_str.length(), 0) != blk_str.length())
	{
		perror("send");
	}
}


void message_display(std::string s){
	std::vector<std::string> params = tokenize(s,";");
	std::string ip_message = "";
	std::string msg = "";
	for(int i=0;i<params.size();i++){
		std::vector<std::string> parts = tokenize(params[i],":");
		if(parts[0] == "FROM"){
			ip_message = parts[1];
		}
		else if(parts[0] == "TO"){
			//
		}

		else if(parts[0] == "MESSAGE"){
			msg = mystrop(mystrop(parts[1],	"mncpa",":"),"mnchw",	";");
		}
	}
	cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
	cse4589_print_and_log("msg from:%s\n[msg]:%s\n", ip_message.c_str(), msg.c_str());
	cse4589_print_and_log("[%s:END]\n", "RECEIVED");
}


int recv_file(int sockfd, FILE *fp)
{
	int bits;
	char buff[LEN_BUFFER];
	memset(buff, 0, LEN_BUFFER);
	while ((bits = recv(sockfd, buff, LEN_BUFFER, 0)) > 0)
	{
		if (fwrite(buff, sizeof(char), bits, fp) != bits)
		{
			perror("file");
			return 0;
		}
		memset(buff, 0, LEN_BUFFER);
	}
	return 1;
}

int transfer(FILE *fptr, int sockfd)
{
	int bits;
	char buffer[LEN_BUFFER];
	memset(buffer, 0, LEN_BUFFER);
	while ((bits = fread(buffer, sizeof(char), LEN_BUFFER, fptr)) > 0)
	{
		if (send(sockfd, buffer, bits, 0) == -1)
		{
			perror("send");
			return 0;
		}
		memset(buffer, 0, LEN_BUFFER);
	}
	return 1;
}

int init_file_socket()
{
	int opt = TRUE;
	int server_main;
	int addrlen = 0;  
	int new_socket, i;
	struct sockaddr_in address;

	char buffer[1025];
	if ((server_main = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_main, SOL_SOCKET, SO_REUSEADDR, (char *)&opt,
				   sizeof(opt)) < 0)
	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);
	address.sin_family = AF_INET;
	if (bind(server_main, (struct sockaddr *)&address, sizeof(address)) < 0)
	{
		perror("file socket bind failed");
		exit(EXIT_FAILURE);
	}
	fflush(stdin);
	if (listen(server_main, 4) < 0)
	{
		perror("file socket listen");
		exit(EXIT_FAILURE);
	}
	return server_main;
}

void send_file(std::string ip, std::string filename)
{
	char buff[LEN_BUFFER];
	char str_port[12];
	int socket = connect_to_host(ip.c_str(), IntToString(clients[get_client(ip)].port).c_str());
	strncpy(buff, filename.c_str(), filename.length());
	if (send(socket, buff, LEN_BUFFER, 0) == -1)
	{
		perror("name");
	}
	FILE *fp = fopen(filename.c_str(), "rb");
	if (fp == NULL)
	{
		perror("file");
	}
	transfer(fp, socket);
	fclose(fp);
	close(socket);
}
void client_function(int portnum)
{
	fd_set readfds;
	int len;
	int client_select, 
	toggle = 1;
	char buff[1024] = {0};
	int file_fd, new_socket, client_sock, i, valread, addrlen;
	int client_socket[MAX_NODES];
	struct sockaddr_in address;
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);
	addrlen = sizeof(address);
	PORT = portnum;

	file_fd = init_file_socket();
	maxfd = file_fd;
	
	char buffer[1025];
	for (int i = 0; i < MAX_NODES; i++)
	{
		clients[i].hostname = "";
		clients[i].ip = "";
		clients[i].port = -1;
		clients[i].socket = -1;
		clients[i].is_active = FALSE;
		clients[i].rcvd_msgs = 0;
		clients[i].sent_msgs = 0;
	}

	while(TRUE){
		FD_ZERO(&readfds);
		FD_SET(0, &readfds);
		if(LOGGED_IN){
			FD_SET(client_scock, &readfds);
			FD_SET(file_fd, &readfds);
		}

		if (toggle)
		{
			printf("[PA1-Client@CSE489/589]$ ");
			fflush(stdout);
		}
		client_select = select(maxfd + 1, &readfds, NULL, NULL, NULL);
		if (client_select == -1)
		{
			perror("select()");
			exit(EXIT_FAILURE);
		}
		else if (client_select)
		{
			if (LOGGED_IN && FD_ISSET(client_scock, &readfds))
			{
				int val = recv(client_scock, buffer, sizeof(buffer), 0);
				if(val >= 0){
					if(strncmp("ACL;", buffer, strlen("ACL;")) == 0){
						std::string s(buffer);
						clientcall(s);
						toggle = 0;
					}
					else if(strncmp("RELAY;", buffer, strlen("RELAY;")) == 0){
						std::string s(buffer);
						message_display(s);
						toggle = 1;
					}
					else if(strncmp("LOGIN_SUCCESSFUL;", buffer, strlen("LOGIN_SUCCESSFUL;")) == 0){
						std::string s(buffer);
						cse4589_print_and_log("[%s:SUCCESS]\n", "LOGIN");
						cse4589_print_and_log("[%s:END]\n", "LOGIN");
						toggle = 1;
					}
					else{
						printf("\nServer: %s\nVal: %d\n", buffer, val);
						if(val == 0){
							
							close(client_scock);
							exit(0);
						}
						toggle = 1;
					}
					memset(&buffer[0], 0, sizeof(buffer));
				}
				else{
					printf("\nError in Server message");
					toggle = 1;
				}
				fflush(stdout);
			}
			else if (FD_ISSET(0, &readfds))
			{
				fgets(buff, sizeof(buff), stdin);
				len = strlen(buff) - 1;
				if (buff[len] == '\n')
					buff[len] = '\0';
				if (strcmp(buff, "") == 0)
				{
					toggle = 1;
				}
				else
				{
					common_cmd(buff,0);
					other_cmd(buff,0);
					fflush(stdout);
					toggle = 1;
				}
			}
			else if (FD_ISSET(file_fd, &readfds))
			{
				toggle = 1;
				struct sockaddr_in address;
				int new_socket;
				address.sin_family = AF_INET;
				address.sin_addr.s_addr = INADDR_ANY;
				address.sin_port = htons(PORT);
				addrlen = sizeof(address);
				if ((new_socket = accept(file_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
				{
					perror("accept");
					exit(EXIT_FAILURE);
				}
				char name_buf[LEN_BUFFER];
				memset(name_buf, 0, LEN_BUFFER);
				if (recv(new_socket, name_buf, LEN_BUFFER, 0) == -1)
				{
					perror("filename");
				}
				FILE *fp = fopen(name_buf, "wb");
				if (!fp)
				{
					perror("file");
				};
				if (recv_file(new_socket, fp) > 0)
				{
					printf("[%s:SUCCESS]\n", "RECEIVED");
					printf("[%s:END]\n", "RECEIVED");
				}
				fclose(fp);
				close(new_socket);
			}
			else{
				printf("\nnull");
				toggle = 1;
				fflush(stdout);
			}
		}
	}
}

void server(int portnum)
{
	fd_set readfds;
	int len;
	int server_select;
	toggle = 1;
	char buff[1024] = {0};
	int client_sock, i, valread, addrlen;
	int master_sock, new_socket; 
	int client_socket[MAX_NODES];
	struct sockaddr_in address;
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);
	addrlen = sizeof(address);

	PORT = portnum;
	int maxfd = 0;
	char buffer[1025];

	master_sock = server_sock();
	maxfd = master_sock;
	for (int i = 0; i < MAX_NODES; i++)
	{
		clients[i].hostname = "";
		clients[i].ip = "";
		clients[i].port = -1;
		clients[i].socket = -1;
		clients[i].is_active = FALSE;
		clients[i].rcvd_msgs = 0;
		clients[i].sent_msgs = 0;
	}
	while (1)
	{
		FD_ZERO(&readfds);
		FD_SET(0, &readfds);
		FD_SET(master_sock, &readfds);
		for (i = 0; i < MAX_NODES; i++)
		{
			if (clients[i].socket != -1)
			{
				client_sock = clients[i].socket;
				FD_SET(client_sock, &readfds);
			}
		}
		if (toggle)
		{
			printf("[PA1-Server@CSE489/589]$ ");
			fflush(stdout);
		}
		server_select = select(maxfd + 1, &readfds, NULL, NULL, NULL);
		fflush(stdin);

		if (server_select == -1)
		{
			perror("select()");
			exit(EXIT_FAILURE);
		}
		else if (server_select)
		{
			if (FD_ISSET(master_sock, &readfds)) 
			{
				if ((new_socket = accept(master_sock, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
				{
					perror("accept");
					exit(EXIT_FAILURE);
				}
				char host[1024], service[20];
				getnameinfo((struct sockaddr *)&address, sizeof address, host, sizeof host, service, sizeof service, 0);

				for (i = 0; i < MAX_NODES; i++)
				{
					if (clients[i].socket == -1)
					{
						clients[i].socket = new_socket;
						clients[i].ip = inet_ntoa(address.sin_addr);
						clients[i].port = ntohs(address.sin_port);
						clients[i].hostname = host;
						clients[i].is_active = TRUE;
						if (new_socket > maxfd)
							maxfd = new_socket;
						break;
					}
				}
				toggle = 0;
				int client_socket = clients[i].socket;
				std::string login_msg = "LOGIN_SUCCESSFUL;";
				if (send(client_socket, login_msg.c_str(), login_msg.length(), 0) != login_msg.length())
				{
					perror("send");
				}
			}
			else if (FD_ISSET(0, &readfds))
			{
				fgets(buff, sizeof(buff), stdin);
				len = strlen(buff) - 1;
				if (buff[len] == '\n'){
					buff[len] = '\0'; //null 
				}
				if (strcmp(buff, "") == 0)
					toggle = 1;
				else
				{
					common_cmd(buff,1);
					other_cmd(buff,1);
					fflush(stdout);
					toggle = 1;
				}
			}
			else
			{
				for (i = 0; i < MAX_NODES; i++)
				{
					client_sock = clients[i].socket;
					if (FD_ISSET(client_sock, &readfds))
					{
						valread = read(client_sock, buffer, 1024);
						if (valread == 0 || valread == -1) 
						{
							getpeername(client_sock, (struct sockaddr *)&address, (socklen_t *)&addrlen);
							close(client_sock);
							clients[i].ip = "";
							clients[i].hostname = "";
							clients[i].port = -1;
							clients[i].socket = -1;
							toggle = 0;
						}
						else
						{
							buffer[valread] = '\0';
							if (strncmp("RELAY;", buffer, strlen("RELAY;")) == 0)
							{
								client_msg((const char*)buffer);
							}
							if (strncmp("BROADCAST;", buffer, strlen("BROADCAST;")) == 0)
							{
								broadcast(buffer);
							}
							else if (strncmp("REQ_ACL;", buffer, strlen("REQ_ACL;")) == 0)
							{
								upldate1(clients[i].socket);
								toggle = 0;
							}
							else if (strncmp("UPDATE_PORT;", buffer, strlen("UPDATE_PORT;")) == 0)
							{
								updatecport(buffer, i);
								upldate1(clients[i].socket);
								toggle = 0;
							}
							else if (strncmp("CL_LOGOUT;", buffer, strlen("CL_LOGOUT;")) == 0)
							{
								clients[i].is_active = FALSE;
								toggle = 0;
							}
							else if (strncmp("CL_LOGIN;", buffer, strlen("CL_LOGIN;")) == 0)
							{
								clients[i].is_active = TRUE;
								toggle = 0;
								relay(i);
							}
							else if (strncmp("BLK_CL;", buffer, strlen("BLK_CL;")) == 0)
							{
								block_sock(clients[i].ip,buffer);
								toggle = 0;
							}
							else if (strncmp("UNBLK_CL;", buffer, strlen("UNBLK_CL;")) == 0)
							{
								unblock_sock(clients[i].ip,buffer);
								toggle = 0;
							}
							
						}
					}
				}
			}
		}
		else
		{
			printf("Error");
		}
		fflush(stdin);
	}
}


//general commands
void common_cmd(char* s,int node){
	
	if (strcmp(s, "AUTHOR") == 0)
	{
		char author_name[10]="hramadas";
		cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
		cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", author_name);
		cse4589_print_and_log("[%s:END]\n", "AUTHOR");
	}
	else if (strcmp(s, "PORT") == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", "PORT");
		cse4589_print_and_log("PORT:%d\n", PORT);
		cse4589_print_and_log("[%s:END]\n", "PORT");
	}
	else if (strcmp(s, "IP") == 0)
	{
        struct sockaddr_in address;
        int addrlen = sizeof(address);
        memset((char *)&address, 0, sizeof(address));
        address.sin_family = AF_INET;
        address.sin_port = htons(53);
        
        int dummy_sock = socket(AF_INET, SOCK_DGRAM, 0);
      
        char ip_address[16];
        inet_pton(AF_INET, "8.8.4.4", &address.sin_addr);
        connect(dummy_sock, (struct sockaddr*)&address, sizeof(address));
        getsockname(dummy_sock, (struct sockaddr*)&address, (unsigned int*)&addrlen);
        inet_ntop(AF_INET, &(address.sin_addr), ip_address, addrlen);

		cse4589_print_and_log("[%s:SUCCESS]\n", "IP");
	    cse4589_print_and_log("IP:%s\n", ip_address);
		cse4589_print_and_log("[%s:END]\n", "IP");
	}
	else if (strcmp(s, "LIST") == 0)
	{
		if(node == 0 && (!LOGGED_IN) ){
			cse4589_print_and_log("[%s:ERROR]\n", "LIST");
		}else{
			cse4589_print_and_log("[%s:SUCCESS]\n", "LIST");
			sort_list();
			int list_id = 0;
			for (int i = 0; i < MAX_NODES; i++)
			{
				if (clients[i].socket != -1 && clients[i].is_active == TRUE)
				{
					list_id++;
					cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, clients[i].hostname.c_str(), clients[i].ip.c_str(), clients[i].port);
				}
			}
		}
		cse4589_print_and_log("[%s:END]\n", "LIST");
	}
	else if (strcmp(s, "STATISTICS") == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", "STATISTICS");
		sort_list();
		int count = 0;
		for (int i = 0; i < MAX_NODES; i++)
		{
			if (clients[i].socket != -1)
			{
				count++;
				cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", count, 
									clients[i].hostname.c_str(),
									clients[i].sent_msgs,
									clients[i].rcvd_msgs, clients[i].is_active?"logged-in":"logged-out"
									);
			}
		}
		cse4589_print_and_log("[%s:END]\n", "STATISTICS");
	}
}
//sock specific commands
void other_cmd(char* s, int node){
	std::string send_str = "";
	if (strncmp("LOGIN", s, strlen("LOGIN")) == 0){
		string login_str = s;
		std::vector<std::string> params = tokenize(login_str);
		if(validateIP(params[1]) && StringtoInt(params[2])){
			client_scock = login(params[1],params[2]);
			if(client_scock == -1){
				cse4589_print_and_log("[%s:ERROR]\n", "LOGIN");
				cse4589_print_and_log("[%s:END]\n", "LOGIN");
			}
			else{
				send_str = "";
				send_str += "UPDATE_PORT;PORT:" + IntToString(PORT);

				if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
				{
					perror("send");
				}
			}
		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "LOGIN");
			cse4589_print_and_log("[%s:END]\n", "LOGIN");
		}
	}
	else if (strncmp("REFRESH", s, strlen("REFRESH")) == 0){
		if(node == 0 && (!LOGGED_IN) ){
			cse4589_print_and_log("[%s:ERROR]\n", s);
		}else{
			cse4589_print_and_log("[%s:SUCCESS]\n", s);
			send_str = "";
			send_str += "REQ_ACL;FROM:" + fetch_ip() + ";";

			if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
			{
				perror("send");
			}
		}
		cse4589_print_and_log("[%s:END]\n", s);
	}
	else if (strncmp("SEND ", s, strlen("SEND ")) == 0){
		string send_msg = s;
		std::vector<std::string> params = tokenize2(send_msg, 2);
		fflush(stdin);


		std::string fmtd_msg = mystrop(
		mystrop(
			params[2], ";", "mnchw"),
		":", "mncpa");
		if(validateIP(params[1]) && active_client(params[1])){
			std::string send_str = "";
			send_str += "RELAY;FROM:" + fetch_ip() + ";TO:" + params[1] + ";MESSAGE:" + fmtd_msg + ";";

			if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
			{
				perror("send");
				cse4589_print_and_log("[%s:ERROR]\n", "SEND");
			}
			else{
				cse4589_print_and_log("[%s:SUCCESS]\n", "SEND");
			}
		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "SEND");
		}


		cse4589_print_and_log("[%s:END]\n", "SEND");
	}
	
	else if (strncmp("BLOCK ", s, strlen("BLOCK ")) == 0){
		string stringed_com = s;
		std::vector<std::string> params = tokenize(stringed_com);
		if(validateIP(params[1])){
			send_str = "";
			send_str += "BLK_CL;BLKD_IP:" + params[1];
			if ((std::count(
					blocked_sockets.begin(),
					blocked_sockets.end(),
					params[1])))
			{
				cse4589_print_and_log("[%s:ERROR]\n", "BLOCK");
				return;
			}
			if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
			{
				perror("send");
			}
			blocked_sockets.push_back(params[1]);
			cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCK");

		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "BLOCK");
		}
		cse4589_print_and_log("[%s:END]\n", "BLOCK");
	}
	else if (strncmp("UNBLOCK ", s, strlen("UNBLOCK ")) == 0){
		string stringed_com = s;
		std::vector<std::string> params = tokenize(stringed_com);
		if(validateIP(params[1])){
			unblock(params[1]);
		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
		}
		cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
	}
	else if (strncmp("BLOCKED", s, strlen("BLOCKED")) == 0){
		string stringed_com = s;
		std::vector<std::string> params = tokenize(stringed_com);
		if(validateIP(params[1])){
			int validity = get_client(params[1]);
			if( validity == -1){
				cse4589_print_and_log("[%s:ERROR]\n", "BLOCKED");
				return;
			}
			else{
				cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCKED");
			}
			sort_list();
			int j = get_client(params[1]);
			int count = 0;
			for (int i = 0; i < MAX_NODES; i++)
			{
				if(is_blocked(params[1],clients[i].ip)){
					count++;
					cse4589_print_and_log(
						"%-5d%-35s%-20s%-8d\n", 
						count, clients[i].hostname.c_str(), 
						clients[i].ip.c_str(), clients[i].port);
				}
			}

		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "BLOCKED");
		}
		cse4589_print_and_log("[%s:END]\n", "BLOCKED");
	}
	else if (strncmp("BROADCAST", s, strlen("BROADCAST")) == 0){
		string send_str = s;
		std::vector<std::string> params = tokenize(send_str);
		if(LOGGED_IN){
			cse4589_print_and_log("[%s:SUCCESS]\n", "BROADCAST");

			send_str = "";
			send_str += "BROADCAST;FROM:" + fetch_ip() + ";MESSAGE:"+ params[1];

			if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
			{
				perror("send");
			}
		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "BROADCAST");
		}
		cse4589_print_and_log("[%s:END]\n", "BROADCAST");
	}
	else if (strncmp("LOGOUT", s, strlen("LOGOUT")) == 0){
		cse4589_print_and_log("[%s:SUCCESS]\n", s);
		send_str = "";
		send_str += "CL_LOGOUT;FROM:" + fetch_ip();

		if (send(client_scock, send_str.c_str(), send_str.length(), 0) != send_str.length())
		{
			perror("send");
		}
		LOGGED_IN = FALSE;
		cse4589_print_and_log("[%s:END]\n", s);
	}
	else if (strncmp("SENDFILE", s, strlen("SENDFILE")) == 0){
		string sendfile_str = s;
		if(LOGGED_IN){
			cse4589_print_and_log("[%s:SUCCESS]\n", "SENDFILE");
			std::vector<std::string> params = tokenize(sendfile_str);
			send_file(params[1],params[2]);
		}
		else{
			cse4589_print_and_log("[%s:ERROR]\n", "SENDFILE");

		}
		cse4589_print_and_log("[%s:END]\n", "SENDFILE");
	}
	else if (strcmp(s, "EXIT") == 0)
	{
		close(client_scock);
		exit(0);
	}

	else
	{
		cout << "No matching command : " << s;
	}
}


//init for server socket
int server_sock()
{
	int opt = TRUE;
	int server_main;
	struct sockaddr_in address;

	if ((server_main = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	if (setsockopt(server_main, SOL_SOCKET, SO_REUSEADDR, (char *)&opt,
				   sizeof(opt)) < 0)
	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);
	if (bind(server_main, (struct sockaddr *)&address, sizeof(address)) < 0)
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
	fflush(stdin);
	if (listen(server_main, 4) < 0)
	{
		perror("listen");
		exit(EXIT_FAILURE);
	}
	return server_main;
}
//broadcast to everyone
void broadcast(char* buffer){
	std::string dest_regex = "";
	std::string bdcst_str(buffer + 10);
	std::string relay_str = "";
	std::string send_str = "";
	std::string dest_ip = "255.255.255.255";
	std::string ip_message = "";
	std::string message = "";
	int dest_socket = -1;
	std::vector<std::string> params = tokenize(bdcst_str, ";");
	for (int i = 0; i < params.size(); i++)
	{
		std::vector<std::string> parts = tokenize(params[i], ":");
		if (parts[0] == "FROM")
		{
			ip_message = parts[1];
		}
		else if (parts[0] == "MESSAGE")
		{
			message = parts[1];
		}
	}
	cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
	track_msg(ip_message,1);
	cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",ip_message.c_str(),"255.255.255.255",message.c_str());
	cse4589_print_and_log("[%s:END]\n", "RELAYED");
	for(int i=0; i<MAX_NODES ; i++){
		if(clients[i].is_active == TRUE && clients[i].ip != ip_message){
			relay_str += "RELAY;FROM:" + ip_message + ";TO:"
						+ clients[i].ip + ";MESSAGE:" + message + ";";
			if (clients[i].socket != -1)
			{
				if (send(clients[i].socket, relay_str.c_str(), relay_str.length(), 0) != relay_str.length())
				{
					perror("send");
				}
				else{
					track_msg(clients[i].ip,0);
				}
			}
		}
	}

	toggle = 1;
	if (dest_socket != -1)
	{
		if (send(dest_socket, buffer, strlen(buffer), 0) != strlen(buffer))
		{
			perror("send");
		}
	}
}

void updatecport(char* buffer, int i){
	std::string port_num (buffer+strlen("UPDATE_PORT;PORT:"));
	clients[i].port = StringtoInt(port_num);

}

void track_msg(std::string ip, int type){
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == ip)
		{
			if (type==1){
				clients[i].sent_msgs ++;
			}
			else if (type==0){
				clients[i].rcvd_msgs ++;
			}	
				return;
		}
	}
}
//check if client is blicked
bool is_blocked(std::string blking, std::string blkd){
	int i = get_client(blking);
	if(std::count(clients[i].blocked_clients.begin(), clients[i].blocked_clients.end(), blkd)){
		return true;
	}
	return false;
}
//block a client
void block_sock(std::string blking_client, char* buffer){
	std::vector<std::string> blk_commands;
	blk_commands = tokenize(buffer, ";");
	std::string client_blocked = "NONE";
	for (int i = 0; i < blk_commands.size(); i++)
	{
		std::vector<std::string> parts = tokenize(blk_commands[i],":");
		if(parts[0] == "BLKD_IP"){
			client_blocked = parts[1];
			break;
		}
	}
	if(client_blocked == "NONE"){
		return;
	}
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == blking_client)
		{
			if( !(std::count(clients[i].blocked_clients.begin(), clients[i].blocked_clients.end(), client_blocked))){
				clients[i].blocked_clients.push_back(client_blocked);
			}
			return;
		}
	}
}
//Message relayed
void relay(int i){
	int tot_msgs = clients[i].blocked_msgs.size();
	for (int j = 0; j < tot_msgs; j++)
	{
		client_msg(clients[i].blocked_msgs[j].c_str());
		if ((std::count(clients[i].blocked_msgs.begin(), clients[i].blocked_msgs.end(), clients[i].blocked_msgs[j])))
		{
			std::vector<std::string>::iterator itr = std::find(
				clients[i].blocked_msgs.begin(),
				clients[i].blocked_msgs.end(),
				clients[i].blocked_msgs[j]);
			if (itr != clients[i].blocked_msgs.end())
				clients[i].blocked_msgs.erase(itr);
		}
	}
	
	int client_s = clients[i].socket;
	std::string loginStr = "LOGIN_SUCCESSFUL;";
	if (send(client_s, loginStr.c_str(), loginStr.length(), 0) != loginStr.length())
	{
		perror("send");
	}
}
//unblock a client
void unblock_sock(std::string blking_client, char* buffer){
	std::vector<std::string> blk_commands;
	blk_commands = tokenize(buffer, ";");
	std::string client_blocked = "NONE";
	for (int i = 0; i < blk_commands.size(); i++)
	{
		std::vector<std::string> parts = tokenize(blk_commands[i],":");
		if(parts[0] == "BLKD_IP"){
			client_blocked = parts[1];
			break;
		}
	}
	if(client_blocked == "NONE"){
		return;
	}
	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == blking_client)
		{
			if((std::count(clients[i].blocked_clients.begin(), clients[i].blocked_clients.end(), client_blocked))){
				std::vector<std::string>::iterator itr = std::find(
					clients[i].blocked_clients.begin(),
					clients[i].blocked_clients.end(),
					client_blocked);
				if (itr != clients[i].blocked_clients.end())
					clients[i].blocked_clients.erase(itr);
			}
			return;
		}
	}
}


void client_msg(const char *buffer)
{
	std::string dest_regex = "";
	std::string relay_str(buffer + 6);
	std::string send_str = "";
	std::string dest_ip = "";
	std::string ip_message = "";
	std::string message = "";
	int dest_socket = -1;
	std::vector<std::string> params = tokenize(relay_str, ";");
	for (int i = 0; i < params.size(); i++)
	{
		std::vector<std::string> parts = tokenize(params[i], ":");
		if (parts[0] == "FROM")
		{
			ip_message = parts[1];
		}
		else if (parts[0] == "TO")
		{
			dest_socket = get_sock(parts[1]);
			dest_ip = parts[1];
		}
		else if (parts[0] == "MESSAGE")
		{
			message = parts[1];
		}
	}
	if(is_blocked(dest_ip,ip_message)){
		return;
	}
	

	for (int i = 0; i < MAX_NODES; i++)
	{
		if (clients[i].ip == dest_ip && clients[i].is_active)
		{
			toggle = 1;
			if (dest_socket != -1)
			{
				if (send(dest_socket, buffer, strlen(buffer), 0) != strlen(buffer))
				{
					perror("send");
				}
				else{
					cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
					track_msg(dest_ip,0);
					track_msg(ip_message,1);
					std::string msg = mystrop(mystrop(message,	"mncpa",":"),"mnchw",";");
					cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", ip_message.c_str(), dest_ip.c_str(), msg.c_str());
					cse4589_print_and_log("[%s:END]\n", "RELAYED");
				}
			}
		}
	}
	if( loginstat(dest_ip) == FALSE ){
		int i = get_client(dest_ip);
		std::string store_str(buffer);
		clients[i].blocked_msgs.push_back(store_str);
	}
}




