/**
  * @nmanali_assignment1
  * @author  Nikhil Manali<nmanali@buffalo.edu>
  * @version 1.0
  *
  * @section LICENSE
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License as
  * published by the Free Software Foundation; either version 2 of
  * the License, or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful, but
  * WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  * General Public License for more details at
  * http://www.gnu.org/copyleft/gpl.html
  *
  * @section DESCRIPTION
  *
  * This contains the main function. Add further description here....
  */



#include<iostream>
#include<sstream>
#include<string>
#include<cstdlib>
#include<sys/types.h>
#include<netdb.h>
#include<sys/wait.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<signal.h>
#include<errno.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<ifaddrs.h>
#include<vector>
#include<algorithm>
#include<cctype>

#define PORT "9000"

#define STDIN 0

#include "../include/global.h"
#include "../include/logger.h"

using namespace std;



struct BlockStruc{char IP[50];}; // Block structure
struct messageStruc{char info[1400];}; // Message structure


/*
logList 
structure */

struct logList{char sno[2],name[100],IP[200],port[10];}; 

/* State of each 
client is stored 
in this structure */
struct ListNode{char IP[50];int fd_sock;int port;
                bool status_log;int num_sent;
                int recv_num;bool reg;
                vector<struct messageStruc>buffer_message; vector<struct BlockStruc>bockList;};

bool mycomp(ListNode list_1,ListNode list_2){return list_1.port<list_2.port;}



int main(int argc,char **argv){
	std::cout << "Starting the main function" << std::endl;
	
	cse4589_init_log(argv[2]);   /*Init. Logger*/


    fclose(fopen(LOGFILE, "w")); 	/* Clear LOGFILE*/

	/*Start Here*/
	


class Clientside{
    vector<logList>  L;
    int port;
    vector<struct Block> Block1;
    int socketfd;
    int fdmax;
    int listsize;
    char Addr[20];
    struct addrinfo hints,*res,*myres,newhints;
    fd_set masterList,read_fds;
    bool loggedin;
    struct sockaddr_in peer;

    public:
    Clientside(char *arg){
        //login flag
        loggedin = false;
        port = atoi(arg);
        memset(&hints,0,sizeof(hints));
        //HINTS
        hints.ai_family=AF_INET;
        hints.ai_flags=AI_PASSIVE;
		hints.ai_socktype=SOCK_STREAM;


    }
    // getting port
    
    void getmyPort(){
        std::cout << " Enter port function" << std::endl;
        
        
        
        char com[] = "PORT";
        cse4589_print_and_log("[%s:SUCCESS]\n", com);

		cse4589_print_and_log("PORT:%d\n",port);
		
		cse4589_print_and_log("[%s:END]\n", com);
	
    }

    /*
    
    Getting 
    
    Local Ip
    */
    void getmyIP(){
        
        
        char IP[1000];
        
        char com[] = "IP";
        struct ifaddress *ifa,*p;
        
        // Decalre structre 
        // With while loop

        p = ifa;
        while(p!=NULL){
            struct sockaddr *s=p->ifa_addr;
            if(s->sa_family==AF_INET)
                        {
                                inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

                                if(strcmp(IP,"127.0.0.1")!=0)
                                {
					cse4589_print_and_log("[%s:SUCCESS]\n", com);
					fflush(NULL);
					strcpy(Addr,IP);
					cse4589_print_and_log("IP:%s\n", IP);
					fflush(NULL);
					cse4589_print_and_log("[%s:END]\n", com);
					fflush(NULL);
					break;
				}
                        }
            p=p->ifa_next;

        }
    }

/*


Getting MY IP
Local
*/

    bool GetmyIP()
        {
            std::cout << "Enter GetmyIP function" << std::endl;
                struct ifaddrs *ifa,*p;
                char IP[2000];
                char com[]="IP";
                p=ifa;

                while(p!=NULL){
                    struct sockaddr *s=p->ifa_addr;
                    if(s->sa_family==AF_INET)
                        {
                                inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

                                if(strcmp(IP,"127.0.0.1")!=0)
                                {
                                        strcpy(Addr,IP);    
                                        return true;
                                }
                        }


                    p=p->ifa_next;
                }

		return false;

   }


/*

Getting the first 3 character
using extractFirst, extractSecond, extractThird char functions
*/

   char *extractFirst(char *input)
        {
                char *first=new char[30];
                int j=0;
                int i=0;
                while(input[i]!='\0' && input[i] != ' '){
                    first[j]=input[i];
                    i++;
                    j++;
                }
                first[j]='\0';
                return first;
        }

    char *getSecond(char *input,char *second){
        int j=0;
        int i=0;
        for(i=0;input[i]!=' '&&input[i]!='\0';i++);

        for(;isalnum(input[i])==0&&input[i]!='\0';i++);

        while(input[i]!=' '&&input[i]!='\0'){
            second[j]=input[i];
            i++;
            j++;
        }

        second[j]='\0';
        return second;
        
    }

    char *extractSecond(char *input){

        char *second1 = new char[400];

         char* second = getSecond(char *input,char *second1);
        return second;
    }

    char* getThird(char *input,char *third){
        int i;
        int j=0;
        for(i=0;input[i]!=' '&&input[i]!='\0';i++);
        i++;
        for(;input[i]!=' '&&input[i]!='\0';i++);
        i++;
        while(input[i]!='\0'){
            third[j]=input[i];
            i++;
            j++;
        }
        third[j]='\0';
        return third;

    }

    char *extractThird(char *input)
        {
                char *third=new char[1024];
                third = getThird(char *input,char *third);
                return third;
  
        }
        
        
    // Extracting various charter end    
    char* getBroad(char *input, char *third){
        int i=0;
        int j=0;
        for(i=0;input[i] != ' ' && input[i] != '\0';i++);
        i++;
      
        while(input[i] != '\0'){
            third[j]=input[i];
            i++;
            j++;
        }
        third[j]='\0';
        return third;
    }
    
    char* broadExtract(char *input){
        char *third = new char[1024];
        third = getBroad(char *input, char *third);
        return third;
    }

    void listSplit(char *str){
        char *print;
        vector<char*>s;
        print = strtok(str,"-");
        while(print != NULL){
            s.push_back(print);
            print=strtok(NULL,"-");
        }
        updateList(s);
    }

    void splitList(char *p){
        char str[500];
        strcpy(str,p);
        listSplit(char *str);

    }

    void updateList(vector<char*>s){
        struct logList list1;
        L.clear();
        sizeOfList = s.size();
        char str[500];
        char *p;
        int i=0;
        while(i<s.size()){
            strcpy(str,s[i]);
            p=strtok(str," ");
            strcpy(list1.sno,p);
            p=strtok(NULL," ");
            strcpy(list1.name,p);
            p=strtok(NULL," ");
            strcpy(list1.IP,p);
            p=strtok(NULL," ");
            strcpy(list1.port,p);
            L.push_back(l1);
        }
    }

    char* msgrecv(int socketfd,char *message){
        char *buffer;
        char str[1500];
        int size;
        int total =0;
        int n;
        while(total<size){
            n=recv(socketfd,str+total,size,0);
            if(n==-1) break;
            total += n;
            size-=n;
        }
        str[total] = '\0';
        strcpy(message,str);
        return message;

    }

    char* recvmsg(int socketfd, char*msg){
       
        int size;
        recv(socketfd,&size,sizeof(size),0);
        char* res = msgrecv(int socketfd,char *message);
        return res;
    }

   void sendall(int sockfd,char *type,char* buf)
        {	char *message=new char[1048];
                strcat(type,buf);
		strcpy(message,type);
                int size=strlen(message);
                int n;
                int total=0;
                send(sockfd,&size,sizeof(size),0);
                while(total<size)
                {
                        n=send(sockfd,message+total,size,0);

                        if(n==-1)
                        break;

                        total+=n;
                        size-=n;
                }
		delete[] message;	
               
        }
        
        
    bool checkValidPort(char *port){
        std::cout << " Enter check valid port" << std::endl;
        
        bool flag=true;
        int i=0;
        
        
        while(i<strlen(port)){
            if(isdigit(port[i])!=0){
                continue;
            }else{
                flag = false;
                break;
            }
            i++;
        }
        if(flag!=true) return false;
        long v = atol(port);
        if(v<0 || v>65335) false;
        
        if(flag!=true) return false;
        return true;
    }    

    /*
     Check if the ip is correct or not
    */
    bool isValidIP(char *IP){
                std::cout << " Entering isValid" << std::endl;
                struct sockaddr_in s;
                int i=inet_pton(AF_INET,IP,&(s.sin_addr));
                if(i==0)return false;
                return true;
        }

	void printList()
	{
		char command_str[]="LIST";
		cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
		fflush(NULL);
		for(int i=0;i<L.size();i++)
		cse4589_print_and_log("%-5d%-35s%-20s%-8s\n", i+1,L[i].name,L[i].IP,L[i].port);
		fflush(NULL);
		cse4589_print_and_log("[%s:END]\n", command_str);
		fflush(NULL);
	}



}






	class Server{
	    
	    
	    vector<struct ListNode> listRemote;
    	int fd_sock;
    	int fd_new;
    	
    
        int fdmax;
        int yes;
    	
    	
    	socklen_t addrlen;
    	int port;
    	
    	struct sockaddr_in resources;
    	struct sockaddr remoteAddr;
    	
    	
    	fd_set master;
    	fd_set fds_read;
    	fd_set fds_write;
    	
	
	void get_port_val(){	char command_str[]="PORT";

            /* 
            Returning the output
            */
            
            printf ("%s \n", "get Port Function");
            
			cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
			cse4589_print_and_log("PORT:%d\n",ntohs(resources.sin_port));
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
	}
	
	
	void listOutput(){	
	    
	    std::cout << "Entering List Output" << std::endl;
	    
	    char service_val[100];
	    char host_name[200];
	    

		char command_str[]="LIST";
		cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
		fflush(NULL);
		
		sockaddr_in s;
		socklen_t size=sizeof(s);
		int i =0;
		
		while(i<listRemote.size()){
		   
		   if(listRemote[i].log_status==true && listRemote[i].reg==true){	
       			//cout<<i+1<<" "<<hostname<<" "<<remoteList[i].IP<<" "<<remoteList[i].port<<endl<<flush;

		       inet_aton(listRemote[i].IP,&s.sin_addr);
                        	s.sin_family=AF_INET;
				getnameinfo((struct sockaddr*)&s,size, host_name,sizeof(host_name),service_val,sizeof service_val,NI_NAMEREQD);
				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", i+1, host_name, listRemote[i].IP, listRemote[i].port);
				fflush(NULL);
			}
			i++;
		}
		
		cse4589_print_and_log("[%s:END]\n", command_str);
		fflush(NULL);
	}
	
	
	
	
	char* getList(char* mes){
	    
	    /*
	    Getting all 
	    my list
	    
	    */
        
    	std::cout << "Enter the get list part" << std::endl;

        	    
		char *p=new char[500];
		
		char host[200],service[200];
		
		
		struct sockaddr_in sock;
		socklen_t slen=sizeof(sock);
		
		p[0]='\0';
		
		int i=0;;
		

		// Sorting the list
		sort(listRemote.begin(),listRemote.end(),mycomp);
		
		
		while(i<remoteList.size()){
		 
		 
		 if(remoteList[i].log_status==true  && remoteList[i].reg==true){	
		        
		        strcat(p,"-");
    
    			stringstream stream;
    			
    			stream<<(i+1); 
    			
    			string temp=stream.str();
    			
    			char *num=new char[temp.length()+1];
    			strcpy(num,temp.c_str());
    
    			//cout<<num<<endl;
    			strcat(p,num);
    			strcat(p," ");
    			//cout<<p<<endl;
    			inet_aton(remoteList[i].IP,&s.sin_addr);
    			s.sin_family=AF_INET;
    		
    			getnameinfo((struct sockaddr*)&s,slen,host,sizeof(host),service,sizeof(service),NI_NAMEREQD);
    			strcat(p,host);
    			
    			
    			strcat(p," ");
    			inet_ntop(AF_INET,&(s.sin_addr),host,INET_ADDRSTRLEN);
    
    			strcat(p,host);
    			strcat(p," ");
    			stream.str("");
    			stream<<remoteList[i].port;
    			temp=stream.str();
    			delete[] num;
    			num=new char[temp.length()+1];
    			strcpy(num,temp.c_str());
    			strcat(p,num);
    			delete[] num;
    		 }
		 i++;
		}
		
		strcpy(mes,p);
		return mes;
	}


	
	
	
	public:
	void getMyIp_usingInt() {
	    
	    //Helper function to fetch
	    //the inet IP address and referred 
	    //from Wenjun's Recitation Material
	    
	    
		socklen_t socket_len;
		int fd_temp;
		char IP[2000];
		
	    
		struct addrinfo ip_hints,*ip_res;
		struct sockaddr_in sock_addr;

		memset(&ip_hints,0,sizeof(ip_hints));
		ip_hints.ai_family=AF_INET;
		ip_hints.ai_flags=AF_UNSPEC;
		ip_hints.ai_socktype=SOCK_DGRAM;


		
		if((fd_temp=socket(ip_res->ai_family,ip_res->ai_socktype,ip_res->ai_protocol))==-1){
			perror("ip socket: ");
			exit(-1);
		}
	
		if(getaddrinfo("8.8.8.8","53",&ip_hints,&ip_res)==-1){
			perror("ip getaddrinfo: ");
			exit(-1);
		}

		mylen=sizeof(sock_addr);

		if(getsockname(fd_temp,(struct sockaddr*)&sock_addr,&mylen)==-1){
			perror("getsock: ");
			exit(-1);
		}

		if(connect(fd_temp,ip_res->ai_addr,ip_res->ai_addrlen)==-1)
		{
			perror("ip connect: ");
			exit(-1);
		}
		


		inet_ntop(AF_INET,&(me.sin_addr),IP,sizeof(IP));
		if(strcmp(IP,"127.0.0.1")!=0){cout<<IP<<endl<<flush;}
		
		close(fd_temp);
	}
	
	
	void Local_Ip(){
		
		std::cout << "Entering Local_Ip" << std::endl;
		
		// Getting 
		// Local Ip
		struct addrs_if *p;
		
		struct addrs_if *ifa_add;
		char IP[2000];
		
		char command_str[]="IP";
		
		if(getifaddrs(&ifa_add)==-1){
		    
			std::cout << "Getting IF address" << std::endl;
			
			// Getting If address
			
			cse4589_print_and_log("[%s:ERROR]\n", command_str);
			fflush(NULL);
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
			return;
		}
		
		

		for(p=ifa_addr;p!=NULL;p=p->ifa_add_next){	
		
			struct sockaddr *s=p->ifa_addr;
			
			if(s->sa_family==AF_INET){
				inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

				if(strcmp(IP,"127.0.0.1")!=0){	cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
				//cout<<IP<<endl
					fflush(NULL);
					cse4589_print_and_log("IP:%s\n",IP);
					fflush(NULL);
					cse4589_print_and_log("[%s:END]\n", command_str);
					fflush(NULL);
						
					break;
				}
			}
		
		}
	}
	
	
	
	bool isValidIP(char *IP){
		//referred from beej's example on how to use inet_pton(),inet_ntop() functions
        
        std::cout << "Checking if the IP is valid or not" << std::endl;
		struct sockaddr_in s;
		int i=inet_pton(AF_INET,IP,&(s.sin_addr));
		if(i==0){return false;}else{return true} }


    // Server() 
    
	Server(char *char_P){	//Referred from Beej's guide 
		//port=atoi(P);


		memset(&resources,0,sizeof(resources));
		
		resources.sin_family=AF_INET;
		stringstream convertport(char_P);

		
		flag_yes = 1;
		
		
		if(! (convertport>>port)){port=0;}

        resources.sin_addr.s_addr=htonl(INADDR_ANY);
		resources.sin_port=htons(port);
		
        /*
        Bind to the port
        
        */
		if(bind(fd_sock,(struct sockaddr*)&resources, sizeof(resources))==-1){
		    
		    // Cheking binding connections
			perror("bind error: ");
			exit(-1);
		}


		if((fd_sock=socket(AF_INET,SOCK_STREAM,0))==-1){
			perror("socket error: ");
			exit(-1);
		}
		
		/* 
		Listening to 
		
		the port
		*/
		if(listen(fd_sock,40)==-1){
		    // Checking list condition
			perror("listener error: ");
			exit(-1);
		}

        /*
        Set socket
        */
		if(setsockopt(fd_sock,SOL_SOCKET,SO_REUSEADDR,&flag_yes,sizeof(int))==-1){
			perror("sockopt error: ");
			exit(-1);
		}
		




		
	}
	
	// sendall()
	void all_Mess(int sock,char *catg,char* buffer){	
	    //Referred from beej's
	    
	    //partial send() example
		
		
		int size=strlen(catg);
		int n;
		int sum_total=0;
		
		
		send(sock,&size,sizeof(size),0);
		
		char *message=new char[1048];
		
		strcat(catg,buffer);
		strcpy(message,catg);
		
		//cout<<n<<"bytes were sent"<<endl<<flush;

		while(sum_total<size)
		{	//ut<<type<<endl<<flush;
		
		    // Enteringf 
		    // WHile loop
			n=send(sock,message+sum_total,size,0);
		
			if(n==-1){break;}
			
			sum_total+=n;
			size-=n;
		}
		
		/* Deleting 
		the current 
		message */
		
		delete[] message;
		
	}
	
	
	
    // recvmessage()
	 char* recv_Message(int fd_sock ,char *buffer){
         	//Referred    
         	// recvmessage
         	
            char *str=new char[1500];
            int size;
            
            if(recv(fd_sock,&size, sizeof(size),0)==0){	
			FD_CLR(fd_sock,&master);

			int i=0;
			while(i<listRemote.size()){
				if(listRemote[i].fd_sock==fd_sock){listRemote.erase(listRemote.begin()+i);}
            i++;
			}

			close(fd_sock);

		    }
		
		
            int total_val=0;
            int n;
            while(total_val<size){
                n=recv(fd_sock,str+total_val,size,0);

                if(n==-1){break;}

                total_val+=n;
                size-=n;
                
            }

            str[total]='\0';

	    return str;
        }

// Modified all these character later
	char *extractFirst(char *input){char *first=new char[30];
                int j=0;
                for(int i=0;input[i]!='\0'&&input[i]!=' ';i++,j++){first[j]=input[i];}
                first[j]='\0';
                return first;}

    char *extractSecond(char * input){char *second=new char[300];
                int j=0;
                int i;
                for(i=0;input[i]!=' '&&input[i]!='\0';i++);

                for(;isalnum(input[i])==0&&input[i]!='\0';i++);

                for(;input[i]!=' '&&input[i]!='\0';i++,j++)
                        second[j]=input[i];

                second[j]='\0';

                return second;
        }

        char *extractThird(char *input)
        {
                char *third=new char[1024];
                int j=0;
                int i;
                for(i=0;input[i]!=' '&&input[i]!='\0';i++);

                //for(;isalnum(input[i])==0&&input[i]!='\0';i++);

                i++;
		for(;input[i]!=' '&&input[i]!='\0';i++);
		
                //for(;isalnum(input[i])==0&&input[i]!='\0';i++);

		i++;
                for(;input[i]!='\0';i++,j++)
                        third[j]=input[i];

                third[j]='\0';

                return third;
        }

//  End here   
    
    // prepareBuffer
    char *getBuffer (int rind,char *message){
        
		std::cout << "Getiing Buffer" << std::endl;
		

		char* third=new char[1500];
		
		third=extractThird(message);	
		
		char *mod=new char[1024];	
		mod[0]=message[0];
		mod[1]=message[1];
		
		/*
		Concatinating the string
		and listRemote
		*/
		strcat(mod,listRemote[rind].IP);
		strcat(mod," ");
		strcat(mod,third);
		
		cout<<mod<<endl;	
		delete[] third;
		return mod;	 
	}

    
    
    // findClient
	int findClt(int socket){
		for(int i=0;i<listRemote.size();i++){
			if(listRemote[i].fd_sock == socket ){return i; }}
		return -1;}


	void removeFromBlock(int fd_sock, char *IP){	
	   
	    std::cout << "Entering remove block functions" << std::endl;
	    int index;
	    
	    index=findClt(fd_sock);
	    
		int eind;
	    
	    int i=0;
		while(i<listRemote[rind].BlockList.size()){
			
			if(strcmp(listRemote[index].BlockList[i].IP,IP)==0){	eind=i;	
				break;
			}}
        /*
        Setting up the remote List */
        
		listRemote[index].BlockList.erase(listRemote[index].BlockList.begin()+eind);}

	bool isBlocked(int send_sock,int rind){
		int index=findClt(send_sock);
		
		int i=0;
		while(i<listRemote[rind].BlockList.size()){
			if(strcmp(listRemote[index].IP,remoteList[rind].BlockList[i].IP)==0){return true;}}
		return false;
	}




// 	void printStatistics()
// 	{
// 		char hostname[200],service[100];
//                 sockaddr_in s;
//                 socklen_t size=sizeof(s);
// 		char log[20];
// 		cse4589_print_and_log("[%s:SUCCESS]\n","STATISTICS");
// 		for(int i=0;i<remoteList.size();i++)
// 		{ 
// 		     if(remoteList[i].reg==true)
// 			{
// 				inet_aton(remoteList[i].IP,&s.sin_addr);
//                         	s.sin_family=AF_INET;
//                         	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

// 				if(remoteList[i].log_status==true)
// 				{
// 					 strcpy(log,"logged-in");
// 					//cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname, remoteList[i].num_sent, remoteList[i].num_recv, "logged-in")
// 					//cout<<i+1<<" "<<remoteList[i].IP<<" "<<remoteList[i].num_sent<<" "<<remoteList[i].num_recv<<" "<<"logged-in"<<endl<<flush;

// 				}
// 				else
// 				{	strcpy(log,"logged-out");
// 					//cout<<i+1<<" "<<remoteList[i].IP<<" "<<remoteList[i].num_sent<<" "<<remoteList[i].num_recv<<" "<<"logged-out"<<endl<<flush;
// 				}

// 			cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname,remoteList[i].num_sent, remoteList[i].num_recv,log);
// 			fflush(NULL);
// 			}
// 		}
// 		cse4589_print_and_log("[%s:END]\n","STATISTICS");
// 	}
	
	
	void get_Statistics(){

        
        sockaddr_in s;
        socklen_t size=sizeof(s);
		
		char hostname[200];
		char service[100];
		
		char log[20];
		cse4589_print_and_log("[%s:SUCCESS]\n","STATISTICS");
		
		int i=0;
		while(i<listRemote.size()){ 
		     if(listRemote[i].reg==true){
				
				inet_aton(listRemote[i].IP,&s.sin_addr);
            	s.sin_family=AF_INET;
            	
            	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

				if(listRemote[i].log_status!=true){
					 strcpy(log,"logged-out");}
				else{	strcpy(log,"logged-in");}

			cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname,listRemote[i].num_sent, listRemote[i].num_recv,log);
			fflush(NULL);
			}
		}
		cse4589_print_and_log("[%s:END]\n","STATISTICS");
	}
	
	
	// printBlockList
	void pBloList(char *IP){
		
        sockaddr_in s;
        socklen_t size=sizeof(s);
                
        char hostname[200];
        char service[100];
		
		char command_str[]="BLOCKED";
		int index=findClt(IP);
		
		int i;
		vector<ListNode>tempBlock;
		

		
		
		if(listRemote[index].reg==true && index!=-1){	
		    cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
			fflush(NULL);
            
			for(i=0;i<listRemote[index].BlockList.size();i++){	 
			    int j=findClt(listRemote[index].BlockList[i].IP);
			   	tempBlock.push_back(listRemote[j]);}
		
			sort(tempBlock.begin(),tempBlock.end(),mycomp);
			
			int i=0;
			
			
			while(i<tempBlock.size()){
				inet_aton(tempBlock[i].IP,&s.sin_addr);
            	s.sin_family=AF_INET;
            	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",i+1,hostname,tempBlock[i].IP,tempBlock[i].port);
				fflush(NULL);
			}
			
			
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
		}else{	

			cse4589_print_and_log("[%s:ERROR]\n", command_str);
			fflush(NULL);
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
		}
		
	}


void checkSerevr(){
    
		FD_SET(STDIN,&master);
		FD_SET(fd_sock,&master);
    
		fdmax=fd_sock;

		char buf[500];
		char remoteIP[INET6_ADDRSTRLEN];
		
		int i;
		int index;
		
		int buflen;
    while(true){
        
        read_msg = master;
        
        int i =0;
        while(i<fdmax){
        if(FD_ISSET(i, &read_msg)){
            
            if(i==STDIN){
				char input[500]="";
				
				fgets(input,sizeof(input),stdin);
				input[strlen(input)-1]='\0';
					
					
				char *auth_first=extractFirst(input);
                    
                    if(strcmp(auth_first,"IP")==0){	
						myIP();
					}
					else if(strcmp(auth_first,"AUTHOR")==0){	
					    
					    char command_str[]="AUTHOR";
					    
						cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
						fflush(NULL);
						cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "nmanali");
						fflush(NULL);
						cse4589_print_and_log("[%s:END]\n", command_str);
						fflush(NULL);
					}
					else if(strcmp(auth_first,"LIST")==0){	
					    /* getting My 
					    list */
					    
					    char *get_p,l[500];
						get_p=getList(l);
						
						printList();
					}else if(strcmp(auth_first,"PORT")==0){	
						get_port_val();
					}
					else if(strcmp(auth_first,"STATISTICS")==0){
						get_Statistics();
					}
					else if(strcmp(auth_first,"BLOCKED")==0)
					{	char command_str[]="BLOCKED";

						char *IP=extractSecond(input);
						
						if(isValidIP(IP)==true){pBloList(IP);}
						else
						{
							cse4589_print_and_log("[%s:ERROR]\n", command_str);
							fflush(NULL);
							cse4589_print_and_log("[%s:END]\n", command_str);
							fflush(NULL);
						}
					}
					else if(strcmp(input,"EXIT")==0)
					{	
						close(sockfd);
						exit(-1);
					}	
				
			 }
			 else if(i==fd_sock){
			     //vector<struct sockaddr>list=myList();
				
				len_address=sizeof(remoteaddr);
				fd_new=accept(fd_sock,&remoteaddr,&len_address);
				
				
				struct ListNode temp_struct;
						 
						if(newfd==-1)
						{
							perror("accept: ");
							exit(-1);
						}
						else
						{	
							inet_ntop(AF_INET,&(((struct sockaddr_in*)&remoteaddr)->sin_addr),remoteIP,INET_ADDRSTRLEN);
							recv(fd_new,&temp.port,sizeof(int),0);
						    
							FD_SET(fd_new,&master);
							(fd_new>fdmax)?fdmax=newfd:fdmax;
							
							

							 
							 if((index=findClient(remoteIP))==-1)
							 {	strcpy(temp.IP,remoteIP);
								temp.sockfd=newfd;
								temp.num_sent=0;
								temp.num_recv=0;
								temp.reg=true;
								temp.log_status=true;
							 	remoteList.push_back(temp);
							 }
							else
							{	
								listRemote[index].reg=true;
								listRemote[index].log_status=true;
								
								strcpy(listRemote[index].IP,remoteIP);
								listRemote[index].fd_sock=fd_new;
								listRemote[index].port=temp.port;
							}

							char list[500],*l;
							l=getList(list);		

							char type[]="L ";
							/* 
							use sendALL function here 
							
							*/
							all_Mess(fd_new,type,list);
							
						}
					}			
					
					else{
						char* message;
						char response[1500];
						message=recv_Message(i,response);
						
						switch(message){
						case message[0]=='0':
							
							char type[1024]="0 ";
							char list[500];
							
							
							
							char* p=getList(list);

							all_Mess(i,type,p);
						
						case message[0]=='1':
							
							
							char m[1400];
							int send=findClt(i);
							
							listRemote[send].num_sent++;
	
	
							char *IP=extractSecond(message);
							int j=findClt(IP);
							
							
							char *third=extractThird(message);	
							
							if(j!=-1)
							{
								
								if(isBlocked(i,j)==false)
								{	char type[]="";
									
									strcpy(m,message);

									if(listRemote[j].log_status==true)
									{	
									    
									    
									    char *prep=getBuffer(send,m);
										all_Mess(listRemote[j].fd_sock,prep,type);
									    
									    char cmd[]="RELAYED";
										
										listRemote[j].num_recv++;
										//cout<<"In Relaying Send: "<<m<<endl;
										
							        cse4589_print_and_log("[%s:SUCCESS]\n",cmd);
	                                fflush(NULL);
                            		cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",remoteList[send].IP,remoteList[j].IP,third);
                            		fflush(NULL);
                    //message
                            		cse4589_print_and_log("[%s:END]\n",cmd);
                            		fflush(NULL);

										
									}
									else{
										struct message messBuf;
										
										//strcpy(mbuf.info,message);
										char *prep=getBuffer(send,message);
										strcpy(messBuf.info,prep);
										
										listRemote[j].buffer.push_back(messBuf);
										//cout<<"Am I here"<<endl<<flush;
									}
								}
								
							}else{
							    
							    
								strcpy(m,message);
								struct ListNode temp2;
								strcpy(temp2.IP,IP);
								temp2.reg=false;
								temp2.log_status=false;
								temp2.num_sent=0;
								temp2.num_recv=0;
								remoteList.push_back(temp2);
								int ind=findClient(temp2.IP);
								//cout<<ind<<" "<<remoteList[ind].IP<<"X"<<flush;
								if(ind!=-1)
								{	struct message mbuf;
									char *prep=getBuffer(send,message);
									strcpy(mbuf.info,prep);
									listRemote[ind].buffer.push_back(mbuf);
								}
								
								//cout<<"Am I here 2"<<endl<<flush;
							}

						case message[0]=='2':
						
														bool flag=false;
								int client;
								char command_str[]="RELAYED";
						
							    int send=findClt(i);
								listRemote[send].num_sent++;
								
								
								
                            int j =1;
							while(j<=fdmax){	
							    
							    char trailer[]="";
								client=findClt(j);
								
								
								if(FD_ISSET(j,&master)){	
									if(j!=i && j!=sockfd )
									{	
									
										if(listRemote[client].log_status==true && isBlocked(i,client) == false)
										{	all_Mess(j,message,trailer);
								 			flag=true;
											
											listRemote[client].num_recv++;
										}	
									}
								}
								
								else if(client!=-1 && isBlocked(i,client)==false){	
								    //BUffering 

									struct message m;
									strcpy(m.info,message);
									
									
									listRemote[client].buffer.push_back(m);
								}
								j++;
							}
							
							
							
							if(flag==true){
							    
							    char *third=extractThird(message);
								
								
								cse4589_print_and_log("[RELAYED:SUCCESS]\n");
								fflush(NULL);
								cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",remoteList[send].IP,third);
								fflush(NULL);
							//message
								cse4589_print_and_log("[RELAYED:END]\n",command_str);
								fflush(NULL);
							}

						
						case message[0]=='3':
						
							Block tempBlock;
							index=findClt(i);
				// 			//if(index==-1)
				// 			//cout<<"youre an invalid client"<<endl<<flush;
				// 			if(index!=-1)
				// 			{ char* second=extractSecond(message);
				// 			  strcpy(tempBlock.IP,second);
				// 			  remoteList[index].BlockList.push_back(tempBlock);

				// 			}
						

						case message[0]=='4':
						

							Block tempBlock;
							index=findClient(i);
					
							//if(index==-1)
							//cout<<"youre an invalid client"<<endl<<flush;
							if(index!=-1)
							{
								char* second=extractSecond(message);
								
								removeFromBlock(i,second);
							}
						
						case message[0]=='9':
						
							int ind=findClient(i);
							
							listRemote[ind].num_sent=0;
							listRemote[ind].num_recv=0;
							
							listRemote[ind].log_status=false;
							listRemote[ind].reg=false;

							
							FD_CLR(i,&master);
							
							close(i);

						
						case message[0]=='X':
						
							int ind=findClt(i);
							//cout<<remoteList[ind].IP<<" logged out"<<endl;
							listRemote[ind].log_status=false;
							
							FD_CLR(i,&master);
							close(i);		
	
						
						case message[0]=='B':
							int j=findClt(i);
							//cout<<"Am I getting this req "<<endl<<flush;
							//cout<<"Buffer Size"<<remoteList[j].buffer.size()<<endl<<flush;
							int c=-1;
							char *from,*message;
							char command_str[]="RELAYED";
							int size=listRemote[j].buffer.size();
							
							
												
							if(size==1)
							{	char type[1024]="F";
							
							
								all_Mess(listRemote[j].sockfd,type,listRemote[j].buffer[0].info);
								
								listRemote[j].num_recv++;
								from=extractSecond(listRemote[j].buffer[0].info);
								message=extractThird(listRemote[j].buffer[0].info);
								
								
								listRemote[j].buffer.erase(listRemote[j].buffer.begin());
							
								if(listRemote[j].buffer[0].info[0]=='2'){c=1;}
                                                                        else{
                                                                        c=0;}
							}
							
							else if(size>1)
							{	char type[1024]="B";
								
								all_Mess(remoteList[j].sockfd,type,remoteList[j].buffer[0].info);
								
								
															
								listRemote[j].num_recv++;
								listRemote[j].buffer.erase(remoteList[j].buffer.begin());
								
								if(listRemote[j].buffer[0].info[0]=='2')
									c=1;
								else
									c=0;
								
								from=extractSecond(remoteList[j].buffer[0].info);
								message=extractThird(remoteList[j].buffer[0].info);
								
	
						
							}
		
							else 
							{
								//size =0;
								char type[]="N";
								char resp[]=" ";
								all_Mess(listRemote[j].sockfd,type,resp);
							}

						 if(c==0) 
							{	//cout<<from<<endl;
								//char *third=extractThird(message);
								cse4589_print_and_log("[RELAYED:SUCCESS]\n");
								fflush(NULL);
                                cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from,remoteList[j].IP,message);
                                fflush(NULL);
                        //message
                                cse4589_print_and_log("[RELAYED:END]\n");
                                fflush(NULL);

							}

							else if(c==1)
							{
								//char *third=extractThird(message);
								cse4589_print_and_log("[RELAYED:SUCCESS]\n",command_str);
								fflush(NULL);
                                cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",from,message);
                                fflush(NULL);
                                //message
                                cse4589_print_and_log("[RELAYED:END]\n",command_str);
                                fflush(NULL);
                                //Broadcast

							}
	

						} delete[] message;
					}
            
        }
            
        
        i++;    
        }
        
    }

    
    
}


}
 return 0;    
}
 