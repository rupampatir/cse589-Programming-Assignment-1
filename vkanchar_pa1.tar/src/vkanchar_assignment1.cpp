/**
 * @mhniaz_assignment1
 * @author  Muhammad Hamza Niaz <mhniaz@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include<ifaddrs.h>
#include <vector>
#include <string>
#include <ctype.h>



#define HOSTNAME_LEN 128
#define PATH_LEN 256
#define TRUE 1
#define MSG_SIZE 256
#define BUFFER_SIZE 256
#define CMD_SIZE 100
#define BUFFER_SIZE 256
#define BACKLOG 5
#define STDIN 0

#include "../include/logger.h"


using namespace std;

struct clientInfo {
	int list_id;
	char *hostname;
	char *ipaddr;
	char *portNumber;
    bool isLoggedin;
};

vector<clientInfo> clientList;


char getIPaddress(char *port){
    struct addrinfo hints, *res, *p;
    int status;
    char ipstr;
    void *addr;

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if((status = getaddrinfo(NULL, port, &hints, &res)) != 0){
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
    }

    for(p = res; p != NULL; p = p->ai_next ){

        if(p->ai_family == AF_INET){
            struct sockaddr_in *ipv4 = (struct sockaddr_in *)p->ai_addr;
            addr = &(ipv4->sin_addr);

        }


    }
    inet_ntop(p->ai_family, addr, reinterpret_cast<char *>(ipstr), sizeof ipstr);
    freeaddrinfo(res);
    return ipstr;
}

void UDPsocket(){
	struct addrinfo ip_hints,*ip_res;
		struct sockaddr_in me;
		socklen_t mylen;
		char IP[2000];
		int tempfd;
		memset(&ip_hints,0,sizeof(ip_hints));
		ip_hints.ai_family=AF_INET;
		ip_hints.ai_flags=AF_UNSPEC;
		ip_hints.ai_socktype=SOCK_DGRAM;

		if(getaddrinfo("8.8.8.8","53",&ip_hints,&ip_res)==-1)
		{
			perror("ip getaddrinfo: ");
			exit(-1);
		}

		
		if((tempfd=socket(ip_res->ai_family,ip_res->ai_socktype,ip_res->ai_protocol))==-1)
		{
			perror("ip socket: ");
			exit(-1);
		}
	

		if(connect(tempfd,ip_res->ai_addr,ip_res->ai_addrlen)==-1)
		{
			perror("ip connect: ");
			exit(-1);
		}
		
		mylen=sizeof(me);

		if(getsockname(tempfd,(struct sockaddr*)&me,&mylen)==-1)
		{
			perror("getsock: ");
			exit(-1);
		}

		inet_ntop(AF_INET,&(me.sin_addr),IP,sizeof(IP));
		if(strcmp(IP,"127.0.0.1")!=0)
			printf("%s\n", IP);
		
		close(tempfd);
}

void getIPaddress(){
	struct ifaddrs *ifa,*p;
		char IP[2000];

		for(p=ifa;p!=NULL;p=p->ifa_next)
		{	
			struct sockaddr *s=p->ifa_addr;
			
			if(s->sa_family==AF_INET)
			{
				inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

				if(strcmp(IP,"127.0.0.1")!=0)
				{	cse4589_print_and_log("[%s:SUCCESS]\n", "IP");
					fflush(NULL);
					cse4589_print_and_log("IP:%s\n",IP);
					fflush(NULL);
					cse4589_print_and_log("[%s:END]\n", "IP");
					fflush(NULL);
					//cout<<IP<<endl	
					break;
				}
			}
		
		}
}

char *extractCommand(char *input){
      char *cmd=new char[30];
                int j=0;
                for(int i=0;input[i]!='\0'&&input[i]!=' ';i++,j++){
                    cmd[j]=input[i];
                }   
                cmd[j]='\0';
    return cmd;
}

char* extractIPaddr(char *input){
    char *ipaddr = new char[300];
    char space = ' ';
    string arr = input;
    size_t found = arr.find(space);
    int j = 0;
    int i = 0;
    for(i = 0;input[i]!=' '&& input[i]!='\0'; i++){
        i++;
    }
    for(;isalnum(input[i])==0&&input[i]!='\0';i++);
    for(;input[i]!=' '&&input[i]!='\0';i++,j++){
        ipaddr[j] = input[i];
    }
    ipaddr[j] = '\0';
    return ipaddr;
}

char *extractPort(char *input){
    char *port = new char[1024];
    int j = 0;
    int i = 0;
    for(i=0;input[i]!=' '&&input[i]!='\0';i++);
    i++;
	for(;input[i]!=' '&&input[i]!='\0';i++);
    i++;
    for(;input[i]!='\0';i++,j++){
        port[j] = input[i];
    }
    port[j] = '\0';
    return port;

}

bool checkIPaddr(char *IP){
    struct sockaddr_in s;
		
		int i=inet_pton(AF_INET,IP,&(s.sin_addr));
		
		if(i==0)
		return false;

		return true;
}
bool checkPort(char *Portent){
		bool flag=true;

		for(int i=0;i<strlen(Portent);i++)
			if(isdigit(Portent[i])==0)
				{ flag=false; break;}

		if(flag==false)
			return false;

		long v=atol(Portent);
		if(v<0 ||  v>65335)
			flag=false;

		if(flag==false)
			return false;
		return true;

	}


void list(){

}


int connect_to_host(char *server_ip, char* server_port)
{
	int fdsocket;
	struct addrinfo hints, *res;

	/* Set up hints structure */	
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	/* Fill up address structures */	
	if (getaddrinfo(server_ip, server_port, &hints, &res) != 0)
		perror("getaddrinfo failed");

	/* Socket */
	fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if(fdsocket < 0)
		perror("Failed to create socket");
	
	/* Connect */
	if(connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0)
		perror("Connect failed");
	
	freeaddrinfo(res);

	return fdsocket;
}

void login(char *client_ip, char *client_port){

}




void client(char *portNumber){
    int server_socket, head_socket, selret, sock_index, fdaccept=0, caddr_len;
    struct sockaddr_in client_addr;
    struct addrinfo hints, *res, newHints;
    fd_set master_list, watch_list;
    char hostname[200], service[100];
    
    

    /* Set up hints structure */
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    /* Fill up address structures */
    if (getaddrinfo(NULL, portNumber, &hints, &res) != 0)
        perror("getaddrinfo failed");

    /* Socket */
    server_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if(server_socket < 0)
        perror("Cannot create socket");

    /* Bind */
    if(bind(server_socket, res->ai_addr, res->ai_addrlen) < 0 )
        perror("Bind failed");

    freeaddrinfo(res);

    /* Listen */
    if(listen(server_socket, BACKLOG) < 0)
        perror("Unable to listen on port");

    /* ---------------------------------------------------------------------------- */

    /* Zero select FD sets */
    FD_ZERO(&master_list);
    FD_ZERO(&watch_list);

    /* Register the listening socket */
    FD_SET(server_socket, &master_list);
    /* Register STDIN */
    FD_SET(STDIN, &master_list);

    head_socket = server_socket;

    while(TRUE){
        memcpy(&watch_list, &master_list, sizeof(master_list));

        //printf("\n[PA1-Server@CSE489/589]$ ");
        //fflush(stdout);

        /* select() system call. This will BLOCK */
        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
        if(selret < 0)
            perror("select failed.");

        /* Check if we have sockets/STDIN to process */
        if(selret > 0){
            /* Loop through socket descriptors to check which ones are ready */
            for(sock_index=0; sock_index<=head_socket; sock_index+=1){

                if(FD_ISSET(sock_index, &watch_list)){

                    /* Check if new command on STDIN */
                    if (sock_index == STDIN){
                        char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);

						int len = strlen(cmd);
						cmd[len-1]='\0';

                        memset(cmd, '\0', CMD_SIZE);
                        if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to cmd
                            exit(-1);

						
                        //printf("\nI got: %s\n", cmd);

                        //vector<string> CMDS = extractFirstCmds(cmd);
						int lent = strlen(cmd);
						cmd[lent-1]='\0';


                        //Process PA1 commands here ...
                        if(strcmp(cmd, "AUTHOR") == 0){
                            cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
                            printf("HELLO");
                            cse4589_print_and_log("I,  mhniaz, have read and understood the course academic integrity policy.\n");
                            cse4589_print_and_log("[AUTHOR:END]\n");
                        }

                        if(strcmp(cmd, "IP") == 0){
                            cse4589_print_and_log("[IP:SUCCESS]");
                            char ip_addr = getIPaddress(portNumber);
                            cse4589_print_and_log("IP:%s", ip_addr);
                            cse4589_print_and_log("[IP:END]");
                        }
                        if(strcmp(cmd, "PORT") == 0){
                            cse4589_print_and_log("[PORT:SUCCESS]");
                            cse4589_print_and_log("[PORT:%s]", portNumber);
                            cse4589_print_and_log("[PORT:END]");
                        }

                        if(strcmp(cmd, "LOGIN") == 0){
                            memset(&newHints,0,sizeof(newHints));
                            int id = 0;
                            newHints.ai_family=AF_INET;
							newHints.ai_socktype=SOCK_STREAM;
                            char *ipaddr = extractIPaddr(cmd);
                            char *port = extractPort(cmd);
                            if(checkIPaddr(ipaddr) && checkPort(port)){
                                cse4589_init_log("[LOGIN:SUCCESS]");
                                struct clientInfo client;
                                client.ipaddr = ipaddr;
                                client.list_id = id;
                                id++;
                                client.portNumber = portNumber;
                                sockaddr_in s;
                                socklen_t size=sizeof(s);
                                getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);
                                client.hostname = hostname;
                                clientList.push_back(client);
                            }
                        }

                        if(strcmp(cmd, "LIST") == 0){
                            for(int i = 0; i < clientList.size(); i++){
                                printf("%-5d%-35s%-20s%-8d\n", clientList[i].list_id, clientList[i].hostname, clientList[i].ipaddr, clientList[i].portNumber);
                            }
                            
                        }
                        

                        free(cmd);
                    }
                        /* Check if new client is requesting connection */
                    else if(sock_index == server_socket){
                        caddr_len = sizeof(client_addr);
                        fdaccept = accept(server_socket, (struct sockaddr *)&client_addr,
                                          reinterpret_cast<socklen_t *>(&caddr_len));
                        if(fdaccept < 0)
                            perror("Accept failed.");

                        printf("\nRemote Host connected!\n");

                        /* Add to watched socket list */
                        FD_SET(fdaccept, &master_list);
                        if(fdaccept > head_socket) head_socket = fdaccept;
                    }
                        /* Read from existing clients */
                    else{
                        /* Initialize buffer to receieve response */
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
                        memset(buffer, '\0', BUFFER_SIZE);

                        if(recv(sock_index, buffer, BUFFER_SIZE, 0) <= 0){
                            close(sock_index);
                            printf("Remote Host terminated connection!\n");

                            /* Remove from watched list */
                            FD_CLR(sock_index, &master_list);
                        }
                        else {
                            //Process incoming data from existing clients here ...

                            printf("\nClient sent me: %s\n", buffer);
                            printf("ECHOing it back to the remote host ... ");
                            if(send(fdaccept, buffer, strlen(buffer), 0) == strlen(buffer))
                                printf("Done!\n");
                            fflush(stdout);
                        }

                        free(buffer);
                    }
                }
            }
        }
    }

}


/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	if (strcmp(argv[1], "s") == 0){
        //server(argv[2]);
        printf("server under construction!");
    }
    if (strcmp(argv[1], "c") == 0){
        client(argv[2]);
    }
	return 0;
}




