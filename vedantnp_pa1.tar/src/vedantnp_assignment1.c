#include <stdio.h>
#include <stdlib.h>
#include "../include/logger.h"
#include "../include/global.h"

#include <sys/socket.h>
#include <sys/un.h>
#include <strings.h>
#include <ifaddrs.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>

#define MSG_SIZE 256
#define BUFFER_SIZE 256
#define CMD_SIZE 100
#define BUFFER_SIZE 256

void start_client(int port_c);
void start_server(int server_port);
char* blocked_client_list(char *cmd);
int host_conn(char *server_ip, int server_port, int c_port);
struct message_c block_unblock_client(char *msg,int server,struct message_c data);
struct message_c send_to_client(char *msg,int server,struct message_c data);
int client_login(char *msg,int server,int port_c);
void list_in_order();
bool socket_binder(int c_port);
void display_STATISTICS();
void delete_entry(int delete_info);
void list_display();
unsigned short int get_port();
bool check_validIP(char *ip);
char* get_IP();
//int new_client_request(int server_socket,struct sockaddr_in client_addr,int head_socket,struct message_server server_data,fd_set master_list);


char * ubit_name ="vedantnp";
fd_set client_master_list;
int csocket_head;
fd_set client_watch_list;
int fdsocket;
bool loggedin;
int csock_idx;

struct message_c
{
	char cmd[20];
	char ip[24];
	char info[256];
};

struct blocklist_c
{
	char buffer[1024];
	char C_ip[24];
	char ip1[24];
	char ip2[24];
	char ip3[24];
	char ip4[24];
	int C_id;
}*client_ptr[5];

struct list_info
{
	int fd_socket;
	int rcvd_msg;
	int list_idx;
	char host_name[40];
	char state[20];
	char list_ip[24];
	int list_port;
	int send_msg;
}*list_ptr[5];

struct message_server
{
	char info[256];
	char cmd[20];
	char sender_ip[24];
	struct list_info list_row;
};

//struct message_server server_data;
/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/*Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	struct list_info hosts[6];
	int port = atoi(argv[2]);
	//int fdsocket;
	if(argc != 3) 
	{
		//printf("Enter Valid Arguments");
		exit(-1);
	}
	if(*argv[1]=='c'){
		start_client(port);
	}
	else if(*argv[1]=='s'){
		start_server(port);
	}
	else
	{
		//printf("Exiting the application");
		exit(-1);
	}
	return 0;
}
//client side
void start_client(int port_c)
{
	int server=0,selret,j=0;
	struct message_c data;
	bool port_binded=socket_binder(port_c);
	loggedin=false;
	if(port_binded==false){
		//printf("\nclient not bind");
		exit(-1);
	}
	FD_ZERO(&client_master_list); 
    FD_ZERO(&client_watch_list);
    FD_SET(0, &client_master_list);

    csocket_head=0;
	while(1){
		fflush(stdout);	
		FD_ZERO(&client_master_list);
    	FD_ZERO(&client_watch_list);

    	FD_SET(0, &client_master_list);
		FD_SET(server, &client_master_list);
		
		csocket_head=server;

		memcpy(&client_watch_list,&client_master_list,sizeof(client_master_list));
        selret = select(csocket_head + 1, &client_watch_list,NULL,NULL,NULL);
        if(select(csocket_head + 1, &client_watch_list,NULL,NULL,NULL)<0){
			//printf("\nSelect failed");
            exit(-1);
        }
        if(select(csocket_head+1,&client_watch_list,NULL,NULL,NULL)>0){
            for(csock_idx=0; csock_idx<=csocket_head; csock_idx+=1){
                if(FD_ISSET(csock_idx, &client_watch_list)){
                	 if (csock_idx==0){
				        char *msg = (char*) malloc(sizeof(char)*MSG_SIZE);
				    	memset(msg,'\0',MSG_SIZE);
						char *input = fgets(msg,MSG_SIZE-1,stdin);
						if(input==NULL){ 
							exit(-1);
						}
						msg[strlen(msg)-1] = '\0';
						if((strcmp(msg,"AUTHOR"))==0){
							cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
							cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n",ubit_name);
							cse4589_print_and_log("[AUTHOR:END]\n");
						}
						else if((strcmp(msg,"IP"))==0){
							char *buf = get_IP();
							if(buf!=NULL){
    							cse4589_print_and_log("[IP:SUCCESS]\n");
        						cse4589_print_and_log("IP:%s\n",buf);
								cse4589_print_and_log("[IP:END]\n");
							}
							else{
								cse4589_print_and_log("[IP:ERROR]\n");
								cse4589_print_and_log("[IP:END]\n");
							}
						}
						else if((strcmp(msg,"PORT"))==0){
							unsigned short int p = get_port();
							if(p==-1){
								cse4589_print_and_log("[PORT:ERROR]\n");
								cse4589_print_and_log("[PORT:END]\n");
							}
							else{
								cse4589_print_and_log("[PORT:SUCCESS]\n");
								cse4589_print_and_log("PORT:%d\n",p);
								cse4589_print_and_log("[PORT:END]\n");
							}
						}
						else if((strcmp(msg,"LIST"))==0&&loggedin==true){
							strcpy(data.cmd,"LIST");
							ssize_t sending = send(server,&data,sizeof(data), 0);
							if(sending==sizeof(data)){
								cse4589_print_and_log("[LIST:SUCCESS]\n");
							}
							else{
								cse4589_print_and_log("[LIST:ERROR]\n");
							}
							fflush(stdout);
						}
						else if((strncmp(msg,"LOGIN",5))==0){
							server = client_login(msg,server,port_c);
							csocket_head = server;
							fflush(stdout);
						}
						else if((strcmp(msg,"REFRESH"))==0&&loggedin==false){  
				        	cse4589_print_and_log("[REFRESH:SUCCESS]\n"); 
				        	cse4589_print_and_log("[REFRESH:END]\n");                 
				        }
				        else if((strncmp(msg,"SEND",4))==0&&loggedin==true){
							data = send_to_client(msg,server,data);
							fflush(stdout);
				        }
						else if((strncmp(msg,"BROADCAST",9))==0&&loggedin==true){
							strcpy(data.cmd,"BROADCAST");
							char message[256];
							int k=10;j=0;
							while(msg[k]!='\0'){
								message[j]=msg[k];
								k=k+1;
								j=j+1;
							}
							strcpy(data.info,message);
							ssize_t sending = send(server,&data,sizeof(data), 0);
							if(sending==sizeof(data)){
								cse4589_print_and_log("[BROADCAST:SUCCESS]\n");
							}
							cse4589_print_and_log("[BROADCAST:END]\n");
							fflush(stdout);	
						}
						else if((strncmp(msg,"BLOCK",5))==0&&loggedin==true){
							data = block_unblock_client(msg,server,data);
							fflush(stdout);
						}
						else if((strncmp(msg,"UNBLOCK",7))==0&&loggedin==true)
						{
							data = block_unblock_client(msg,server,data);
							fflush(stdout);
						}
						else if((strcmp(msg,"LOGOUT"))==0&&loggedin==true){
							strcpy(data.cmd,"LOGOUT");
							ssize_t sending = send(server,&data,sizeof(data), 0);
							if(sending==sizeof(data)){
								printf("[LOGOUT:SUCCESS]\n");
								loggedin=false;
								bool port_binded=socket_binder(port_c);
								server=close(server);
							}
							cse4589_print_and_log("[LOGOUT:END]\n");	
						}
						else if((strncmp(msg,"SENDFILE",8))==0&&loggedin==true){
						}
						else if((strcmp(msg,"EXIT"))==0){
							close(server);
							cse4589_print_and_log("[EXIT:SUCCESS]\n");
							cse4589_print_and_log("[EXIT:END]\n");
							exit(0);
						}
                    }
                    else{
        				struct message_server rcv_s;
        				memset(&rcv_s,'\0',sizeof(rcv_s));
						if(recv(server, &rcv_s,sizeof(rcv_s),0)>= 0){
							if(strcmp(rcv_s.cmd,"MSG")==0)
							{
								cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
								cse4589_print_and_log("msg from:%s\n[msg]:%s\n",rcv_s.sender_ip,rcv_s.info);
								cse4589_print_and_log("[RECEIVED:END]\n");
							}
							else if(strcmp(rcv_s.cmd,"LIST")==0){	
								cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",rcv_s.list_row.list_idx,rcv_s.list_row.host_name,rcv_s.list_row.list_ip,rcv_s.list_row.list_port);
							}
							else if(strcmp(rcv_s.cmd,"LOGLIST")==0){	
								cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",rcv_s.list_row.list_idx,rcv_s.list_row.host_name,rcv_s.list_row.list_ip,rcv_s.list_row.list_port);
							}
							else if(strcmp(rcv_s.cmd,"LISTOVER")==0){	
								cse4589_print_and_log("[LIST:END]\n");
							}
							else if(strcmp(rcv_s.cmd,"LOGLISTOVER")==0){	
								cse4589_print_and_log("[LOGIN:END]\n");
							}
							else if(strcmp(rcv_s.cmd,"MSG_SENT")==0){	
								cse4589_print_and_log("[SEND:SUCCESS]\n");
								cse4589_print_and_log("[SEND:END]\n");
							}
							else if(strcmp(rcv_s.cmd,"MSG_SENT_FAIL")==0){	
								cse4589_print_and_log("[SEND:ERROR]\n");
								cse4589_print_and_log("[SEND:END]\n");
							}
							fflush(stdout);
						}
                    } 
                    fflush(stdout);	
                }
            }
        }	
	}
}
//server side
void start_server(int server_port)
{
	fd_set master_list, watch_list;
	int server_socket,head_socket,selret;
	int clientaddr_len;
	int fdaccept=0,send_socket=0;
	int sock_index;

	struct message_server server_data;
	struct list_info send_list;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	struct message_c rcv_data;

	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	fdsocket=server_socket;
    if(server_socket < 0){
		//printf("\nSocket creation failed");
		exit(-1);
    }
    else{
    	//printf("\nSocket created successfully");
    }
	bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(server_port);

	int socket_bind = bind(server_socket,(struct sockaddr *)&server_addr,sizeof(server_addr));
    if(socket_bind < 0 ){
    	//printf("\nBinding failed");
		exit(-1);
    }
    else{
    	//printf("\nBinded to socket\n");
    }
	int socket_listen = listen(server_socket,5);
    if(socket_listen< 0){
		//printf("\nNot Listening");
		exit(-1);
    }
    else{
    	//printf("\nListening to socket\n");
    }
	int i=0;
	int num_of_hosts = 5;
	while(i<num_of_hosts){
    	list_ptr[i]=(struct list_info *)malloc(sizeof(struct list_info));
    	client_ptr[i]=(struct list_info *)malloc(sizeof(struct blocklist_c));
		client_ptr[i]->C_id=0;
		list_ptr[i]->list_idx=0; 
		i = i + 1;
	}
    for(i=0;i<num_of_hosts;i++){
		strcpy(client_ptr[i]->ip1,"null");
		strcpy(client_ptr[i]->ip2,"null");
		strcpy(client_ptr[i]->ip3,"null");
		strcpy(client_ptr[i]->ip4,"null");
    }
    FD_ZERO(&master_list); 
    FD_ZERO(&watch_list);
    FD_SET(server_socket, &master_list);
    FD_SET(0, &master_list);

    head_socket = server_socket;

    while(1){
		fflush(stdout);	
        memcpy(&watch_list, &master_list, sizeof(master_list));
        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
        if(select(head_socket+1, &watch_list, NULL, NULL, NULL)<0){
            //printf("\nSelect Failed");
            exit(1);
        }
        if(select(head_socket + 1, &watch_list, NULL, NULL, NULL) > 0){
        	 for(sock_index=0; sock_index<=head_socket; sock_index+=1){
                fflush(stdout);
                memset(&server_data, '\0', sizeof(server_data));//mera
                if(FD_ISSET(sock_index, &watch_list)){
	                if (sock_index == 0){
	                	char *cmd = (char*)malloc(sizeof(char)*CMD_SIZE);
	                	memset(cmd,'\0',CMD_SIZE);
						char *newline = fgets(cmd,CMD_SIZE-1,stdin);
						if(newline== NULL){
							//printf("\nError");
							exit(-1);
						}
						cmd[strlen(cmd)-1]='\0';
						if((strcmp(cmd,"AUTHOR"))==0)
						{
							cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
							cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n",ubit_name);
							cse4589_print_and_log("[AUTHOR:END]\n");
						}
	                    else if((strcmp(cmd,"IP"))==0)
	                    {
							char *buf = get_IP();
							if(buf!=NULL){
    							cse4589_print_and_log("[IP:SUCCESS]\n");
        						cse4589_print_and_log("IP:%s\n",buf);
								cse4589_print_and_log("[IP:END]\n");
							}
							else{
								cse4589_print_and_log("[IP:ERROR]\n");
								cse4589_print_and_log("[IP:END]\n");
							}
	                    }
	                    else if((strcmp(cmd,"PORT"))==0)
	                    {
							unsigned short int p = get_port();
							if(p==-1){
								cse4589_print_and_log("[PORT:ERROR]\n");
								cse4589_print_and_log("[PORT:END]\n");
							}
							else{
								cse4589_print_and_log("[PORT:SUCCESS]\n");
								cse4589_print_and_log("PORT:%d\n",p);
								cse4589_print_and_log("[PORT:END]\n");
							}
	                    }
	                    else if((strcmp(cmd,"LIST"))==0){
							int i=0,j,num_of_hosts=5;
	                    	list_in_order();
	                    	cse4589_print_and_log("[LIST:SUCCESS]\n");
	                        list_display();
	                        cse4589_print_and_log("[LIST:END]\n");
	                    }
	                    else if((strcmp(cmd, "STATISTICS"))==0){
	                    	cse4589_print_and_log("[STATISTICS:SUCCESS]\n");
	                        display_STATISTICS();
	                        cse4589_print_and_log("[STATISTICS:END]\n");
	                    }
	                    else if((strncmp(cmd,"BLOCKED",7))==0)
	                    {
							cmd = blocked_client_list(cmd);				
	                    }
						free(cmd);
	                }
	                else if(sock_index==server_socket){
						//head_socket = new_client_request(server_socket,client_addr,head_socket,server_data,master_list);
	                    char ip[INET_ADDRSTRLEN];
						char host[1024];
						clientaddr_len = sizeof(client_addr);
	                    fdaccept = accept(server_socket,(struct sockaddr *)&client_addr,&clientaddr_len);
	                    if(fdaccept<0){
							//printf("\nAccept failed");
							exit(-1);
	                    }
	                    inet_ntop(AF_INET,&client_addr.sin_addr.s_addr,ip, INET_ADDRSTRLEN);                      
						ntohs(client_addr.sin_port);
	                    FD_SET(fdaccept,&master_list);
	                    if(fdaccept>head_socket) {
                            head_socket = fdaccept;
                        }
	                    getnameinfo((struct sockaddr *)&client_addr,clientaddr_len,host, sizeof(host),0,0,0);
	                    //printf("\nhost name is:-%s", host);
	                    //printf("\nPort number is:-%d", ntohs(client_addr.sin_port));
	                    int n=0;
						while((client_ptr[n]->C_id)!=0){
                        	n++;
                        }
						client_ptr[n]->C_id=n+1;
						strcpy(client_ptr[n]->C_ip,ip);
                        int m=0;
                        while((list_ptr[m]->list_idx)!=0){
                        	m++;
                        }
                        list_ptr[m]->list_idx=m+1;
                        list_ptr[m]->list_port=ntohs(client_addr.sin_port);
                        list_ptr[m]->fd_socket=fdaccept;
                        list_ptr[m]->send_msg=0;
                        list_ptr[m]->rcvd_msg=0;
                        strcpy(list_ptr[m]->state,"logged-in");
                        strcpy(list_ptr[m]->list_ip,ip);
                        strcpy(list_ptr[m]->host_name,host);

                        //send list of currently loged in clients to the client
                        list_in_order();
						//INFORMING THAT LOGIN IS OVER
						strcpy(server_data.cmd,"LOGLISTOVER");
						ssize_t sending = send(fdaccept,&server_data,sizeof(server_data), 0);
						if(sending==sizeof(server_data)){
								//printf("Done!\n");
	                        }
							fflush(stdout);	
	                }
	                else{
	                	memset(&rcv_data,'\0',sizeof(rcv_data));

	                    if(recv(sock_index,&rcv_data,sizeof(rcv_data), 0) <= 0){
	                    	delete_entry(sock_index);
	                        //printf("Remote Host terminated connection!\n");
	                        FD_CLR(sock_index,&master_list);
	                    }
	                    else {
	                    	if((strcmp(rcv_data.cmd,"SEND"))==0){
	                    		char sender_ip[24],receivers_ip[24];
								i = 0;
								int num_of_hosts = 5;

								while(i<num_of_hosts){
									if(list_ptr[i]->fd_socket==sock_index){	
										strcpy(sender_ip,list_ptr[i]->list_ip);
										list_ptr[i]->send_msg+=1;
										break;
									}
									i++;			
								}
								i = 0;
								while(i<num_of_hosts){
									if((strcmp(list_ptr[i]->list_ip,rcv_data.ip)) == 0){	
										send_socket=list_ptr[i]->fd_socket;
										list_ptr[i]->rcvd_msg+=1;
										break;
									}
									i++;	
								}
								strcpy(receivers_ip,rcv_data.ip);
								int p=0;
								bool flag=true;

								while(client_ptr[p]->C_id!=0){
									if(strcmp(sender_ip,client_ptr[p]->C_ip)==0){
										break;	
									}
									p++;
								}
								if(strcmp(client_ptr[p]->ip1,receivers_ip)==0||strcmp(client_ptr[p]->ip2,receivers_ip)==0||strcmp(client_ptr[p]->ip3,receivers_ip)==0||strcmp(client_ptr[p]->ip4,receivers_ip)==0){
									flag=false;
								}
								if(flag==true){		
									strcpy(server_data.cmd,"MSG");
									strcpy(server_data.sender_ip,sender_ip);
									strcpy(server_data.info,rcv_data.info);

									ssize_t sending = send(send_socket,&server_data,sizeof(server_data), 0);

									if(sending==sizeof(server_data)){
										cse4589_print_and_log("[RELAYED:SUCCESS]\n");
										cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",sender_ip, receivers_ip, rcv_data.info);				 
										strcpy(server_data.cmd,"MSG_SENT");
										ssize_t sending = send(sock_index,&server_data,sizeof(server_data), 0);
				                        if(sending == sizeof(server_data)){
				                        	//printf("Done!\n");	
				                        }
			                        }
			                        else{
			                        	cse4589_print_and_log("[RELAYED:ERROR]\n");
			                        	strcpy(server_data.cmd,"MSG_SENT_FAIL");
										ssize_t sending = send(sock_index,&server_data,sizeof(server_data), 0);
				                        if(sending==sizeof(server_data)){
				                        	//printf("Done!\n");	
				                        }
			                        }
			                        cse4589_print_and_log("[RELAYED:END]\n");
			                    }
			                    else{
			                    	//printf("this client blocked this ip");
			                    	cse4589_print_and_log("[RELAYED:SUCCESS]\n");
									cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",sender_ip, receivers_ip, rcv_data.info);
			                    	strcpy(server_data.cmd,"MSG_SENT");
									ssize_t sending = send(sock_index,&server_data,sizeof(server_data), 0);
			                        if(sending==sizeof(server_data))
			                        {
			                        	//printf("\nsent msg to sender that msg has been delivered!\n");	
			                        }
			                        cse4589_print_and_log("[RELAYED:END]\n");
			                    }
	                    	}
	                    	else if((strcmp(rcv_data.cmd,"BROADCAST"))==0){
		                    	char sender_ip[24];
								i = 0;
								int num_of_host = 5;
								while(i<num_of_host){
									if(list_ptr[i]->fd_socket==sock_index){	
										strcpy(sender_ip,list_ptr[i]->list_ip);
										list_ptr[i]->send_msg+=1;
										break;
									}
									i = i + 1;
								}
								i = 0;
								while(i<num_of_host){
									if(list_ptr[i]->list_idx!=0&&(strcmp(list_ptr[i]->list_ip,sender_ip))!=0){
										send_socket=list_ptr[i]->fd_socket;
										strcpy(server_data.cmd,"MSG");
										strcpy(server_data.sender_ip,sender_ip);
										strcpy(server_data.info,rcv_data.info);
										if(send(send_socket, &server_data, sizeof(server_data), 0) == sizeof(server_data)){
		                        			cse4589_print_and_log("[RELAYED:SUCCESS]\n");
											cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",sender_ip, rcv_data.info);
		                        		}
		                        		else{
		                        			cse4589_print_and_log("[RELAYED:ERROR]\n");
		                        		}	
		                        		cse4589_print_and_log("[RELAYED:END]\n");	
									}
									i = i + 1;
								}				
	                    	}
	                    	else if((strcmp(rcv_data.cmd,"BLOCK"))==0){
	                    		char sender_ip[24];
								for(int i=0;i<5;i++){
									if(list_ptr[i]->fd_socket==sock_index){	
										strcpy(sender_ip,list_ptr[i]->list_ip);
										break;
									}	
								}
								int z=0;

								while((client_ptr[z]->C_id)!=0){
					            	//printf("\ninside server block");
							        if(strcmp(rcv_data.ip,client_ptr[z]->C_ip)==0){
										break;
									}
									z++;
					         	}
					         	//printf("\n CURRENT Z VALUE IS %d",&z);
					         	//printf("\n CURRENT IP1 VALUE IS %s",client_ptr[z]->ip1);

								if(strcmp(client_ptr[z]->ip1,"null")==0){
									strcpy(client_ptr[z]->ip1,sender_ip);
								}
								else if(strcmp(client_ptr[z]->ip2,"null")==0){
									strcpy(client_ptr[z]->ip2,sender_ip);
								}
								else if(strcmp(client_ptr[z]->ip3,"null")==0){
									strcpy(client_ptr[z]->ip3,sender_ip);
								}
								else if(strcmp(client_ptr[z]->ip4,"null")==0){
									strcpy(client_ptr[z]->ip4,sender_ip);
								}
	                    	}
	                    	else if((strcmp(rcv_data.cmd,"UNBLOCK"))==0){
	                    		char sender_ip[24];
								for(int i=0;i<5;i++){
									if(list_ptr[i]->fd_socket==sock_index){	
										strcpy(sender_ip,list_ptr[i]->list_ip);
										break;
									}	
								}
								int z=0;
								while((client_ptr[z]->C_id)!=0){
					            	//printf("\ninside server  block");
							        if(strcmp(rcv_data.ip,client_ptr[z]->C_ip)==0){
										break;
									}
									z++;
					         	}
					         	if(strcmp(client_ptr[z]->ip1,sender_ip)==0){
									strcpy(client_ptr[z]->ip1,"null");
								}
								else if(strcmp(client_ptr[z]->ip2,sender_ip)==0){
									strcpy(client_ptr[z]->ip2,"null");
								}
								else if(strcmp(client_ptr[z]->ip3,sender_ip)==0){
									strcpy(client_ptr[z]->ip3,"null");
								}
								else if(strcmp(client_ptr[z]->ip4,sender_ip)==0){
									strcpy(client_ptr[z]->ip4,"null");
								}	
	                    	}
	                    	else if((strcmp(rcv_data.cmd,"LIST"))==0){
	                    		for(int i=0;i<5;i++){
									if(list_ptr[i]->list_idx!=0){	
										printf("%-5d%-35s%-20s%-8d\n", list_ptr[i]->list_idx, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port,list_ptr[i]->fd_socket);
										
										send_list.list_idx=list_ptr[i]->list_idx;
										strcpy(send_list.host_name,list_ptr[i]->host_name);
										strcpy(send_list.list_ip,list_ptr[i]->list_ip);
										send_list.list_port=list_ptr[i]->list_port;

										strcpy(server_data.cmd,"LIST");
										server_data.list_row=send_list;
										if(send(sock_index, &server_data, sizeof(server_data), 0) == sizeof(server_data)){
											//printf("Done!\n");
			                            }	
									}
								}
								strcpy(server_data.cmd,"LISTOVER");
								if(send(sock_index, &server_data, sizeof(server_data), 0) == sizeof(server_data)){
									printf("Done!\n");
	                            }
	                            fflush(stdout);		
	                    	}
	                    	else if((strcmp(rcv_data.cmd,"LOGOUT"))==0){
								for(int i=0;i<5;i++){
									if(list_ptr[i]->fd_socket==sock_index){	
										strcpy(list_ptr[i]->state,"logged-out");
										close(sock_index);
										FD_CLR(sock_index, &master_list);
										list_in_order();
									}	
								}
	                    	}
							fflush(stdout);
	                    }
	             	}   
	         	}
            }
        }
    }
}
char* blocked_client_list(char *cmd){
	char ip[24];
	int k=8,i=0;
	while(cmd[k]!='\0'){	
		ip[i]=cmd[k];
		i++;
		k++;
	}
	ip[i]='\0';
	if(!check_validIP(ip)){
		cse4589_print_and_log("[BLOCKED:ERROR]\n");
	}
	else{
		cse4589_print_and_log("[BLOCKED:SUCCESS]\n");
		int o=0;
		while(client_ptr[o]->C_id!=0){
			if(strcmp(ip,client_ptr[o]->C_ip)==0){
				break;	
			}
			o++;
		}	
		for(int q = 1;q<5;q++){
			if(q==1){
				if(strcmp(client_ptr[o]->ip1,"null")!=0){
				for(int i=0;i<5;i++){
					if((strcmp(list_ptr[i]->list_ip,client_ptr[o]->ip1)) == 0){	
						cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", &q, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port);
						break;
					}									                   	
				}	
			}
		}
			else if(q==2){
		if(strcmp(client_ptr[o]->ip2,"null")!=0){
			for(int i=0;i<5;i++){
				if((strcmp(list_ptr[i]->list_ip,client_ptr[o]->ip2)) == 0){	
					cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", &q, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port);
					break;
				}									                   	
			}	
		}
			}
			else if(q==3){
		if(strcmp(client_ptr[o]->ip3,"null")!=0){
			for(int i=0;i<5;i++){
				if((strcmp(list_ptr[i]->list_ip,client_ptr[o]->ip3)) == 0){	
					cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", &q, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port);
					break;
				}									                   	
			}	
		}
			}
			else if(q==4){
		if(strcmp(client_ptr[o]->ip4,"null")!=0){
			for(int i=0;i<5;i++){
				if((strcmp(list_ptr[i]->list_ip,client_ptr[o]->ip4)) == 0){	
					cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", &q, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port);
					break;
				}									                   	
			}	
		}
			}
		}
	}
	cse4589_print_and_log("[BLOCKED:END]\n");
	return cmd;
}
int host_conn(char *server_ip, int server_port, int c_port){
    int len;
    struct sockaddr_in remote_server_addr;

    bzero(&remote_server_addr, sizeof(remote_server_addr));
    remote_server_addr.sin_family = AF_INET;
    inet_pton(AF_INET, server_ip, &remote_server_addr.sin_addr);
    remote_server_addr.sin_port = htons(server_port);
    if(connect(fdsocket, (struct sockaddr*)&remote_server_addr, sizeof(remote_server_addr)) < 0){
		////printf("Connection failed");
		exit(-1);
    }
    else{
    	//printf("\nLogged in\n");
    }
    return fdsocket;
}
struct message_c block_unblock_client(char *msg,int server,struct message_c data){
	char ip[24];
	int i=0;
	if((strncmp(msg,"BLOCK",5))==0){
		int k = 6;
		while(msg[k]!='\0'){	
			ip[i]=msg[k];
			i++;
			k++;
		}
		ip[i]='\0';
		if(check_validIP(ip)){	
			strcpy(data.cmd,"BLOCK");
			strcpy(data.ip,ip);
			printf("Entered ip is:- %s\n",&ip);
			if(send(server,&data, sizeof(data), 0) == sizeof(data)){
				cse4589_print_and_log("[BLOCK:SUCCESS]\n");
			}
		}
		else{
			cse4589_print_and_log("[BLOCK:ERROR]\n");
		}
		cse4589_print_and_log("[BLOCK:END]\n");
		return data;
	}
	else if(strncmp(msg,"UNBLOCK",7)==0){
		int k = 8;
		strcpy(data.cmd,"UNBLOCK");
		while(msg[k]!='\0'){	
			ip[i]=msg[k];
			i++;
			k++;
		}
		ip[i]='\0';
		if(check_validIP(ip)){
			strcpy(data.ip,ip);
			//printf("Entered ip is:- %s\n",&ip);
			if(send(server, &data, sizeof(data), 0) == sizeof(data)){
				cse4589_print_and_log("[UNBLOCK:SUCCESS]\n");
			}
		}
		else{
			cse4589_print_and_log("[UNBLOCK:ERROR]\n");
		}
		cse4589_print_and_log("[UNBLOCK:END]\n");
		return data;
	}
}
struct message_c send_to_client(char *msg,int server,struct message_c data){
	char cip[24],message[256];
	int k=5,j=0;
	while(msg[k]!=' '){
		cip[j]=msg[k];
		j++;
		k++;
	}
	cip[j]='\0';
	if(!check_validIP(cip)){
		cse4589_print_and_log("[SEND:ERROR]\n");
		cse4589_print_and_log("[SEND:END]\n");
	}
	else{
		j=0;
		k=k+1;
		while(msg[k]!='\0'){
			message[j]=msg[k];
			k++;
			j++;
		}
		message[j]='\0';
		k=0,j=0;
		strcpy(data.cmd,"SEND");
		strcpy(data.ip,cip);
		strcpy(data.info,message);
		if(send(server, &data, sizeof(data),0) == sizeof(data)){
			//cse4589_print_and_log("[SEND:SUCCESS]\n");
		}
	}
	return data;
}

int client_login(char *msg,int server,int port_c){
	char ip[24],portv[32];
	int j=0,k=6;
	while(msg[k]!=' '){
		ip[j] = msg[k];
		k = k + 1;
		j = j + 1;
	}
	ip[j]='\0';
	if(!check_validIP(ip)){
		cse4589_print_and_log("[LOGIN:ERROR]\n");
		cse4589_print_and_log("[LOGIN:END]\n");
	}
	else{
		j = 0;
		k = k + 1;
		while(msg[k]!='\0'){
			portv[j] = msg[k];
			k = k + 1;
			j = j + 1;
		}
		portv[j]='\0';
		int p_error=0;
		for (int i=0;i<strlen(portv);i++){
			if (!isdigit(portv[i]))
			{
				//printf ("Entered input is not a number\n");
				p_error=1;
			}
		}
		if(p_error!=1){
			int l=1;
			int u=65535;
			if(l<= atoi(portv)&&atoi(portv)<= u)
			{	/*connect to server*/
				server=host_conn(ip, atoi(portv), port_c);
				FD_SET(server, &client_master_list);
				csocket_head=server;
			    loggedin=true;
				cse4589_print_and_log("[LOGIN:SUCCESS]\n");
			}
			else{
				cse4589_print_and_log("[LOGIN:ERROR]\n");
				cse4589_print_and_log("[LOGIN:END]\n");
			}
		}
		else{
			cse4589_print_and_log("[LOGIN:ERROR]\n");
			cse4589_print_and_log("[LOGIN:END]\n");
		}
	}
	return server;	
}
void list_in_order(){
	int num_of_hosts = 5;
	int i,j,key;
	for(int i = 1;i<num_of_hosts;i++){
		key = list_ptr[i]->list_port;
		j = i - 1;
		while(j>=0&&list_ptr[j]->list_port>key&&list_ptr[j+1]->list_idx!=0){
				int temp_port;
				int tlist_id;
				int temp_send_msg;
				char temp_list_host_name[40];
				char temp_state[20];
				char temp_list_ip[24];
				int temp_fd_socket;
				int temp_rcv_msg;
				
				temp_port=list_ptr[j]->list_port;
				temp_fd_socket=list_ptr[j]->fd_socket;
				temp_rcv_msg=list_ptr[j]->rcvd_msg;
				temp_send_msg=list_ptr[j]->send_msg;

				strcpy(temp_list_host_name,list_ptr[j]->host_name);
				strcpy(temp_list_ip,list_ptr[j]->list_ip);
				strcpy(temp_state,list_ptr[j]->state);
	
				list_ptr[j]->list_port=list_ptr[j+1]->list_port;
				list_ptr[j]->send_msg=list_ptr[j+1]->send_msg;
				list_ptr[j]->fd_socket=list_ptr[j+1]->fd_socket;
				list_ptr[j]->rcvd_msg=list_ptr[j+1]->rcvd_msg;
				strcpy(list_ptr[j]->host_name,list_ptr[j+1]->host_name);
				strcpy(list_ptr[j]->list_ip,list_ptr[j+1]->list_ip);
				strcpy(list_ptr[j]->state,list_ptr[j+1]->state);
				
				list_ptr[j+1]->rcvd_msg=temp_rcv_msg;
				list_ptr[j+1]->send_msg=temp_send_msg;
				list_ptr[j+1]->list_port=temp_port;
				list_ptr[j+1]->fd_socket=temp_fd_socket;
				strcpy(list_ptr[j+1]->host_name,temp_list_host_name);
				strcpy(list_ptr[j+1]->list_ip,temp_list_ip);
				strcpy(list_ptr[j+1]->state,temp_state);
				j = j - 1;
		}
		list_ptr[j+1]->list_port = key;
	}
}
bool socket_binder(int c_port){
	struct sockaddr_in my_addrs;
	int optval=1;
	fdsocket = socket(AF_INET, SOCK_STREAM, 0);
    my_addrs.sin_family=AF_INET;
    my_addrs.sin_addr.s_addr=INADDR_ANY;
    my_addrs.sin_port=htons(c_port);

    if(fdsocket < 0){
       //printf("\nFailed to create socket");
       return false;
    }
    setsockopt(fdsocket, SOL_SOCKET,SO_REUSEPORT,&optval,sizeof(optval));
    if(bind(fdsocket, (struct  sockaddr*)&my_addrs,sizeof(struct sockaddr_in))!=0){
   		//printf("\nError in binding client port\n");
    	return false;
    }
    else if(bind(fdsocket, (struct  sockaddr*)&my_addrs,sizeof(struct sockaddr_in))!=0){
    	//printf("\nclient binded to port correctly\n");
    	return true;
    }
}
void display_STATISTICS(){
	int i = 0;
	int num_of_hosts = 5;
	while(i<num_of_hosts){
		if(list_ptr[i]->list_idx!=0){	
			cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", list_ptr[i]->list_idx, list_ptr[i]->host_name, list_ptr[i]->send_msg, list_ptr[i]->rcvd_msg,list_ptr[i]->state);
		}
		i = i + 1;
	}
}
void delete_entry(int delete_info){
	int delete=0;
	int last=0;
	int i,num_of_hosts = 5;
	for(i=0;i<num_of_hosts;i++){
		if(list_ptr[i]->fd_socket==delete_info)
		{	
			delete=i;
			break;
		}
	}
	for(int i=delete;i<num_of_hosts;i++){
		last=last+1;
		if(list_ptr[i+1]->list_idx!=0){
			strcpy(list_ptr[i]->host_name,list_ptr[i+1]->host_name);
			strcpy(list_ptr[i]->list_ip,list_ptr[i+1]->list_ip);
			list_ptr[i]->list_port=list_ptr[i+1]->list_port;
			list_ptr[i]->fd_socket=list_ptr[i+1]->fd_socket;
			list_ptr[i]->rcvd_msg=list_ptr[i+1]->rcvd_msg;
			list_ptr[i]->send_msg=list_ptr[i+1]->send_msg;
			strcpy(list_ptr[i]->state,list_ptr[i+1]->state);
		}	

	}
	list_ptr[last]->list_idx=0;
}
void list_display(){
	int i = 0;
	int num_of_hosts = 5;
	while(i<num_of_hosts){
		if(list_ptr[i]->list_idx!=0){	
			cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_ptr[i]->list_idx, list_ptr[i]->host_name, list_ptr[i]->list_ip, list_ptr[i]->list_port);
		}
		i = i + 1;
	}
}
unsigned short int get_port(){
	struct sockaddr_in portvalue;
	socklen_t len=sizeof(portvalue);
	unsigned short int port_val;
	int name = getsockname(fdsocket,(struct sockaddr *)&portvalue, &len);
	port_val = ntohs(portvalue.sin_port);
	if(name<0){
		return -1;
	}
	else{
		return port_val;
	}
}

bool check_validIP(char *ip){
	struct sockaddr_in temp;
	char *check[5];
	int flag = 0;
	check[0] = "128.205.36.46";
	check[1] = "128.205.36.33";
	check[2] = "128.205.36.34";
	check[3] = "128.205.36.35";
	check[4] = "128.205.36.36";

	if(!strcmp(check[0],ip)){
		flag = 1;
	}
	else if(!strcmp(check[1],ip)){
		flag = 1;
	}
	else if(!strcmp(check[2],ip)){
		flag = 1;
	}		
	else if(!strcmp(check[3],ip)){
		flag = 1;
	}
	else if(!strcmp(check[4],ip)){
		flag = 1;
	}
	if(flag==0){
		return false;
	}
	else{
		return true;
	}	
}

char* get_IP(){
    const char* google_dns_server = "8.8.8.8";
    int dns_port = 53;
    struct sockaddr_in serv,name;
	socklen_t namelen = sizeof(name);
	char *buffer=malloc(100);
    int sock = socket(AF_INET,SOCK_DGRAM,0);
    if(socket(AF_INET, SOCK_DGRAM,0) < 0){
		//printf("\nSocket error");
		exit(-1);
    }  
    memset(&serv,0,sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr(google_dns_server);
    serv.sin_port = htons(dns_port);
 
    int err = connect(sock,(const struct sockaddr*)&serv,sizeof(serv));
    err = getsockname(sock,(struct sockaddr*)&name,&namelen);
         
    const char* p = inet_ntop(AF_INET,&name.sin_addr,buffer,100);
	//size_t i = 0;
	// while(buffer[i]!='\0'){
	// }
    if(p != NULL){
		////printf("\n%s",buffer);
		return buffer;
    }
    else{
		//printf("\nNULL");
		return NULL;
    }
    close(sock);
}