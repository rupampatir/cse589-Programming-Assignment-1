/**
* @pchopde_assignment1
* @author  Priyank Pramod Chopde <pchopde@buffalo.edu>
* @version 1.0
*
* @section LICENSE
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License as
* published by the Free Software Foundation; either version 2 of
* the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* General Public License for more details at
* http://www.gnu.org/copyleft/gpl.html
*
* @section DESCRIPTION
*
* This file contains the client.
*/

#include <iostream>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <strings.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <typeinfo> 
#include <algorithm>
#include <vector>

#include "../include/global.h"
#include "../include/logger.h"

using namespace std;

#define TRUE 1
#define MSG_SIZE 256
#define BUFFER_SIZE 256
#define CMD_SIZE 100
#define STDIN 0

/*
To keep in mind while implementing 
A client should not accept any other command, except LOGIN, EXIT, IP, PORT, and AUTHOR, or receive packets, unless it is successfully logged in to the server.

*/
int connect_to_host(char *server_ip, char *server_port, char* argv);
char* getIP_client(char* argv);
void send_to_host(int fdsocket, data_struct* data);
int ip_check(char *ip);
int port_check(char *port);

int getClientIndexFromIP();
void addBlockedClient(char* clientIp, char* block_ip);
// client_struct client_s;

void addtolist(data_struct server_data);
void printLoggedInC();
void clearlist();

	client_info_struct client_info;
	vector<client_info_struct> active_clients_info;


int client(char *argv)
{
	fd_set client_master_list, client_watch_list;
	data_struct send_data;
	// client_struct client_info;
	// vector<client_struct> active_clients_info;

	int fdsocket=0; //socket for server messages
	int index = 1; //The index track of incoming list
	int selret,client_head_socket,client_sock_index, iterator = 0;
	char *server_ip, *server_port;
	char *client_ip, *client_port;
	char *block_ip; //For blocking 
	int logged_in = 0; // To keep track if the client is logged in or not
	// int server=0;

	FD_ZERO(&client_master_list);
	FD_ZERO(&client_watch_list); //watch_list
	FD_SET(STDIN, &client_master_list); ///FD_SET(fileno(stdin), &watch_list);
	client_head_socket=0;

	while(TRUE)
	{
		// fflush(stdout);
		FD_ZERO(&client_master_list);
		FD_ZERO(&client_watch_list); //watch_list

		FD_SET(STDIN, &client_master_list);
		FD_SET(fdsocket, &client_master_list);
		client_head_socket=fdsocket;

		memcpy(&client_watch_list, &client_master_list, sizeof(client_master_list));
		
		printf("\n[PA1-Client@CSE489/589]$ ");
		fflush(stdout);
		/* select() system call. This will BLOCK */
		selret = select(client_head_socket+1, &client_watch_list,NULL,NULL,NULL);
		if(selret<0)
		{
			cout<<"Select failed\n";
			exit(-1);
		}
		if(selret>0)
		{
			/* Loop through socket descriptors to check which ones are ready */
			for(client_sock_index=0;client_sock_index<=client_head_socket;client_sock_index+=1)
			{
				if(FD_ISSET(client_sock_index, &client_watch_list))
				{
					if(client_sock_index == STDIN)
					{
						char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
						memset(cmd, '\0', CMD_SIZE);
						if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to cmd
							exit(-1);
										
						// printf("\nI got: %s\n", cmd);
						// fgets(cmd, CMD_SIZE-1, stdin);
						char* param;

						if(strcmp(cmd,"AUTHOR\n")==0)
						{
							param=strtok(cmd," ");
							cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
							cse4589_print_and_log("I, pchopde, have read and understood the course academic integrity policy.\n");
							cse4589_print_and_log("[AUTHOR:END]\n");
							// break;
						}
						else if(strcmp(cmd,"IP\n")==0)
						{
							param=strtok(cmd," ");
							// cout<<"entering getIP()\n";
							char* ip_addr = getIP_client(argv);
							cse4589_print_and_log("[IP:SUCCESS]\n");
							cse4589_print_and_log("IP:%s\n", ip_addr);
							cse4589_print_and_log("[IP:END]\n");

							// cout<<"getIP() done\n";
						}
						else if(strcmp(cmd,"PORT\n")==0)
						{
							param=strtok(cmd," ");
							cse4589_print_and_log("[PORT:SUCCESS]\n");
							cse4589_print_and_log("PORT:%s\n", argv);
							cse4589_print_and_log("[PORT:END]\n");
						}
						else if(strcmp(cmd,"LIST\n")==0)
						{
							param=strtok(cmd," ");
							// cout<<"entering getIP()\n";
							cse4589_print_and_log("[LIST:SUCCESS]\n");
							printLoggedInC();
							cse4589_print_and_log("[LIST:END]\n");

							// cout<<"getIP() done\n";
						}
									
						else if(strncmp(cmd,"LOGIN",5)==0)
						{
							param = strtok(cmd," ");
							// printf("Into login command\n");
							int param_counter=0;
							while (param != NULL)
							{
								param_counter+=1;
								if(param_counter == 2)
								{
									server_ip = param;
								}
								if(param_counter==3)
								{
									param[strcspn(param,"\n")]='\0';
									server_port = param;
								}
								// printf("%s\n", param);
								param = strtok(NULL," ");
							}
							// printf("%s\t%s\n",server_ip,server_port);
							char *temp_ip = server_ip;
							char *temp_port = server_port;
							if(ip_check(server_ip) && port_check(temp_port))
							{
								// cout<<"Valid IP and Port\n";
								fdsocket = connect_to_host(server_ip,server_port,argv);
								logged_in =1;
								cse4589_print_and_log("[LOGIN:SUCCESS]\n");
								strcpy(send_data.cmd,"SENDLIST");
								char* ip_addr = getIP_client(argv);
								strcpy(send_data.ip,ip_addr);
								// cout<<"Requesting list to server\n";
								if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
								{
									// cout<<"List requested\n";
								}
								cse4589_print_and_log("[LOGIN:END]\n");
								// cout<<logged_in;
							}
							else
							{
								cse4589_print_and_log("[LOGIN:ERROR]\n");
								cse4589_print_and_log("[LOGIN:END]\n");
							}
							// fdsocket = connect_to_host(server_ip,server_port,argv);
							fflush(stdout);
							// send_to_host(fdsocket);
						}
						else if(strncmp(cmd,"SEND",4)==0 && logged_in ==1)
						{
							// cout<<"Into send\n";
							// cout<<cmd;
							// param=strtok(cmd," ");
							char client_ip[32];
							char message_to_be_sent[256];
							int cmd_iterator = 5;
							iterator = 0;

							while(cmd[cmd_iterator]!= ' ')
							{
								client_ip[iterator]=cmd[cmd_iterator];
								cmd_iterator+=1;
								iterator+=1;
							}
							client_ip[iterator]='\0';
							// cout<<"The IP is\n";
							// cout<<client_ip;
							int checkInList = 0;
							for(int i =0;i<active_clients_info.size(); i++)
							{
								if(strcmp(active_clients_info[i].ip,client_ip)==0)
								{
									// cout<<"Client exists, should set the flag and send\n";
									checkInList=1;
								}

							}
							if(ip_check(client_ip)&& checkInList)
							{
								iterator = 0;
								int message_iterator = cmd_iterator+1;
								while(cmd[message_iterator]!='\0')
								{
									message_to_be_sent[iterator] = cmd[message_iterator];
									message_iterator+=1;
									iterator+=1;
								}
								message_to_be_sent[iterator]='\0';
								// cout<<"The message is\n";
								// cout<<message_to_be_sent;
								strcpy(send_data.cmd,"SEND");
								strcpy(send_data.ip,client_ip);
								strcpy(send_data.message,message_to_be_sent);
								// cout<<"Sending to server\n";
								//Check if the client is in the list already

								//If not print send error

								if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
								{
									// cout<<"Client send executed\n";
									cse4589_print_and_log("[SEND:SUCCESS]\n");
									cse4589_print_and_log("[SEND:END]\n");
								}
								else
								{
									cout<<"Send was not executed\n;";
								}
								// send_to_host(fdsocket, &send_data);
							}
							else
							{
								cse4589_print_and_log("[SEND:ERROR]\n");
								cse4589_print_and_log("[SEND:END]\n");
							}
							fflush(stdout);
						}
						else if(strncmp(cmd,"BLOCK",5)==0 && logged_in == 1)
						{
							cout<<"Into blocked\n";
							// cse4589_print_and_log("[BLOCK:SUCCESS]\n");
							// cse4589_print_and_log("[BLOCK:END]\n");
							param = strtok(cmd," ");
							int param_counter=0;
							while (param != NULL)
							{
								param_counter+=1;
								if(param_counter == 2)
								{
									param[strcspn(param,"\n")]='\0';
									block_ip = param;
								}
								param = strtok(NULL," ");
							}
							// cout<<ip_check(block_ip);

							strcpy(send_data.cmd,"BLOCK");
							strcpy(send_data.ip,block_ip);

							// Check if the client is in the active clients 
							// int checkInBlockList = 0;
							// for(int i =0;i<active_clients_info.size(); i++)
							// {
							// 	if(strcmp(active_clients_info[i].ip,client_ip)==0)
							// 	{
							// 		cout<<"Client exists, should set the flag and send\n";
							// 		// checkInBlockList=1;
							// 	}
							// }

							// strcpy(send_data.message,message_to_be_sent);
							// cout<<"Sending to server\n";
							if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data) && ip_check(block_ip))
							{
								cout<<"Client send executed\n";
								if(ip_check(block_ip)==1)
								{
								cse4589_print_and_log("[BLOCK:SUCCESS]\n");
								cse4589_print_and_log("[BLOCK:END]\n");
								}
							}
							else{
								cse4589_print_and_log("[BLOCK:ERROR]\n");
								cse4589_print_and_log("[BLOCK:END]\n");
							}
							// cout<<"IP to be blocked:"<<block_ip;
							
							/*Call your function here, the variable block_ip is (char*)*/
							/*Remember the client should be logged in before it can enter BLOCKED command*/
						}
						else if(strncmp(cmd,"UNBLOCK",7)==0 && logged_in ==1)
						{
							
							// cout<<"Into unblocked\n";
							param = strtok(cmd," ");
							int param_counter=0;
							while (param != NULL)
							{
								param_counter+=1;
								if(param_counter == 2)
								{
									param[strcspn(param,"\n")]='\0';
									block_ip = param;
								}
								param = strtok(NULL," ");
							}
							// block_ip[strlen(block_ip)-1] = '\0';
							// cse4589_print_and_log("DEBUG: IP to be unblocked:");
							// cse4589_print_and_log(block_ip);
							// cse4589_print_and_log("\n");
							strcpy(send_data.cmd,"UNBLOCK");
							strcpy(send_data.ip,block_ip);
							// strcpy(send_data.message,message_to_be_sent);
							// cout<<"Sending to server\n";
							if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
							{
								cout<<"Client send executed\n";
								if(ip_check(block_ip)==1)
								{
								cse4589_print_and_log("[BLOCK:SUCCESS]\n");
								cse4589_print_and_log("[BLOCK:END]\n");
								}
							}
							else{
								cse4589_print_and_log("[BLOCK:ERROR]\n");
								cse4589_print_and_log("[BLOCK:END]\n");								
							}
							// cout<<"IP to be blocked:"<<block_ip;
							
							/*Call your function here, the variable block_ip is (char*)*/
							/*Remember the client should be logged in before it can enter BLOCKED command*/
						}
						else if ((strncmp(cmd,"BROADCAST",9))==0 && logged_in == 1)
						{
							char message_to_be_sent[256];
							int cmd_iterator = 10;
							iterator = 0;
							while(cmd[cmd_iterator]!='\0')
							{
								message_to_be_sent[iterator]=cmd[cmd_iterator];
								iterator+=1;
								cmd_iterator+=1;
							}
							message_to_be_sent[iterator]='\0';
							// cout<<message_to_be_sent;
							strcpy(send_data.cmd,"BROADCAST");
							strcpy(send_data.message,message_to_be_sent);
							cout<<"Sending to server\n";
							if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
							{
								cse4589_print_and_log("[BROADCAST:SUCCESS]\n");
							}
							else
							{
								cse4589_print_and_log("[BROADCAST:ERROR]\n");
							}
							cse4589_print_and_log("[BROADCAST:END]\n");
							fflush(stdout);
						}
						else if ((strncmp(cmd,"LOGOUT",6))==0 && logged_in == 1)
						{
							// cout<<"Into LOGOUT\n";
							strcpy(send_data.cmd,"LOGOUT");
							// cout<<"Sending logout to server\n";
							if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
							{
								cse4589_print_and_log("[LOGOUT:SUCCESS]\n");
							}
							// close(fdsocket);
							logged_in =0;
							cse4589_print_and_log("[LOGOUT:END]\n");
							fflush(stdout);
						}
						else if ((strncmp(cmd,"EXIT",4))==0)
						{
							// cout<<"Into EXIT\n";
							strcpy(send_data.cmd,"EXIT");
							// cout<<"Sending exit to server\n";
							if(logged_in==1)
							{
								if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
								{
									// cse4589_print_and_log("[EXIT:SUCCESS]\n");
								}
							}

							close(fdsocket);
							logged_in =0;
							cse4589_print_and_log("[EXIT:SUCCESS]\n");
							cse4589_print_and_log("[EXIT:END]\n");
							fflush(stdout);
							exit(0);
						}
						else if ((strncmp(cmd,"REFRESH",4))==0 && logged_in == 1)
						{
							// cout<<"Into REFRESH\n";
							// strcpy(send_data.cmd,"REFRESH");
							// cout<<"Calling clean vector\n";
							clearlist();
							// cout<<"Sending sendlist to server\n";
							strcpy(send_data.cmd,"SENDLIST");
							char* ip_addr = getIP_client(argv);
							strcpy(send_data.ip,ip_addr);
							// cout<<"Requesting list to server\n";
							if(send(fdsocket, &send_data,sizeof(send_data),0)==sizeof(send_data))
							{
								// cout<<"List requested\n";
							}
							fflush(stdout);
						}
					}
					else
					{
						// cout<<"Into receive state\n";
						data_struct server_data;
						memset(&server_data, '\0', sizeof(server_data));

						// char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
						// memset(buffer, '\0', BUFFER_SIZE);

						if(recv(fdsocket, &server_data, sizeof(server_data), 0) >= 0)
						{
							// printf("Server responded: %s", server_data.message);
							// fflush(stdout);//There will be no waiting for messages
							if(strcmp(server_data.cmd,"MSG")==0)
							{	// format("msg from:%s\n[msg]:%s\n",client-ip,msg);
								cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
								cse4589_print_and_log("msg from:%s\n[msg]:%s",server_data.ip,server_data.message);
								cse4589_print_and_log("[RECEIVED:END]\n");
							}
							else if(strcmp(server_data.cmd,"MSG_SENT")==0)
							{	
								// cse4589_print_and_log("[SEND:SUCCESS]\n");
								// cse4589_print_and_log("[SEND:END]\n");
							}
							else if(strcmp(server_data.cmd,"MSG_SENT_FAIL")==0)
							{	cse4589_print_and_log("[SEND:ERROR]\n");
								cse4589_print_and_log("[SEND:END]\n");
							}
							else if(strcmp(server_data.cmd,"SENDLIST")==0)
							{
								// cout<<"Active clients\n";
								// cout<<index<<" "<<server_data.ip<<" "<<server_data.hostname<<" "<<server_data.port;
								addtolist(server_data);
								
							// {	// format("msg from:%s\n[msg]:%s\n",client-ip,msg);
							// 	cout<<"REceiving login list\n";
							// 	recv(fdsocket, &active_clients, sizeof(active_clients))
							// 	cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
							// 	cse4589_print_and_log("msg from:%s\n[msg]:%s\n",server_data.ip,server_data.message);
							// 	cse4589_print_and_log("[RECEIVED:END]\n");
							}
							fflush(stdout);
						}
					}
					fflush(stdout);
				}
			}
		}
	}
}	

int ip_check(char *ip) //To check if the IP is valid
{
	struct sockaddr_in temp;
	int result= inet_pton(AF_INET, ip, &temp.sin_addr);
	if(result==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int port_check(char *port) //To check if the port is valid
{
	char *ptr = port;
	strcat(ptr, "\0");
	if(port == NULL)
		return 0;
	while(ptr!=NULL)
	{
		if(atoi(ptr)>0 && atoi(ptr)<=65535)
			return 1;
		else
			return 0;
	}
}

void send_to_host(int fdsocket, data_struct* data)
{		
	int server = fdsocket;
	while(TRUE)
	{
		printf("\n[PA1-Client@CSE489/589]$ ");

		
		printf("\nSending it to the remote server ... ");
		if(send(server, &data, sizeof(data), 0) == sizeof(data))
			printf("Done!\n");
		fflush(stdout);
		
		/* Initialize buffer to receieve response */
		data_struct server_data;
		memset(&server_data, '\0', sizeof(server_data));
		
		if(recv(server, &server_data, sizeof(server_data), 0) >= 0)
		{
			printf("Server responded: %s", server_data.message);

			fflush(stdout);//There will be no waiting for messages
		}
	}
}


char* getIP_client(char *port)
{
	// printf("Into getIP\n");
	struct addrinfo hints, *res;
	struct sockaddr_in google, client;
	int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if(udp_socket < 0){
		perror("Cannot create socket");
	}
	memset(&google, 0, sizeof(google));
	google.sin_family = AF_INET;
	google.sin_port = htons(53);
	google.sin_addr.s_addr = inet_addr("8.8.8.8");

	if(connect(udp_socket, (struct sockaddr *)&google, sizeof(google)) < 0){
		perror("Connect failed");
	}
	socklen_t clientlen = sizeof(client);
	if(getsockname(udp_socket, (struct sockaddr *)&client, &clientlen)<0){
		perror("couldn't get ip address");
	}
	char buffer[50];
	const char* ip = inet_ntop(AF_INET, &client.sin_addr, buffer, 80);
	char* ipstr = new char[50];
	strcpy(ipstr, ip);
	if(ip==NULL)
	{
		cse4589_print_and_log("[IP:ERROR]\n");
	}
	// else
	// {
	// 	cse4589_print_and_log("[IP:SUCCESS]\n");
	// }
	return ipstr;
}

int connect_to_host(char *server_ip, char* server_port, char* argv)
{
	int s;
	int fdsocket;
	struct addrinfo hints, *res;
	struct sockaddr_in serveraddr;
	struct sockaddr_in clientaddr;
	
	int client = socket(AF_INET, SOCK_STREAM, 0);

	/*Setting server socket details*/
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = INADDR_ANY;
	serveraddr.sin_port = htons(atoi(server_port));
	serveraddr.sin_addr.s_addr = inet_addr(server_ip);

	/*Setting client socket details*/
	clientaddr.sin_family = AF_INET;
	clientaddr.sin_addr.s_addr = INADDR_ANY;
	clientaddr.sin_port = htons(atoi(argv));

	if(bind(client, (struct sockaddr*) &clientaddr, sizeof(struct sockaddr_in))==0)
	{}
	else
	{	
		printf("Unable to bind\n");
	}
	socklen_t addr_size = sizeof(serveraddr);
	int con = connect(client, (struct sockaddr*) &serveraddr, sizeof(serveraddr));
	// if (con == 0)
    //     printf("Client Connected\n");
    // else
    //     printf("Error in Connection\n");


	return client;
}



void clearlist()
{
	// cout<<"Into clearlist\n";
	active_clients_info.clear();
}

void addtolist(data_struct server_data)
{
	// cout<<"Into addtolist\n";
	// cout<<" "<<server_data.ip<<" "<<server_data.hostname<<" "<<server_data.port;
	strcpy(client_info.ip, server_data.ip);
	strcpy(client_info.hostname,server_data.hostname);
	client_info.port = server_data.port;
	active_clients_info.push_back(client_info);
	// printLoggedInC();
}

bool comparePort(client_info_struct c1, client_info_struct c2)
{
    return (c1.port < c2.port);
}
void printLoggedInC()
{	
	// cout<<"Into printlist\n";
	sort(active_clients_info.begin(), active_clients_info.end(), comparePort);
	for(int i=0; i<active_clients_info.size(); i++){
		// cout<<active_clients_info[i].ip<<":"<<active_clients_info[i].port<<":"<<active_clients_info[i].fdsocket<<"\n";
		int list_id = i+1;
		char hostname[1024];
		strcpy(hostname,active_clients_info[i].hostname);
		char ip_addr[32];
		strcpy(ip_addr,active_clients_info[i].ip);
		int port_num = active_clients_info[i].port;
		cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, hostname, ip_addr, port_num);
	}
} 

