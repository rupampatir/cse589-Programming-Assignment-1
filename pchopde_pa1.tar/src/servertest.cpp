/**
 * @pchopde_assignment1
 * @author  Priyank Pramod Chopde <pchopde@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 * // setenv LD_LIBRARY_PATH /util/gcc-7.2.0/lib64/ [use this command to run if it fails with GLIBCXX_3.4.21 not found error] 
 * reference - https://stackoverflow.com/questions/44205687/glibcxx-3-4-21-not-found-on-centos-7
 */
#include <iostream>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <strings.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

#include "../include/global.h"
#include "../include/logger.h"

using namespace std;

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int servertest()
{
	// /*Init. Logger*/
	// cse4589_init_log(argv[2]);

	// /* Clear LOGFILE*/
    // fclose(fopen(LOGFILE, "w"));

	/*Start Here*/

	//Server tasks
	// Create a socket
	int listening = socket(AF_INET, SOCK_STREAM, 0); //SOCK_STREAM: TCP(reliable, connection oriented) 
	if(listening==-1)
	{
		cout<<"Cannot create a socket!\n";
		return -1;
	}
	/* Bind the socket to a IP/port */
	sockaddr_in hint; //Generally called hints, this is going to be our hint from server side
	hint.sin_family = AF_INET;
	hint.sin_port = htons(54000);  // [host short to network short] Used to convert the whole number that the machine understands to what the network can understand
	// inet_pton(AF_INET, "0.0.0.0", &hint.sin_addr); //Is an internet command, [pointer to a string to a number]. Converts number to an array of integers
	
	if(bind(listening, (sockaddr*)&hint, sizeof(hint)) == -1)
	{
		cout<<"Cannot bind to IP/port!";
	}

	// Mark the socket for listening in
	if(listen(listening, 5) == -1)
	{
		cout<<"Cannot listen!\n";
	}
	
	// Accept a call
	sockaddr_in client;
	socklen_t clientSize = sizeof(client);
	char host[NI_MAXHOST];
	char service[NI_MAXSERV];

	int clientSocket = accept(listening, (sockaddr*)&client, &clientSize);
	if(clientSocket == -1)
	{
		cout<<"Problem with client connecting\n";
	}

	// Close the listening socket
	close(listening);

	memset(host, 0 , NI_MAXHOST); //To clean the memory
	memset(service, 0, NI_MAXSERV);

	int result = getnameinfo((sockaddr*)&client, sizeof(client),host,NI_MAXHOST,service,NI_MAXSERV,0);

	if(result)
	{
		cout<<host<<" connected on port " << service <<endl;
	}
	else
	{
		inet_ntop(AF_INET, &client.sin_addr,host, NI_MAXHOST); //Opposite of inet_pton, [numeric array to string]
		cout<< host<< " connected on "<< ntohs(client.sin_port)<<endl;
	}


	// While receiving- display message, echo message
	char buffer[4096];
	while(true)
	{
		//Clear the buffer
		memset(buffer, 0 , 4096);
		//Wait for the message
		int byteRecv = recv(clientSocket, buffer, 4096, 0);
		if (byteRecv == -1)
		{
			cout<<"There is a connection issue"<<endl;
			break;	
		}
		if (byteRecv == 0)
		{
			cout<<"Client disconnected"<<endl;
			break;	
		}
		//Display the mesage
		cout<<"REceived:" << string(buffer,0,byteRecv)<<endl;
		send(clientSocket, buffer, byteRecv +1,0);//Echo the message 

		//Resend the message
	}

	// Close socket
	close(clientSocket);
	return 0;
}
