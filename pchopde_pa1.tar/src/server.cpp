/**
* @pchopde_assignment1
* @author  Priyank Pramod Chopde <pchopde@buffalo.edu>
* @version 1.0
*
* @section LICENSE
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License as
* published by the Free Software Foundation; either version 2 of
* the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* General Public License for more details at
* http://www.gnu.org/copyleft/gpl.html
*
* @section DESCRIPTION
*
* This file contains the server.
*/
#include <iostream>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <strings.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include "../include/global.h"
#include "../include/logger.h"
#include <typeinfo> 
#include <vector>
#include <algorithm>
#include <map>
#include <queue>
#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 100
#define BUFFER_SIZE 256
#define your_ubit_name "mahikawa"
using namespace std;


int connect_to_host(char *server_ip, char *server_port);
char* getServerIP(char* argv);
string addToLoggedIn(struct sockaddr_in client_addr, int fd);
void printLoggedIn();
void printStats();
int getClientIndexFromFD(int fd);
void addBlockedClient(char* blockedByIp, char* blockIp);
int isSenderBlocked(char* sender, char* receiver);
void removeBlockedClient(vector<string> &blockedClients, char* blockIp);
void sendBufferedMessages(string rcvIP, int fd);
void printBlockedClientInfo(vector<string> blockedClientIPs);
// struct client_struct{
// 	char* ip;
// 	int port;
// 	char* name;
// 	bool isLoggedIn = false;
// 	int recv_count = 0;
// 	int sent_count = 0;
// };
client_struct client_s;
vector<client_struct> active_clients;
// active_clients active_clients;
map<string, int> clientIp_fd;
map<string, queue< pair<string,string> > > ip_bufferedMessage; //key: receiver ip; value: pair<sender ip, message>



/**
* main function
*
* @param  argc Number of arguments
* @param  argv The argument list
* @return 0 EXIT_SUCCESS
*/
int server(char *argv)
{
	data_struct receive_data;
	data_struct server_data;
	int server_socket, head_socket, socketCount, sock_index, fdaccept=0, caddr_len, send_to_socket=0;
	struct sockaddr_in client_addr;
	struct addrinfo hints, *res;
	fd_set master_list, watch_list; //These are the file descriptors for select(), creating two because select is destructive. It's gonna change what set we pass to it and hence we need a temporary copy 

	/* Set up hints structure */
	memset(&hints, 0, sizeof(hints));
    	hints.ai_family = AF_INET; //AF_INET used for ipv4 addresses
    	hints.ai_socktype = SOCK_STREAM; //SOCK_STREAM: TCP(reliable, connection oriented) 
    	hints.ai_flags = AI_PASSIVE;
		

	/* Fill up address structures */
	if (getaddrinfo(NULL, argv, &hints, &res) != 0)
		perror("getaddrinfo failed");
	
	/* Socket */
	server_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if(server_socket < 0)
		perror("Cannot create socket");
	
	/* Bind */
	if(bind(server_socket, res->ai_addr, res->ai_addrlen) < 0 )
		perror("Bind failed");

	freeaddrinfo(res);
	
	/* Listen */
	if(listen(server_socket, BACKLOG) < 0)
		perror("Unable to listen on port");
	
	/* ---------------------------------------------------------------------------- */
	
	/* Zero select FD sets */
	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);
	
	/* Register the listening socket */
	FD_SET(server_socket, &master_list); //Add the current socket from server_socket to the current set in master_list
	/* Register STDIN */
	FD_SET(STDIN, &master_list);
	
	head_socket = server_socket; //because select is destructive it'll change the server socket file descriptor
	
	while(TRUE)
	{
		memcpy(&watch_list, &master_list, sizeof(master_list)); //Copying the master list to temp watch list because select is destructive as mentioned in line 62
		
		printf("\n[PA1-Server@CSE489/589]$ ");
		fflush(stdout);
		
		/* select() system call. This will BLOCK */
		socketCount = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
		if(socketCount < 0)
			perror("Select failed.");
		
		/* Check if we have sockets/STDIN to process */
		if(socketCount > 0){
			/* Loop through socket descriptors to check which ones are ready */
			for(sock_index=0; sock_index<=head_socket; sock_index+=1)
			{
				fflush(stdout);
				memset(&server_data, '\0', sizeof(server_data));
				if(FD_ISSET(sock_index, &watch_list)) //If a file descriptor is ready to read
				{
					
					/* Check if new command on STDIN */
					if (sock_index == STDIN) //Socket that's ready to read from is one of the client socket
					{
						char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
						char *block_ip, *param;
						memset(cmd, '\0', CMD_SIZE);
						if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to cmd
							exit(-1);
						string strcmd(cmd);
						
						// printf("\nI got: %s\n", cmd);
						if(strcmd == "AUTHOR\n")
						{
							cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
							cse4589_print_and_log("I, pchopde, have read and understood the course academic integrity policy.\n");
							cse4589_print_and_log("[AUTHOR:END]\n");
						}
						else if(strcmd == "IP\n"){
							// cout<<"entering getIP()\n";
							char* ip_addr = getServerIP(argv);
							cse4589_print_and_log("IP:%s\n", ip_addr);
							cse4589_print_and_log("[IP:END]\n");
							// cout<<"out"<<ip_addr<<endl;
						}
						else if(strcmd == "PORT\n")
						{
							cse4589_print_and_log("[PORT:SUCCESS]\n");
							cse4589_print_and_log("PORT:%s\n", argv);
							cse4589_print_and_log("[PORT:END]\n");
						}
						else if(strcmd == "LIST\n")
						{
							cse4589_print_and_log("[LIST:SUCCESS]\n");
							printLoggedIn();
							cse4589_print_and_log("[LIST:END]\n");
						}
						else if(strcmd == "STATISTICS\n")
						{
							cse4589_print_and_log("[STATISTICS:SUCCESS]\n");
							printStats();
							cse4589_print_and_log("[STATISTICS:END]\n");
						}


						else if(strncmp(cmd,"BLOCKED",7)==0 )
						{
							// cout<<"entering blocked\n";
							param = strtok(cmd," ");
							int param_counter=0;
							while (param != NULL)
							{
								param_counter+=1;
								if(param_counter == 2)
								{
									block_ip = param;
								}
								param = strtok(NULL," ");
							}
							block_ip[strlen(block_ip)-1] = '\0';
							// block_ip[strlen(block_ip)] = '\0';
							//printing blocked clients for block_ip
							for(int i=0; i<active_clients.size(); i++){
								if(strcmp(active_clients[i].ip, block_ip) == 0){
	
									printBlockedClientInfo(active_clients[i].blockedClients);

								}
								cout<<"\n\n";
							}
							/*Call your function here, the variable block_ip is (char*)*/
							/*Remember the client should be logged in before it can enter BLOCKED command*/
						}							

						
						free(cmd);
					}
					/* Check if new client is requesting connection */
					else if(sock_index == server_socket) //This means we can accept a new connection
					{
						socklen_t caddr_len = sizeof(client_addr);
						fdaccept = accept(server_socket, (struct sockaddr *)&client_addr, &caddr_len);
						if(fdaccept < 0)
							perror("Accept failed.");

						string newClientIP = addToLoggedIn(client_addr, fdaccept);
						// sendBufferedMessages(newClientIP, fdaccept);
						/*###################################*/
						/*Sending buffered messages*/
						if(ip_bufferedMessage.find(newClientIP) != ip_bufferedMessage.end())
						{
							while(!ip_bufferedMessage[newClientIP].empty())
							{
								pair<string,string> currMsg =  ip_bufferedMessage[newClientIP].front(); 
								ip_bufferedMessage[newClientIP].pop();
								// const char* sndrIP = currMsg.first.c_str();
								// const char* messageContent = currMsg.second.c_str();
								char receiver_ip[32];
								send_to_socket = fdaccept;
								//Converting the values
								strcpy(server_data.cmd,"MSG");
								strcpy(server_data.ip,currMsg.first.c_str());
								strcpy(server_data.message,currMsg.second.c_str());
								strcpy(receiver_ip,newClientIP.c_str());
								if(send(send_to_socket, &server_data, sizeof(server_data),0)==sizeof(server_data))
								{
										cse4589_print_and_log("[RELAYED:SUCCESS]\n");
										cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s",server_data.ip, receiver_ip, server_data.message);
										cse4589_print_and_log("[RELAYED:END]\n");
								}
							}
						}
						/*###################################*/

						//Send the client the list
						// send()
						printf("\nRemote Host connected!\n"); 
						/* Add to watched socket list */
						FD_SET(fdaccept, &master_list);  // Adding the connection to the list of connections that we are watching
						if(fdaccept > head_socket) head_socket = fdaccept;
					}
					/* Read from existing clients */
					else
					{
						/* Initialize buffer to receieve response */
						// char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
						memset(&receive_data, '\0', sizeof(receive_data));
						
						if(recv(sock_index, &receive_data, sizeof(receive_data), 0) <= 0)
						{
							close(sock_index);
							//call removeFromLoggedIn(sock_index)
							int idx = getClientIndexFromFD(sock_index);
							if(idx != -1){
								active_clients.erase(active_clients.begin() + idx);
							}
							printf("Remote Host terminated connection!\n");
							
							/* Remove from watched list */
							FD_CLR(sock_index, &master_list);
						}
						else 
						{
							int blockflag = 0;
							//Process incoming data from existing clients here ...
							if((strcmp(receive_data.cmd,"SEND"))==0)
							{
								char sender_ip[32];
								char receiver_ip[32];
								bool isReceiverLoggedIn = false;
								//searching the vector for ip based in sender socket
								for (int i = 0; i < active_clients.size(); i++)
								{
									if (active_clients[i].fdsocket == sock_index)
									{
										strcpy(sender_ip, active_clients[i].ip);
										active_clients[i].sent_count+=1;
										break;
									}
								}
								//searching for receiver socket using ip
								for (int i = 0; i < active_clients.size(); i++)
								{
									if(strcmp(active_clients[i].ip,receive_data.ip) == 0)
									{	
										isReceiverLoggedIn = active_clients[i].isLoggedIn;
										// isSenderBlocked(active_clients[i].blockedClients, sender_ip);
										if (find(active_clients[i].blockedClients.begin(), active_clients[i].blockedClients.end(), sender_ip) !=
										active_clients[i].blockedClients.end()) {
											blockflag = 1;
											// break;
										}
										send_to_socket = active_clients[i].fdsocket;
										active_clients[i].recv_count+=1;
										break;
									}
								}
								//setting receiver IP
								strcpy(receiver_ip,receive_data.ip);
								//Implement check for blocking here
								
								// blockflag = isSenderBlocked();

								if(blockflag == 0)
								{
									strcpy(server_data.cmd,"MSG");
									strcpy(server_data.ip,sender_ip);
									strcpy(server_data.message,receive_data.message);
									if(!isReceiverLoggedIn){
										ip_bufferedMessage[receiver_ip].push({sender_ip, receive_data.message});
									}
									else if(send(send_to_socket, &server_data, sizeof(server_data),0)==sizeof(server_data))
									{
										cse4589_print_and_log("[RELAYED:SUCCESS]\n");
										cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s",sender_ip, receiver_ip, receive_data.message);
										strcpy(server_data.cmd,"MSG_SENT");
										if (send(sock_index, &server_data, sizeof(server_data),0)==sizeof(server_data))
										{
											cout<<"Done!\n";
										}
										cse4589_print_and_log("[RELAYED:END]\n");
									}
									else
			                        {
										cse4589_print_and_log("[RELAYED:ERROR]\n");
										strcpy(server_data.cmd,"MSG_SENT_FAIL");
										if(send(sock_index, &server_data, sizeof(server_data), 0) == sizeof(server_data))
										{
											printf("Done!\n");	
										}
										cse4589_print_and_log("[RELAYED:END]\n");
			                        }
									// cse4589_print_and_log("[RELAYED:END]\n");
								}
								else
			                    {
			                    	printf("this client blocked this ip\n");
			                    	cse4589_print_and_log("[RELAYED:SUCCESS]\n");
									cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",sender_ip, receiver_ip, receive_data.message);
			                    	strcpy(server_data.cmd,"MSG_SENT");
			                        if(send(sock_index, &server_data, sizeof(server_data), 0) == sizeof(server_data))
			                        {
			                        	printf("\nsent msg to sender that msg has been delivered!\n");	
			                        }
			                        cse4589_print_and_log("[RELAYED:END]\n");
			                    }
							}
							else if((strcmp(receive_data.cmd,"BLOCK")) == 0){
								char sender_ip[32];
								
								//searching the vector for ip based in sender socket
								for (int i = 0; i < active_clients.size(); i++)
								{
									if (active_clients[i].fdsocket == sock_index)
									{
										strcpy(sender_ip, active_clients[i].ip);
										cse4589_print_and_log(sender_ip);
										active_clients[i].blockedClients.push_back(receive_data.ip);
										// active_clients[i].sent_count+=1;
										cse4589_print_and_log(sender_ip);
										cse4589_print_and_log("\n");
										// active_clients[i].blockedClients.push_back(receive_data.ip);
										break;
									}
								}
								// cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCK");
								// cse4589_print_and_log("[%s:END]\n", "BLOCK");

							}
							else if((strcmp(receive_data.cmd,"UNBLOCK")) == 0){
								char sender_ip[32];
								string receiver_ip="";
								//searching the vector for ip based in sender socket
								for (int i = 0; i < active_clients.size(); i++)
								{
									if (active_clients[i].fdsocket == sock_index)
									{
										strcpy(sender_ip, active_clients[i].ip);
										bool blockedIPFound = false;
										for(int j=0; j<active_clients[i].blockedClients.size(); j++){
											cout<<"received ip to be unblocked: "<<receive_data.ip<<"\n";
											if(strcmp(receive_data.ip, active_clients[i].blockedClients[j].c_str()) == 0){
												// cout<<"found previously blocked client, removing it";
												active_clients[i].blockedClients.erase(active_clients[i].blockedClients.begin()+j);
												blockedIPFound = true;
												break;
											}
										}
										if(!blockedIPFound){
											cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
										}
										else{
											cse4589_print_and_log("[%s:SUCCESS]\n", "UNBLOCK");
										}
										// removeBlockedClient(active_clients[i].blockedClients, receive_data.ip);
										break;
									}
								}

								// addBlockedClient(sender_ip, receive_data.ip);
								
								cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
							}
							else if((strcmp(receive_data.cmd,"BROADCAST"))==0)
							{
								int i = 0;
								char sender_ip[32];
								char receiver_ip[32];
								//searching the vector for ip based in sender socket
								while(i<5)
								{	
									if (active_clients[i].fdsocket==sock_index)
									{
										strcpy(sender_ip, active_clients[i].ip);
										active_clients[i].sent_count+=1;
										break;
									}
									i+=1;
								}
								//Sending the message to all the active clients
								i = 0;
								while(i<active_clients.size())
								{
									int blockflag=0;
									if(active_clients[i].fdsocket !=0)
									{	
										send_to_socket=active_clients[i].fdsocket;
										// receiver_ip = active_clients[i].ip;
										strcpy(receiver_ip,active_clients[i].ip);
										//Check for blocking
										// cout<<"Receiver IP: "<<receiver_ip<<"Sender IP: "<<sender_ip<<strcmp(receiver_ip, sender_ip);
										if(blockflag==0 && strcmp(receiver_ip, sender_ip))
										{
											active_clients[i].recv_count+=1;
											strcpy(server_data.cmd,"MSG");
											strcpy(server_data.ip,sender_ip);
											strcpy(server_data.message,receive_data.message);
											if(send(send_to_socket, &server_data, sizeof(server_data),0)==sizeof(server_data))
											{
												cse4589_print_and_log("[RELAYED:SUCCESS]\n");
												cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",sender_ip, receiver_ip, receive_data.message);
												strcpy(server_data.cmd,"MSG_SENT");
												if (send(sock_index, &server_data, sizeof(server_data),0)==sizeof(server_data))
												{
													cout<<"Done!\n";
												}
											}
											else
											{
												cse4589_print_and_log("[RELAYED:ERROR]\n");
												strcpy(server_data.cmd,"MSG_SENT_FAIL");
												if(send(sock_index, &server_data, sizeof(server_data), 0) == sizeof(server_data))
												{
													printf("Done!\n");	
												}
			                        		}
										cse4589_print_and_log("[RELAYED:END]\n");
										}
										
									}
									i+=1;
								}

							}
							else if((strcmp(receive_data.cmd,"SENDLIST"))==0)
							{
								// cout<<"Requestor server IP: ";
								// cout<<receive_data.ip;
								// cout<<"Client requesting list\n";
								char requestor_ip[32];
								//Get the requestor socket using IP
								//searching for receiver socket using ip
								for (int i = 0; i < 5; i++)
								{
									if((strcmp(active_clients[i].ip,receive_data.ip)) == 0)
									{	
										send_to_socket=active_clients[i].fdsocket;
										// active_clients[i].recv_count+=1;
										break;
									}	
								}
								for(int i=0; i<active_clients.size(); i++)
								{
									if(active_clients[i].isLoggedIn==true)
									{
										// sort(active_clients.begin(), active_clients.end(), comparePort);
										strcpy(server_data.cmd,"SENDLIST");
										strcpy(server_data.ip,active_clients[i].ip);
										strcpy(server_data.hostname,active_clients[i].hostname);
										server_data.port = active_clients[i].port;
										// cout<<"Active clients IP\n"<<active_clients[i].ip<<" "<<active_clients[i].hostname;
										if(send(send_to_socket, &server_data, sizeof(server_data),0)==sizeof(server_data))
										{
											// cout<<"Sending active IP,hostname,port\n";
										}
									}

								}
							}
							else if((strcmp(receive_data.cmd,"LOGOUT"))==0)
							{
								// cout<<"Received logout from the client\n";
								char requestor_ip[32];
								//searching the vector for ip based on sender socket
								for (int i = 0; i < active_clients.size(); i++)
								{
									if (active_clients[i].fdsocket == sock_index)
									{
										active_clients[i].isLoggedIn=false;
										// cout<<"The IP "<<active_clients[i].ip<<" logged out\n"<<active_clients[i].isLoggedIn;
										break;
									}
								}
							}
							else if((strcmp(receive_data.cmd,"EXIT"))==0)
							{
								cout<<"Received exit from the client\n";
								char requestor_ip[32];
								//searching the vector for ip based on sender socket
								for (int i = 0; i < active_clients.size(); i++)
								{
									if (active_clients[i].fdsocket == sock_index)
									{
										active_clients[i].isLoggedIn=false;
										/*
										TO DO : Delete the struct vector of this client!
										*/
										active_clients.erase(active_clients.begin()+i);
										break;
									}
								}
							}
							// printf("\nClient sent me: %s\n", buffer);
							// printf("ECHOing it back to the remote host ... ");
							// if(send(fdaccept, buffer, strlen(buffer), 0) == strlen(buffer))
							// 	printf("Done!\n");
							fflush(stdout);
						}
						
						// free(buffer);
					}
				}
			}
		}
	}
	
	return 0;
}

string addToLoggedIn(struct sockaddr_in client_addr, int fd)
{
	// struct client_struct client_s;
	// cout<<"Into add to logged in\n";
	char ip[50];
	int flag=0;
	int caddr_len = sizeof(client_addr);
	char myHostName[1024];
	const char *clstr = inet_ntop(AF_INET, &((struct sockaddr_in*)&client_addr)->sin_addr, ip, sizeof(ip));
	char* clientstr = new char[50];
	strcpy(clientstr, clstr);	
	int port = ntohs(((struct sockaddr_in*)&client_addr)->sin_port);
	// gethostname()
	getnameinfo((struct sockaddr *)&client_addr, caddr_len,myHostName, sizeof(myHostName), 0,0,0);
	strcpy(client_s.hostname,myHostName);
	int index=0;
	// cout<<"The port is "<<port;
	//Checking if the logged in client is already in the list
	// cout<<"The port is "<<port;
	for(int i=0;i<active_clients.size(); i++)
	{
		if(strcmp(active_clients[i].ip,clstr)==0)
		{
			index=i;
			// cout<<"Client already exists\n";
			flag=1;
		}
	}
	if(flag==0)
	{
		client_s.ip = clientstr;
		client_s.port = port;
		client_s.isLoggedIn = true;
		client_s.fdsocket = fd;
		active_clients.push_back(client_s);
		clientIp_fd[client_s.ip] = fd;
		string temp(clientstr);
		return temp;
	}
	else
	{
		// active_clients[i].port = port;
		active_clients[index].isLoggedIn=true;
		active_clients[index].fdsocket=fd;
		string temp(clientstr);
		return temp;
	}
}

void removeFromLoggedIn(int sock_index)
{
	cout<<"Implement remove\n";
}

bool comparePort(client_struct c1, client_struct c2)
{
    return (c1.port < c2.port);
}
void printLoggedIn()
{
	sort(active_clients.begin(), active_clients.end(), comparePort);
	for(int i=0; i<active_clients.size(); i++)
	{
		// cout<<active_clients[i].ip<<":"<<active_clients[i].port<<"\n";
		int list_id = i+1;
		char hostname[1024];
		strcpy(hostname,active_clients[i].hostname);
		char ip_addr[32];
		strcpy(ip_addr,active_clients[i].ip);
		int port_num = active_clients[i].port;
		cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, hostname, ip_addr, port_num);

	}
} 

void printStats()
{
	sort(active_clients.begin(), active_clients.end(), comparePort);
	for(int i=0; i<active_clients.size(); i++)
	{
		int list_id = i+1;
		char hostname[1024];
		int num_msg_sent=active_clients[i].sent_count;
		int num_msg_rcv=active_clients[i].recv_count;
		char status[20];
		strcpy(hostname,active_clients[i].hostname);
		char ip_addr[32];
		strcpy(ip_addr,active_clients[i].ip);
		int port_num = active_clients[i].port;
		if(active_clients[i].isLoggedIn)
		{
			strcpy(status,"logged-in");
		}
		else
		{
			strcpy(status,"logged-out");
		}
		cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", list_id, hostname, num_msg_sent, num_msg_rcv, status);
	}
} 

char* getServerIP(char *port)
{
	struct sockaddr_in google, client;
	int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if(udp_socket < 0){
		perror("Cannot create socket");
	}
	memset(&google, 0, sizeof(google));
	google.sin_family = AF_INET;
	google.sin_port = htons(53);
	google.sin_addr.s_addr = inet_addr("8.8.8.8");

	if(connect(udp_socket, (struct sockaddr *)&google, sizeof(google)) < 0){
		perror("Connect failed");
	}
	socklen_t clientlen = sizeof(client);
	if(getsockname(udp_socket, (struct sockaddr *)&client, &clientlen)<0){
		perror("couldn't get ip address");
	}
	char buffer[50];
	const char* ip = inet_ntop(AF_INET, &client.sin_addr, buffer, 50);
	char* ipstr = new char[50];
	strcpy(ipstr, ip);
	close(udp_socket);
	if(ip==NULL)
	{
		cse4589_print_and_log("[IP:ERROR]\n");
	}
	else
	{
		cse4589_print_and_log("[IP:SUCCESS]\n");
	}
	return ipstr;
	return ipstr;
}

int getClientIndexFromFD(int fd){
	for(int i=0; i<active_clients.size(); i++){
		if(active_clients[i].fdsocket == fd){
			return i;
		}
	}
	return -1;
}

void addBlockedClient(char* blockedByIp, char* blockIp){
	for(int i=0; i<active_clients.size(); i++){
		if(strcmp(active_clients[i].ip, blockedByIp) == 0){
			active_clients[i].blockedClients.push_back(blockIp);
		}
	}

	for(int i=0; i<active_clients.size(); i++){
		// cout<<"added blocked clients";
		cout<<active_clients[i].blockedClients[0];
		// if(strcmp(active_clients[i].ip, blockedByIp) == 0){
		// 	active_clients[i].blockedClients.push_back(blockIp);
		// 	return;
		// }
	}
}

void removeBlockedClient(vector<string> &blockedClients, char* blockIp){
	string ip(blockIp);
	for(int i=0; i<blockedClients.size(); i++)
	{
		cout<<blockedClients[i]<<"\n";
		if(ip == blockedClients[i])
		{
			cout<<"found previously blocked client, removing it";
			blockedClients.erase(blockedClients.begin()+i);
		}
		
	}
	// std::vector<string>::iterator f = find(blockedClients.begin(), blockedClients.end(), ip);
	// if(f != blockedClients.end()){
	// 	cse4589_print_and_log("DEBUG: Blocked client ip found in the list");
	// 	cse4589_print_and_log(blockIp);
	// 	blockedClients.erase(f);
	// }
	
	cse4589_print_and_log("DEBUG: unblocked client");
	// cse4589_print_and_log(ip);
}

void sendBufferedMessages(string rcvIP, int fd)
{
	if(ip_bufferedMessage.find(rcvIP) != ip_bufferedMessage.end())
	{
		while(!ip_bufferedMessage[rcvIP].empty())
		{
			pair<string,string> currMsg =  ip_bufferedMessage[rcvIP].front(); 
			ip_bufferedMessage[rcvIP].pop();
			const char* sndrIP = currMsg.first.c_str();
			const char* messageContent = currMsg.second.c_str();
			cout<<"Into buffered send\n";
			cout<<"Sender IP: "<<sndrIP<<" : ";
			cout<<"Receiver IP: "<<rcvIP<<" : ";
			cout<<"MESSAGE: "<<messageContent;

			//TODO priyank: send <messageContent> to <sndrIP>  
		}
	}
	
}

void printBlockedClientInfo(vector<string> blockedIPs){
	// cse4589_print_and_log("[BLOCKED:SUCCESS]\n");
	vector<client_struct> blockedPrints; 
	int list_id = 1;
	for(int i=0; i<blockedIPs.size(); i++){
		for(int j=0; j<active_clients.size(); j++){
			if(strcmp(active_clients[j].ip, blockedIPs[i].c_str()) == 0){
				blockedPrints.push_back(active_clients[j]);
				list_id++;
				break;
			}
		}
	}
	sort(blockedPrints.begin(), blockedPrints.end(), comparePort);
	for(int x=0; x<blockedPrints.size(); x++){
		cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, blockedPrints[x].hostname, blockedPrints[x].ip, blockedPrints[x].port);
	}

	// cse4589_print_and_log("[BLOCKED:END]\n");

}

// int isSenderBlocked(char* sender, char* receiver){
// 	for(int i=0; i<active_clients.size(); i++){
// 		if(strcmp(active_clients[i].ip, receiver) == 0){
// 			for(int j=0; j<active_clients.blockedClients.size(); j++){
// 				if(strcmp(active_clients[i].blockedClients[j], ) == 0){

// 				}
// 			}
// 		}
// 	}
// }
