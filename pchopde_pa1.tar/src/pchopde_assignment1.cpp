/**
 * @pchopde_assignment1
 * @author  Priyank Pramod Chopde <pchopde@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <iostream>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <strings.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
// #include <bits/stdc++.h>
// #include <cstddef>
#include "../include/global.h"
#include "../include/logger.h"

using namespace std;

/*
To run as a server listening on port 4322
$ ./assignment1 s 4322

To run as a client listening on port 4322
$ ./assignment1 c 4322
*/

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));

	/*Start Here*/

	if(argc != 3) 
	{
		printf("Usage:%s [server/client] [port]\n", argv[0]);
		exit(-1);
	}
	
	cout<<"Running program\n";
	if(strcmp(argv[1],"s")==0)
	{
		cout<<"Running server\n";
		server(argv[2]);
	}
	if(strcmp(argv[1],"c")==0)
	{
		cout<<"Running client\n";
		client(argv[2]);
	}
	return 0;
}
