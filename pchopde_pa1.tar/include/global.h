#ifndef GLOBAL_H_
#define GLOBAL_H_

#define HOSTNAME_LEN 128
#define PATH_LEN 256

int server(char*);
int client(char*);

#include<iostream>
#include <vector>
using namespace std;
struct client_struct{
	char* ip;
	int port;
	char hostname[1024];
	bool isLoggedIn = false;
	int recv_count = 0;
	int sent_count = 0;
	int fdsocket = 0;
	vector<string> blockedClients;
};
struct client_info_struct{
	char ip[32];
	int port;
	char hostname[1024];
	bool isLoggedIn = false;
	int recv_count = 0;
	int sent_count = 0;
	int fdsocket = 0;
};

struct data_struct
{
	char cmd[20];
	char ip[32];
	char message[256];	
	char hostname[1024];
	int port;
};

#endif
