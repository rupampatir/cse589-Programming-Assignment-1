/**
 * @varshith_assignment1
 * @author  varshith vootla <varshith@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>

#include "../include/global.h"
#include "../include/logger.h"

#define STDIN 0
#define TRUE 1
#define BUFFER_SIZE 256
#define CMD_SIZE 256

struct host
{
	char hostname[250];
	char ip_addr[64];
	int port_num;
	int num_msg_sent;
	int num_msg_rcv;
	char status[15];
	int fd;
	struct blocked_clients *blocked;
	struct host *next_host;
	struct message_buffer *buffer;
	int msg_count;
};

struct message_buffer
{
	char message[350];
	char receiver_IP[64];
	int sender_socket;
	struct message_buffer *next;
};

struct blocked_clients
{
	char hostname[250];
	char ip_addr[64];
	int port_num;
	struct blocked_clients *next;
};

struct host *start = NULL;

char *client_port;
int client_sock;
int loggedIn = 0;

void serverProgram(int port_no);
void clientProgram(int port_no);
void ip();
void login();
void list();
void addClientToList();
int receiveAllMessages();
void sendClientList();
void updateListeningPort();
int sendtotalmessage();
void refreshClientList();
void deleteClientList();
void logout();
void logOutClient();
void sendMessage();
void broadCastMessage();
bool isValidIP();
bool valid_number();
bool is_ip_addr_in_client_list();
void increase_msg_send_count();
void increase_msg_recv_count();
int getSocketByIp();
char *get_ip_addr_by_socket();
void show_Statistcs();
void blockClient();
void unblockClient();
void blockClientinServerList();
void unblockClientinServerList();
void deleteClient();
void insertSort();
void deleteNodeInLinkedList();
bool checkBlockedOrNot();
void show_blocked_clients();
bool isClientLoggedIn();
void changeClientLoginStatus();
void sendBufferedMessages();
void storeBufferedMessages();
/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/*Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));
	/*Start Here*/
	if (argc < 2)
	{
		cse4589_print_and_log("Insufficient input arguments");
	}
	int port_no = atoi(argv[2]);

	if (strcmp(argv[1], "s") == 0)
	{
		serverProgram(port_no);
	}
	else if (strcmp(argv[1], "c") == 0)
	{
		client_port = argv[2];
		clientProgram(port_no);
	}
	else
	{
		cse4589_print_and_log("Invalid Arguments Provided");
	}

	return 0;
}

void serverProgram(int port_no)
{
	int server_socket, selret, head_socket, new_socket = 0;
	struct sockaddr_in server_address, clientAddress;
	fd_set master_list, watch_list;

	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket < 0)
	{
		cse4589_print_and_log("Cannot Create Socket");
	}

	bzero(&server_address, sizeof(server_address));

	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
	server_address.sin_port = htons(port_no);

	if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
	{
		cse4589_print_and_log("Bind Failed");
	}

	if (listen(server_socket, 5) < 0)
	{
		cse4589_print_and_log("Unable to listen on port");
	}

	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);

	FD_SET(server_socket, &master_list);

	FD_SET(STDIN, &master_list);

	head_socket = server_socket;

	while (TRUE)
	{
		memcpy(&watch_list, &master_list, sizeof(master_list));

		selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
		if (selret < 0)
		{
			cse4589_print_and_log("select failed");
		}

		if (selret > 0)
		{

			for (int i = 0; i <= head_socket; i += 1)
			{
				if (FD_ISSET(i, &watch_list))
				{
					if (i == STDIN)
					{
						char command[CMD_SIZE];
						memset(command, '\0', CMD_SIZE);
						if (fgets(command, CMD_SIZE - 1, stdin) == NULL)
							exit(-1);

						char command1[CMD_SIZE];
						strcpy(command1, command);

						char *token = strtok(command, "\n");
						char *commands[3];
						int argv = 0;
						char *token1 = strtok(token, " ");
						while (token)
						{
							commands[argv] = token;
							argv++;
							token = strtok(NULL, " ");
						}
						if (strcmp(commands[0], "AUTHOR") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
							cse4589_print_and_log("I, varshith, have read and understood the course academic integrity policy.\n");
							cse4589_print_and_log("[%s:END]\n", commands[0]);
						}
						else if (strcmp(commands[0], "IP") == 0)
						{
							ip(commands);
						}
						else if (strcmp(commands[0], "PORT") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
							cse4589_print_and_log("PORT:%d\n", port_no);
							cse4589_print_and_log("[%s:END]\n", commands[0]);
						}
						else if (strcmp(commands[0], "LIST") == 0)
						{
							list(commands);
						}
						else if (strcmp(commands[0], "STATISTICS") == 0)
						{
							show_Statistcs(commands);
						}
						else if (strcmp(commands[0], "BLOCKED") == 0)
						{
							show_blocked_clients(commands);
						}
					}
					else if (i == server_socket)
					{
						int addrlen = sizeof(clientAddress);
						new_socket = accept(server_socket, (struct sockaddr *)&clientAddress, &addrlen);
						if (new_socket < 0)
						{
							cse4589_print_and_log("Server accept failed");
						}

						char clientIP[16];
						char myHost[30];
						inet_ntop(AF_INET, &(clientAddress.sin_addr), clientIP, sizeof(clientIP));
						unsigned int client_port = ntohs(clientAddress.sin_port);
						struct hostent *clienthost;
						clienthost = gethostbyaddr((const char *)&(clientAddress.sin_addr), sizeof(clientAddress.sin_addr), AF_INET);
						strcpy(myHost, clienthost->h_name);
						addClientToList((&start), client_port, clientIP, myHost, new_socket);
						FD_SET(new_socket, &master_list);
						if (new_socket > head_socket)
						{
							head_socket = new_socket;
						}
					}
					else
					{
						char *bufferLen = (char *)malloc(sizeof(char) * BUFFER_SIZE);
						memset(bufferLen, '\0', BUFFER_SIZE);

						char *buffer = (char *)malloc(sizeof(char) * BUFFER_SIZE);
						memset(buffer, '\0', BUFFER_SIZE);

						int recieved = recv(i, bufferLen, 3, 0);
						int msg_len = atoi(bufferLen);

						int r_entireMSG = receiveAllMessages(i, buffer, msg_len);

						if (recieved == 0)
						{
							deleteClient(&start, i);
							close(i);
							FD_CLR(i, &master_list);
						}
						else
						{
							char *p = strtok(buffer, " ");
							int x = 0;
							char *cmd[2];
							while (p != NULL)
							{
								cmd[x] = p;
								x++;
								if (x <= 0)
								{
									p = strtok(NULL, " ");
								}
								else
								{
									p = strtok(NULL, "");
								}
							}
							if (strcmp(cmd[0], "login") == 0)
							{

								updateListeningPort(start, cmd[1], i);
								insertSort(&start);
								struct host *temp = start;
								sendClientList(temp, i, cmd[0]);
							}
							else if (strcmp(cmd[0], "login-again") == 0)
							{
								changeClientLoginStatus(i);
								struct host *temp = start;
								sendClientList(temp, i, cmd[0]);
								sendBufferedMessages(i);
							}
							else if (strcmp(cmd[0], "REFRESH") == 0)
							{
								struct host *temp = start;
								sendClientList(temp, i, cmd[0]);
							}
							else if (strcmp(cmd[0], "LOGOUT") == 0)
							{
								struct host *temp = start;
								logout(temp, i);
							}
							else if (strcmp(cmd[0], "BLOCK") == 0)
							{
								struct host *temp = start;
								char *sender_ip_addr = get_ip_addr_by_socket(temp, i);
								blockClientinServerList(sender_ip_addr, cmd[1]);
							}
							else if (strcmp(cmd[0], "UNBLOCK") == 0)
							{
								struct host *temp = start;
								char *sender_ip_addr = get_ip_addr_by_socket(temp, i);
								unblockClientinServerList(sender_ip_addr, cmd[1]);
							}
							else if (strcmp(cmd[0], "BROADCAST") == 0)
							{
								char *sender_ip_addr = get_ip_addr_by_socket(start, i);

								int length = strlen(sender_ip_addr) + strlen(cmd[1]) + 1;
								char lengthbuffer[4];
								sprintf(lengthbuffer, "%-3d", length);

								char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
								strcpy(msg, lengthbuffer);
								strcat(msg, sender_ip_addr);
								strcat(msg, " ");
								strcat(msg, cmd[1]);

								int len;
								len = strlen(msg);

								for (int j = 1; j <= head_socket; j++)
								{
									if (FD_ISSET(j, &master_list))
									{
										if (j != server_socket && j != i)
										{
											if (sendtotalmessage(j, msg, &len) == 0)
											{
												increase_msg_recv_count(j, start);
											}
										}
									}
								}
								increase_msg_send_count(i, start);
								// char rel[10] = "RELAYED";
								// char ip_local[17] = "255.255.255.255";
								cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
								cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip_addr, "255.255.255.255", cmd[1]);
								cse4589_print_and_log("[%s:END]\n", "RELAYED");
								free(msg);
							}
							else
							{
								int receiver_socket = getSocketByIp(start, cmd[0]);
								char *sender_ip_address = get_ip_addr_by_socket(start, i);
								char *reciever_ip_addr = get_ip_addr_by_socket(start, receiver_socket);

								if (checkBlockedOrNot(start, reciever_ip_addr, sender_ip_address) == false)
								{

									int length = strlen(sender_ip_address) + strlen(cmd[1]) + 1;

									char lengthbuffer[4];
									sprintf(lengthbuffer, "%-3d", length);

									char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
									strcpy(msg, lengthbuffer);
									strcat(msg, sender_ip_address);
									strcat(msg, " ");
									strcat(msg, cmd[1]);

									int len;
									len = strlen(msg);

									if (!isClientLoggedIn(reciever_ip_addr))
									{
										storeBufferedMessages((&start), sender_ip_address, reciever_ip_addr, msg, i, cmd);
									}
									else
									{
										if (sendtotalmessage(receiver_socket, msg, &len) == 0)
										{
											increase_msg_recv_count(receiver_socket, start);
											increase_msg_send_count(i, start);
										}
										// char relayed[100] = "RELAYED";
										cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
										cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip_address, reciever_ip_addr, cmd[1]);
										cse4589_print_and_log("[%s:END]\n", "RELAYED");
										// free(msg);
									}
								}
							}
						}
						free(bufferLen);
						free(buffer);
					}
				}
			}
		}
	}
}

void clientProgram(int port_no)
{

	fd_set master_list, watch_list;

	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);
	FD_SET(STDIN, &master_list);
	int headSocket = STDIN;

	while (1)
	{

		memcpy(&watch_list, &master_list, sizeof(master_list));

		int selret;
		selret = select(headSocket + 1, &watch_list, NULL, NULL, NULL);
		if (selret < 0)
		{
			cse4589_print_and_log("Selection fail");
		}
		if (selret > 0)
		{

			for (int i = 0; i <= headSocket; i++)
			{

				if (FD_ISSET(i, &watch_list))
				{

					if (i == STDIN)
					{
						char command[200];
						char temp_command[200];
						memset(command, '\0', 3);
						fgets(command, 200, stdin);
						strcpy(temp_command, command);
						char *token = strtok(command, "\n");
						token = strtok(token, " ");
						char *commands[5];
						int argv = 0;
						while (token)
						{
							commands[argv] = token;
							argv++;
							token = strtok(NULL, " ");
						}

						if (strcmp(commands[0], "AUTHOR") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
							cse4589_print_and_log("I, varshith, have read and understood the course academic integrity policy.\n");
							cse4589_print_and_log("[%s:END]\n", commands[0]);
						}
						else if (strcmp(commands[0], "IP") == 0)
						{
							ip(commands);
						}
						else if (strcmp(commands[0], "PORT") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
							cse4589_print_and_log("PORT:%d\n", port_no);
							cse4589_print_and_log("[%s:END]\n", commands[0]);
						}
						else if (strcmp(commands[0], "LIST") == 0)
						{
							list(commands);
						}
						else if (strcmp(commands[0], "LOGIN") == 0)
						{
							login(commands);
							FD_SET(client_sock, &master_list);
							if (client_sock > headSocket)
							{
								headSocket = client_sock;
							}
						}
						else if (strcmp(commands[0], "REFRESH") == 0)
						{
							refreshClientList(commands);
						}
						else if (strcmp(commands[0], "SEND") == 0)
						{
							sendMessage(temp_command);
						}
						else if (strcmp(commands[0], "BROADCAST") == 0)
						{
							broadCastMessage(temp_command);
						}
						else if (strcmp(commands[0], "BLOCK") == 0)
						{
							blockClient(commands);
						}
						else if (strcmp(commands[0], "UNBLOCK") == 0)
						{
							unblockClient(commands);
						}
						else if (strcmp(commands[0], "LOGOUT") == 0)
						{
							logOutClient(commands);
						}
						else if (strcmp(commands[0], "EXIT") == 0)
						{
							close(client_sock);
							cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
							cse4589_print_and_log("[%s:END]\n", commands[0]);
							exit(0);
							cse4589_print_and_log("after exit 0");
							FD_CLR(client_sock, &master_list);
						}
						else
						{
							cse4589_print_and_log("Invalid Command: %s ", commands[0]);
						}
					}
					else
					{
						char *buffer_len = (char *)malloc(sizeof(char) * BUFFER_SIZE);
						memset(buffer_len, '\0', BUFFER_SIZE);

						char *buffer_recv = (char *)malloc(sizeof(char) * BUFFER_SIZE);
						memset(buffer_recv, '\0', BUFFER_SIZE);

						int r = recv(client_sock, buffer_len, 3, 0);
						int msg_length = atoi(buffer_len);
						int s = receiveAllMessages(client_sock, buffer_recv, msg_length);
						if (r != 0)
						{
							char *cmds[2];
							int i = 0;
							char *p = strtok(buffer_recv, " ");

							while (p != NULL)
							{
								cmds[i] = p;
								i++;
								if (i <= 0)
								{
									p = strtok(NULL, " ");
								}
								else
								{
									p = strtok(NULL, "");
								}
							}
							if (strcmp(cmds[0], "login") == 0)
							{
								char *arg = strtok(cmds[1], " ");
								char *info[12];
								int arg_inc = 0;

								while (arg)
								{
									info[arg_inc] = arg;
									arg_inc += 1;
									arg = strtok(NULL, " ");
								}
								int a = 0;
								while (a < arg_inc)
								{
									int port1 = atoi(info[a + 2]);
									addClientToList((&start), port1, info[a + 1], info[a]);
									a += 3;
								}
							}
							else if ((strcmp(cmds[0], "REFRESH") == 0))
							{
								deleteClientList(&start);
								char *arg = strtok(cmds[1], " ");
								char *info[12];
								int arg_inc = 0;

								while (arg)
								{
									info[arg_inc] = arg;
									arg_inc += 1;
									arg = strtok(NULL, " ");
								}
								int a = 0;
								while (a < arg_inc)
								{
									int port1 = atoi(info[a + 2]);
									addClientToList((&start), port1, info[a + 1], info[a]);
									a += 3;
								}
							}
							else if ((strcmp(cmds[0], "login-again") == 0))
							{
								deleteClientList(&start);
								char *arg = strtok(cmds[1], " ");
								char *info[12];
								int arg_inc = 0;

								while (arg)
								{
									info[arg_inc] = arg;
									arg_inc += 1;
									arg = strtok(NULL, " ");
								}
								int a = 0;
								while (a < arg_inc)
								{
									int port1 = atoi(info[a + 2]);
									addClientToList((&start), port1, info[a + 1], info[a]);
									a += 3;
								}
							}
							else
							{
								cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
								cse4589_print_and_log("msg from:%s\n[msg]:%s\n", cmds[0], cmds[1]);
								cse4589_print_and_log("[%s:END]\n", "RECEIVED");
							}
						}
						free(buffer_recv);
						free(buffer_len);
					}
				}
			}
		}
	}
}

void storeBufferedMessages(struct host **head_ref, char *sender_ip_address, char *receiver_IP, char *msg, int i, char *cmd[])
{
	struct host *last = start;

	struct message_buffer *new_message = (struct message_buffer *)malloc(sizeof(struct message_buffer));
	strcpy(new_message->message, msg);
	strcpy(new_message->receiver_IP, receiver_IP);
	new_message->sender_socket = i;

	while (last != NULL)
	{
		if (strcmp(last->ip_addr, receiver_IP) == 0)
		{
			break;
		}
		last = last->next_host;
	}
	// struct message_buffer *temp = last->buffer;
	if (last->buffer == NULL)
	{
		last->buffer = new_message;
		cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
		cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip_address, receiver_IP, cmd[1]);
		cse4589_print_and_log("[%s:END]\n", "RELAYED");
	}
	else
	{
		struct message_buffer *temp = last->buffer;
		while (temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = new_message;

		cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
		cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip_address, receiver_IP, cmd[1]);
		cse4589_print_and_log("[%s:END]\n", "RELAYED");
	}
}

void changeClientLoginStatus(int socket)
{
	struct host *temp = start;
	while (temp != NULL)
	{
		if (temp->fd == socket)
		{
			strcpy(temp->status, "logged-in");
			break;
		}
		temp = temp->next_host;
	}
}
bool isClientLoggedIn(char *reciever_ip_addr)
{
	struct host *loop = start;
	while (loop != NULL)
	{
		if (strcmp(loop->ip_addr, reciever_ip_addr) == 0)
		{
			if (strcmp(loop->status, "logged-in") == 0)
			{
				return true;
			}
		}
		loop = loop->next_host;
	}
	return false;
}

void list(char *commands[])
{
	cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
	struct host *host = start;
	int counter = 1;
	while (host != NULL)
	{
		cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", counter, host->hostname, host->ip_addr, host->port_num);
		host = host->next_host;
		counter++;
	}
	cse4589_print_and_log("[%s:END]\n", commands[0]);
	return;
}

void ip(char *command[])
{

	struct sockaddr_in sorcaddr, my_addr;
	int sckt;
	char myIP[16];
	sckt = socket(AF_INET, SOCK_DGRAM, 0);
	if (sckt < 0)
	{
		cse4589_print_and_log("[%s:ERROR]\n", command[0]);
		cse4589_print_and_log("[%s:END]\n", command[0]);
	}
	sorcaddr.sin_family = AF_INET;
	sorcaddr.sin_addr.s_addr = inet_addr("8.8.8.8");
	sorcaddr.sin_port = 53;
	if (connect(sckt, (struct sockaddr *)&sorcaddr, sizeof(sorcaddr)) < 0)
	{
		cse4589_print_and_log("[%s:ERROR]\n", command[0]);
		cse4589_print_and_log("[%s:END]\n", command[0]);
	}
	socklen_t len = sizeof(my_addr);
	if (getsockname(sckt, (struct sockaddr *)&my_addr, &len) < 0)
	{
		cse4589_print_and_log("[%s:ERROR]\n", command[0]);
		cse4589_print_and_log("[%s:END]\n", command[0]);
	}
	inet_ntop(AF_INET, &(my_addr.sin_addr), myIP, sizeof(myIP));
	cse4589_print_and_log("[%s:SUCCESS]\n", command[0]);
	cse4589_print_and_log("IP:%s\n", myIP);
	cse4589_print_and_log("[%s:END]\n", command[0]);
}

void login(char *commands[])
{
	if (loggedIn == 0)
	{
		struct sockaddr_in sorcaddr;

		bzero(&sorcaddr, sizeof(sorcaddr));
		sorcaddr.sin_family = AF_INET;
		if (inet_pton(AF_INET, commands[1], &sorcaddr.sin_addr) <= 0)
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
			return;
		}
		sorcaddr.sin_port = htons(atoi(commands[2]));

		client_sock = socket(AF_INET, SOCK_STREAM, 0);
		if (client_sock < 0)
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
			return;
		}

		char *ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
		strcpy(ip, commands[1]);

		bool is_valid_ip = isValidIP(ip);
		if (!is_valid_ip)
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
			return;
		}

		if (!valid_number(commands[2]))
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
			return;
		}

		if (connect(client_sock, (struct sockaddr *)&sorcaddr, sizeof(sorcaddr)) < 0)
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
			return;
		}
		fcntl(client_sock, F_SETFL, O_NONBLOCK);
		char msg[30];
		char *flag = "login";

		int length = strlen(flag) + strlen(client_port) + 1;
		char lengthbuffer[4];
		sprintf(lengthbuffer, "%-3d", length);

		strcat(msg, lengthbuffer);
		strcat(msg, flag);
		strcat(msg, " ");
		strcat(msg, client_port);
		if (send(client_sock, msg, strlen(msg), 0) == strlen(msg))
		{
			loggedIn = 1;
			cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
		}
		else
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
		}
		return;
	}
	else
	{
		char msg[30];
		char *flag = "login-again";

		int length = strlen(flag) + strlen(client_port) + 1;
		char lengthbuffer[4];
		sprintf(lengthbuffer, "%-3d", length);

		strcat(msg, lengthbuffer);
		strcat(msg, flag);
		strcat(msg, " ");
		strcat(msg, client_port);
		if (send(client_sock, msg, strlen(msg), 0) == strlen(msg))
		{
			cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
		}
		else
		{
			cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
			cse4589_print_and_log("[%s:END]\n", commands[0]);
		}
		return;
	}
}

void addClientToList(struct host **head_ref, int port, char ip_addr[], char host_name[], int socket)
{
	struct host *new_host = (struct host *)malloc(sizeof(struct host));
	struct host *last = *head_ref;

	new_host->port_num = port;
	new_host->fd = socket;
	strcpy(new_host->status, "logged-in");
	strcpy(new_host->ip_addr, ip_addr);
	strcpy(new_host->hostname, host_name);
	new_host->num_msg_rcv = 0;
	new_host->num_msg_sent = 0;
	new_host->next_host = NULL;
	if (*head_ref == NULL)
	{
		*head_ref = new_host;
		return;
	}

	while (last->next_host != NULL)
	{
		last = last->next_host;
	}
	last->next_host = new_host;
	return;
}
void sendBufferedMessages(int socket)
{
	struct host *last = start;
	struct message_buffer *buffer_message_list;
	while (last != NULL)
	{
		if (last->fd == socket)
		{
			buffer_message_list = last->buffer;
			while (buffer_message_list != NULL)
			{
				send(socket, buffer_message_list->message, strlen(buffer_message_list->message), 0) == strlen(buffer_message_list->message);
				buffer_message_list = buffer_message_list->next;
			}
			break;
		}
		last = last->next_host;
	}
}
void sendClientList(struct host *node, int socket, char *flag)
{
	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(msg, flag);

	while (node != NULL)
	{
		strcat(msg, " ");
		strcat(msg, node->hostname);
		strcat(msg, " ");
		strcat(msg, node->ip_addr);
		strcat(msg, " ");
		char str[5];
		sprintf(str, "%d", node->port_num);
		strcat(msg, str);

		node = node->next_host;
	}
	char *send_msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", (int)strlen(msg));
	strcpy(send_msg, lengthbuffer);
	strcat(send_msg, msg);
	int len = strlen(send_msg);
	int res = sendtotalmessage(socket, send_msg, &len);
	if (res == 0)
	{
	}
	else
	{
		cse4589_print_and_log("Sending List Failed");
	}
	free(msg);
}

int sendtotalmessage(int s, char *buf, int *len)
{
	int bytessent = 0;
	int bytesleft = *len;
	int n;
	while (bytessent < *len)
	{
		n = send(s, buf + bytessent, bytesleft, 0);
		if (n == -1)
		{
			break;
		}
		bytessent += n;
		bytesleft -= n;
	}
	*len = bytessent;
	if (n == -1)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

void updateListeningPort(struct host *node, char *port, int socket)
{
	while (node != NULL)
	{
		if (node->fd == socket)
		{
			node->port_num = atoi(port);
			break;
		}
		node = node->next_host;
	}
	return;
}

int receiveAllMessages(int s, char *buf, int len)
{
	int bytesreceived = 0;
	int bytesleft = len;
	int n;
	while (bytesreceived < len)
	{
		n = recv(s, buf + bytesreceived, bytesleft, 0);
		if (n == -1)
		{
			break;
		}
		bytesreceived += n;
		bytesleft -= n;
	}
	len = bytesreceived;
	if (n == -1)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

void refreshClientList(char *commands[])
{

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	char *send = "refreshlist";

	int length = strlen(commands[0]) + strlen(send) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, commands[0]);
	strcat(msg, " ");
	strcat(msg, send);

	int len;
	len = strlen(msg);

	if (sendtotalmessage(client_sock, msg, &len) == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	free(msg);
}

void deleteClientList(struct host **head_ref)
{
	struct host *current = *head_ref;
	struct host *next;

	while (current != NULL)
	{
		next = current->next_host;
		free(current);
		current = next;
	}
	*head_ref = NULL;
}

void logOutClient(char *commands[])
{

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	char *send = "logout";

	int length = strlen(commands[0]) + strlen(send) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, commands[0]);
	strcat(msg, " ");
	strcat(msg, send);

	int len;
	len = strlen(msg);

	if (sendtotalmessage(client_sock, msg, &len) == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	free(msg);
}

void logout(struct host *host, int socket)
{
	while (host != NULL)
	{
		if (host->fd == socket)
		{
			strcpy(host->status, "logged-out");
			break;
		}
		host = host->next_host;
	}
	return;
}

void sendMessage(char commands[])
{
	strtok(commands, "\n");
	int i = 0;
	char *p = strtok(commands, " ");
	char *cmds[3];
	while (p != NULL)
	{
		cmds[i] = p;
		i++;
		if (i <= 1)
		{
			p = strtok(NULL, " ");
		}
		else
		{
			p = strtok(NULL, "");
		}
	}
	char *ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(ip, cmds[1]);
	bool is_valid_ip = isValidIP(ip);
	if (is_valid_ip == false)
	{
		cse4589_print_and_log("[%s: INVALID IP ERROR]\n", cmds[0]);
		cse4589_print_and_log("[%s:INVALID IP END]\n", cmds[0]);
		return;
	}
	char *check_ip_addr = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(check_ip_addr, cmds[1]);
	bool result = is_ip_addr_in_client_list(start, check_ip_addr);
	if (result == false)
	{
		cse4589_print_and_log("[%s:ERROR]\n", cmds[0]);
		cse4589_print_and_log("[%s:END]\n", cmds[0]);
		return;
	}

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);

	int length = strlen(cmds[1]) + strlen(cmds[2]) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, cmds[1]);
	strcat(msg, " ");
	strcat(msg, cmds[2]);

	int len;
	len = strlen(msg);

	if (sendtotalmessage(client_sock, msg, &len) == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", cmds[0]);
		cse4589_print_and_log("[%s:END]\n", cmds[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR]\n", cmds[0]);
		cse4589_print_and_log("[%s:END]\n", cmds[0]);
	}

	// free(msg);
}

void broadCastMessage(char commands[])
{
	strtok(commands, "\n");
	int i = 0;
	char *p = strtok(commands, " ");
	char *cmds[2];
	while (p != NULL)
	{
		cmds[i] = p;
		i++;
		if (i <= 0)
		{
			p = strtok(NULL, " ");
		}
		else
		{
			p = strtok(NULL, "");
		}
	}

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);

	int length = strlen(cmds[0]) + strlen(cmds[1]) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, cmds[0]);
	strcat(msg, " ");
	strcat(msg, cmds[1]);

	int len;
	len = strlen(msg);

	if ((sendtotalmessage(client_sock, msg, &len) == 0))
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", cmds[0]);
		cse4589_print_and_log("[%s:END]\n", cmds[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR\n]", cmds[0]);
		cse4589_print_and_log("[%s:END]\n", cmds[0]);
	}
	free(msg);
}

bool is_ip_addr_in_client_list(struct host *host, char *ip_addr)
{
	while (host != NULL)
	{
		if (strcmp(host->ip_addr, ip_addr) == 0)
		{
			return true;
		}
		host = host->next_host;
	}
	return false;
}

bool valid_number(char *str)
{
	while (*str)
	{
		if (*str >= '0' && *str <= '9')
		{
			++str;
		}
		else
		{
			return false;
		}
	}
	return true;
}

bool isValidIP(char *ip_addr)
{
	int i, num, dots = 0;
	char *ptr;

	if (ip_addr == NULL)
	{

		return false;
	}
	ptr = strtok(ip_addr, ".");
	if (ptr == NULL)
	{
		return false;
	}
	while (ptr)
	{
		if (!valid_number(ptr))
		{

			return false;
		}

		num = atoi(ptr);
		if (num >= 0 && num <= 255)
		{
			ptr = strtok(NULL, ".");
			if (ptr != NULL)
			{
				dots++;
			}
		}
		else
		{

			return false;
		}
	}

	if (dots != 3)
	{
		return false;
	}
	return true;
}

void increase_msg_recv_count(int socket, struct host *host)
{
	while (host != NULL)
	{
		if (host->fd == socket)
		{
			host->num_msg_rcv = host->num_msg_rcv + 1;
			break;
		}
		host = host->next_host;
	}
}

void increase_msg_send_count(int socket, struct host *host)
{
	while (host != NULL)
	{
		if (host->fd == socket)
		{
			host->num_msg_sent = host->num_msg_sent + 1;
			break;
		}
		host = host->next_host;
	}
}

int getSocketByIp(struct host *host, char *ip_addr)
{

	while (host != NULL)
	{
		if (strcmp(host->ip_addr, ip_addr) == 0)
		{
			return host->fd;
		}
		host = host->next_host;
	}
	return 0;
}

char *get_ip_addr_by_socket(struct host *host, int socket)
{
	char *ip_addr;
	while (host != NULL)
	{
		if (host->fd == socket)
		{
			ip_addr = host->ip_addr;
			return ip_addr;
		}
		host = host->next_host;
	}
	return ip_addr;
}

// list sorted in increasing order
void sortedInsert(struct host **head, struct host *newNode)
{
	struct host dummy;
	struct host *current = &dummy;
	dummy.next_host = *head;

	while (current->next_host != NULL && current->next_host->port_num < newNode->port_num)
	{
		current = current->next_host;
	}

	newNode->next_host = current->next_host;
	current->next_host = newNode;
	*head = dummy.next_host;
}

// Given a list, change it to be in sorted order (using `sortedInsert()`).
void insertSort(struct host **head)
{
	struct host *result = NULL;	  // build the answer here
	struct host *current = *head; // iterate over the original list
	struct host *next;

	while (current != NULL)
	{
		// tricky: note the next pointer before we change it
		next = current->next_host;

		sortedInsert(&result, current);
		current = next;
	}

	*head = result;
}

void show_Statistcs(char *cmd[])
{
	cse4589_print_and_log("[%s:SUCCESS]\n", cmd[0]);
	struct host *host = start;
	int counter = 1;
	while (host != NULL)
	{
		cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", counter, host->hostname, host->num_msg_sent, host->num_msg_rcv, host->status);
		counter++;
		host = host->next_host;
	}
	cse4589_print_and_log("[%s:END]\n", cmd[0]);
	return;
}

void blockClient(char *commands[])
{
	char *ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(ip, commands[1]);
	int valid_ip = isValidIP(ip);
	if (valid_ip == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}

	char *temp_ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(temp_ip, commands[1]);
	int is_ip_inList = is_ip_addr_in_client_list(start, temp_ip);
	if (is_ip_inList == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);

	int length = strlen(commands[0]) + strlen(commands[1]) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, commands[0]);
	strcat(msg, " ");
	strcat(msg, commands[1]);

	int len;
	len = strlen(msg);

	if (sendtotalmessage(client_sock, msg, &len) == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR\n]", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	free(msg);
}

void unblockClient(char *commands[])
{

	char *ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(ip, commands[1]);
	int valid_ip = isValidIP(ip);
	if (valid_ip == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}
	char *temp_ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(temp_ip, commands[1]);
	int is_ip_inList = is_ip_addr_in_client_list(start, temp_ip);
	if (is_ip_inList == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}

	char *msg = (char *)malloc(sizeof(char) * BUFFER_SIZE);

	int length = strlen(commands[0]) + strlen(commands[1]) + 1;
	char lengthbuffer[4];
	sprintf(lengthbuffer, "%-3d", length);

	strcpy(msg, lengthbuffer);
	strcat(msg, commands[0]);
	strcat(msg, " ");
	strcat(msg, commands[1]);

	int len;
	len = strlen(msg);

	if (sendtotalmessage(client_sock, msg, &len) == 0)
	{
		cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	else
	{
		cse4589_print_and_log("[%s:ERROR\n]", commands[0]);
		cse4589_print_and_log("[%s:END]\n", commands[0]);
	}
	free(msg);
}

void show_blocked_clients(char *commands[])
{

	char *ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(ip, commands[1]);
	bool valid_ip = isValidIP(ip);
	if (valid_ip == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}
	char *temp_ip = (char *)malloc(sizeof(char) * BUFFER_SIZE);
	strcpy(temp_ip, commands[1]);
	bool is_ip_inList = is_ip_addr_in_client_list(start, temp_ip);
	if (is_ip_inList == false)
	{
		cse4589_print_and_log("[%s:ERROR\n", commands[0]);
		cse4589_print_and_log("{%s:END]\n", commands[0]);
		return;
	}
	cse4589_print_and_log("[%s:SUCCESS]\n", commands[0]);
	struct host *loop_host = start;
	struct blocked_clients *blocked_list;

	while (loop_host != NULL)
	{
		if (strcmp(loop_host->ip_addr, commands[1]) == 0)
		{
			blocked_list = loop_host->blocked;
			int list_id = 1;
			while (blocked_list != NULL)
			{
				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, blocked_list->hostname, blocked_list->ip_addr, blocked_list->port_num);
				list_id++;
				blocked_list = blocked_list->next;
			}
			cse4589_print_and_log("{%s:END]\n", commands[0]);
			return;
		}
		loop_host = loop_host->next_host;
	}
	cse4589_print_and_log("{%s:END]\n", commands[0]);
	return;
}

void blockClientinServerList(char *sender_ip_addr, char *blocked_ip_addr)
{
	struct host *last = start;
	struct host *temp_host = start;
	while (temp_host != NULL)
	{
		if (strcmp(temp_host->ip_addr, blocked_ip_addr) == 0)
		{
			break;
		}
		temp_host = temp_host->next_host;
	}
	struct blocked_clients *new_blocked_client = (struct blocked_clients *)malloc(sizeof(struct blocked_clients));
	strcpy(new_blocked_client->hostname, temp_host->hostname);
	strcpy(new_blocked_client->ip_addr, temp_host->ip_addr);
	new_blocked_client->port_num = temp_host->port_num;
	new_blocked_client->next = NULL;
	while (last != NULL)
	{
		if (strcmp(last->ip_addr, sender_ip_addr) == 0)
		{
			break;
		}
		last = last->next_host;
	}
	if (last->blocked == NULL)
	{
		last->blocked = new_blocked_client;
	}
	else
	{
		struct blocked_clients *temp = last->blocked;
		while (temp->next != NULL)
		{
			temp = temp->next;
		}
		temp->next = new_blocked_client;
	}
}

void unblockClientinServerList(char *sender_ip_addr, char *unblocked_ip_addr)
{
	struct host *loop_host = start;
	while (loop_host != NULL)
	{
		if (strcmp(loop_host->ip_addr, sender_ip_addr) == 0)
		{
			struct blocked_clients *blocked_list = loop_host->blocked;
			struct blocked_clients *prev;
			// deleteNodeInLinkedList(&(loop_host->blocked), blocked_ip_addr);
			if (blocked_list != NULL && (strcmp(blocked_list->ip_addr, unblocked_ip_addr) == 0))
			{
				blocked_list = blocked_list->next;
				loop_host->blocked = blocked_list;
				return;
			}
			while (blocked_list != NULL && (strcmp(blocked_list->ip_addr, unblocked_ip_addr) != 0))
			{
				prev = blocked_list;
				blocked_list = blocked_list->next;
			}
			if (blocked_list == NULL)
			{
				return;
			}
			prev->next = blocked_list->next;
			break;
		}
		loop_host = loop_host->next_host;
	}
}


bool checkBlockedOrNot(struct host *host, char *source_ip_addr, char *blocked_ip_addr)
{
	struct blocked_clients *temp;
	while (host != NULL)
	{
		if (strcmp(host->ip_addr, source_ip_addr) == 0)
		{
			temp = host->blocked;
			while (temp != NULL)
			{
				if (strcmp(temp->ip_addr, blocked_ip_addr) == 0)
				{
					return true;
				}
				temp = temp->next;
			}
		}
		host = host->next_host;
	}
	return false;
}

void deleteClient(struct host **host_ref, int socket)
{
	struct host *temp = *host_ref, *prev;

	if (temp != NULL && temp->fd == socket)
	{
		*host_ref = temp->next_host;
		free(temp);
		return;
	}
	while (temp != NULL && temp->fd != socket)
	{
		prev = temp;
		temp = temp->next_host;
	}

	if (temp == NULL)
		return;

	prev->next_host = temp->next_host;

	free(temp);
	return;
}

void deleteNodeInLinkedList(struct host **host_ref, char *ip_addr)
{
	struct host *temp = *host_ref, *prev;

	if (temp != NULL && temp->ip_addr == ip_addr)
	{
		*host_ref = temp->next_host;
		free(temp);
		return;
	}

	while (temp != NULL && (strcmp(temp->ip_addr, ip_addr) == 0))
	{
		prev = temp;
		temp = temp->next_host;
	}

	if (temp == NULL)
		return;

	prev->next_host = temp->next_host;

	free(temp);
}
