#include "../include/global.h"
#include "../include/logger.h"
#include "../include/libs.h"

using namespace std;

// global variables
string HOSTNAME;
string PORT;
string IP;
struct addrinfo *ADDR;
struct addrinfo hints;
int SOCK_FD;
vector<HostData> HD;


int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	char option = *argv[1];

    if(argc < 3)
	{
		CMD_Error("Too few arguments");
		exit(1);
	}	

	if(!validatePort(argv[2])) {
		CMD_Error("Invalid port number");
		exit(1);
	}

	switch (tolower(option))
	{
	case 'c':
		runClient(argv[2]); // start client
		break;

	case 's':
		runServer(argv[2]); // start server
		break;

	default:
		CMD_Error("Invalid option");
		return 1;
	}

	return 0;
}