/**
 * @file utils.cpp
 * @author your name (you@domain.com)
 * @brief
 * @version 0.1
 * @date 2022-03-23
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "../include/global.h"
#include "../include/logger.h"
#include "../include/libs.h"

void __initHostNamePort(char *port)
{
	// setting the host port
	PORT = port;

	// setting the hostname
	char __buf_hostname[1024];
	gethostname(__buf_hostname, sizeof(__buf_hostname) - 1);
	HOSTNAME = __buf_hostname;
	// printf("\n [__initHostNamePort] Hostname: %s\n", HOSTNAME.c_str());
}

/**
 * @brief method get the host's IP address by querying the Google DNS server
 *
 * @param port
 *
 * @reference http://stackoverflow.com/a/3120382
 */
void setMyIP(char *port)
{
	char ip_buf[256];
	int socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
	sockaddr_in sock;
	memset(&sock, 0, sizeof(sock));
	sock.sin_family = AF_INET;
	sock.sin_addr.s_addr = inet_addr("8.8.8.8");
	sock.sin_port = htons(53);
	connect(socket_fd, (struct sockaddr *)&sock, sizeof(sock));
	socklen_t len = sizeof(sock);
	getsockname(socket_fd, (struct sockaddr *)&sock, &len);
	inet_ntop(AF_INET, &sock.sin_addr, ip_buf, sizeof(ip_buf));
	IP = ip_buf;
	close(socket_fd);
	// printf("[DEBUG] IP: %s\n", IP.c_str());
}

/**
 * @brief method to initialize the client socket
 *
 * @param port
 */
void initClientSocket(char *port)
{
	setMyIP(port);
}

/**
 * @brief method to initialize the server socket
 *
 * @param port
 * @reference https://beej.us/guide/bgnet/html
 */

void createUDPSocket(char *port)
{
	setMyIP(port);
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;
	int addr_status = getaddrinfo(NULL, port, &hints, &ADDR);
	// printf("[DEBUG] getaddrinfo() returned %d\n", addr_status);
	if (addr_status == 0)
	{
		int sock_val = 1;
		SOCK_FD = socket(ADDR->ai_family, ADDR->ai_socktype, ADDR->ai_protocol);
		bind(SOCK_FD, ADDR->ai_addr, ADDR->ai_addrlen);
		freeaddrinfo(ADDR);
		// printf("[DEBUG] Socket created\n");
	}
	else
	{
		// printf("[ERROR] getaddrinfo() failed\n");
		exit(1);
	}
}

/**
 * @brief method to initialize the client socket based on the client mode
 *
 * @param clientMode
 * @param port
 */
void initSocket(char *port)
{
	__initHostNamePort(port);
	createUDPSocket(port);
}

HostData *createHostData(int cfd, string hostname, string ip, string port)
{
	HostData *data = new HostData;
	data->cfd = cfd;
	data->hostname = hostname;
	data->ip = ip;
	data->port = port;
	data->num_msg_sent = 0;
	data->num_msg_rcv = 0;
	data->status = STR_LOGGEDIN;
	return data;
}

HostData *findHostData(string ip, string port)
{
	int i = 0;
	while (i < HD.size())
	{
		HostData *data = &HD[i];
		if (data->ip == ip && data->port == port)
			return data;
		i++;
	}
	return NULL;
}

HostData *findHostData(string ip)
{
	int i = 0;
	while (i < HD.size())
	{
		HostData *data = &HD[i];
		if (data->ip == ip)
			return data;
		i++;
	}
	return NULL;
}

HostData *findHostData(int cfd)
{
	int i = 0;
	while (i < HD.size())
	{
		HostData *data = &HD[i];
		if (data->cfd == cfd)
			return data;
		i++;
	}
	return NULL;
}

vector<string> splitString(string str, char delimiter)
{
	// split message string into vector of strings separated by delimiter
	vector<string> tokens;
	string token;
	istringstream tokenStream(str);
	while (getline(tokenStream, token, delimiter))
	{
		tokens.push_back(token);
	}
	return tokens;
}

bool validateIP(string ip)
{
	// validate input IP address
	struct sockaddr_in sa;
	int result = inet_pton(AF_INET, ip.c_str(), &(sa.sin_addr));
	return result == 1;
}

bool validatePort(string port)
{
	// validate port number
	int port_num = atoi(port.c_str());
	return (port_num >= MAX_BUF_LEN && port_num <= MAX_SIZE);
}

void CMD_Error(string cmd)
{
	cse4589_print_and_log("[%s:ERROR]\n", cmd.c_str());
	cse4589_print_and_log("[%s:END]\n", cmd.c_str());
}

void CMD_IP()
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_IP.c_str());
	cse4589_print_and_log("IP:%s\n", IP.c_str());
	cse4589_print_and_log("[%s:END]\n", STR_IP.c_str());
}

void CMD_AUTHOR()
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_AUTHOR.c_str());
	cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "tulikash");
	cse4589_print_and_log("[%s:END]\n", STR_AUTHOR.c_str());
}

void CMD_PORT()
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_PORT.c_str());
	cse4589_print_and_log("PORT:%s\n", PORT.c_str());
	cse4589_print_and_log("[%s:END]\n", STR_PORT.c_str());
}

void CMD_LIST()
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_LIST.c_str());
	sort(HD.begin(), HD.end());
	int i = 0;
	while (i < HD.size())
	{
		HostData *data = &HD[i];
		cse4589_print_and_log("%-5d%-35s%-20s%-8s\n", i + 1, data->hostname.c_str(), data->ip.c_str(), data->port.c_str());
		i++;
	}
	cse4589_print_and_log("[%s:END]\n", STR_LIST.c_str());
}

void CMD_EVENT(string ip, string msg)
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_RECEIVED.c_str());
	cse4589_print_and_log("msg from:%s\n[msg]:%s\n", ip.c_str(), msg.c_str());
	cse4589_print_and_log("[%s:END]\n", STR_RECEIVED.c_str());
}

void CMD_STATISTICS()
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_STATS.c_str());
	sort(HD.begin(), HD.end());
	int i = 0;
	while (i < HD.size())
	{
		cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", i + 1, HD[i].hostname.c_str(), HD[i].num_msg_sent, HD[i].num_msg_rcv, HD[i].status.c_str());
		i++;
	}
	cse4589_print_and_log("[%s:END]\n", STR_STATS.c_str());
}

void CMD_EVENTS(string from, string msg, string to)
{
	cse4589_print_and_log("[%s:SUCCESS]\n", STR_RELAYED.c_str());
	cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", (const char *)from.c_str(), (const char *)to.c_str(), (const char *)msg.c_str());
	cse4589_print_and_log("[%s:END]\n", STR_RELAYED.c_str());
}

void CMD_BLOCKED(string ip)
{
	// validate
	if (!(validateIP(ip)) || findHostData(ip) == NULL)
	{
		CMD_Error(STR_BLOCKEDLIST);
		return;
	}

	HostData *hd = findHostData(ip);

	cse4589_print_and_log("[%s:SUCCESS]\n", STR_BLOCKEDLIST.c_str());
	int i = 0;
	while (i < hd->blockeduser.size())
	{
		HostData *new_hd = findHostData(hd->blockeduser[i]);
		cse4589_print_and_log("%-5d%-35s%-20s%-8s\n", i + 1, new_hd->hostname.c_str(), new_hd->ip.c_str(), new_hd->port.c_str());
		i++;
	}
	cse4589_print_and_log("[%s:END]\n", STR_BLOCKEDLIST.c_str());
}