/**
 * @file client.cpp
 * @author your name (you@domain.com)
 * @brief
 * @version 0.1
 * @date 2022-03-23
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "../include/libs.h"

// global variables for client side
bool isLoggedIn = false;
addrinfo *ptr1;
addrinfo *ptr2;
string buf_str = "", input_ip = "", input_port = "";

// helper functions
vector<string> getTokensFromStdin(char *_buf, int len)
{
    read(fileno(stdin), _buf, len);
    string buf = _buf;
    // buf = buf.substr(0, buf.length() - 1);
    buf = TRIM_STR(buf, len);
    vector<string> tokens = splitString(buf, ' ');
    // cout << "[getTokensFromStdin] buf: " << buf << " & token[0]" << tokens[0] << endl;
    return tokens;
}

void loginHelper(vector<string> tokens)
{
    // declare all the variables
    string command = tokens[0];
    string ip = tokens[1];
    string port = tokens[2];
    char recv_buf[MAX_SIZE];
    string recv_str = "";
    vector<string> recv_vec_data;
    vector<string> recv_vec;

    // cout << "ip: " << ip << " port: " << port << endl;
    HD.clear();
    // cout << validateIP(ip) && validatePort(port);

    if (validateIP(ip) && validatePort(port))
    {
        buf_str = "";
        string flag = "1 ";
        buf_str = flag + HOSTNAME + " " + IP + " " + PORT;
        if (input_ip == ip && input_port == port)
        {
            // memset(recv_buf, 0, sizeof(recv_buf));
            std::fill_n(recv_buf, sizeof recv_buf, 0);
            isLoggedIn = true;

            send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
            recv(SOCK_FD, recv_buf, sizeof recv_buf, 0);

            recv_str = recv_buf;
            recv_vec = splitString(recv_str, ' ');

            for (int i = 0; i < recv_vec.size(); ++i)
            {
                recv_vec_data = splitString(recv_vec[i], ' ');
                int condition = atoi(recv_vec_data[0].c_str());
                if (condition == 9)
                {
                    // cout<< buf_str;
                    buf_str = recv_vec_data[3];
                    int i = 4;
                    while (i < recv_vec_data.size())
                    {
                        buf_str = buf_str + " " + recv_vec_data[i];
                        i++;
                    }
                    CMD_EVENT(recv_vec_data[1], buf_str);
                }
                else if (condition == 1)
                {
                    HD.clear();
                    int i = 1;
                    while (i < (recv_vec_data.size() - 1))
                    {
                        if (findHostData(recv_vec_data[i + 1], recv_vec_data[i + 2]) == NULL)
                        {
                            HD.push_back(*createHostData(-2, recv_vec_data[i], recv_vec_data[i + 1], recv_vec_data[i + 2]));
                        }
                        i += 3;
                    }
                    // break;
                }
                else if (condition == 6)
                {
                    buf_str = recv_vec_data[2];
                    int i = 3;
                    while (i < recv_vec_data.size())
                    {
                        buf_str = buf_str + " " + recv_vec_data[i];
                        i++;
                    }
                    CMD_EVENT(recv_vec_data[1], buf_str);
                }
            }

            cse4589_print_and_log("[%s:SUCCESS]\n", command.c_str());
            cse4589_print_and_log("[%s:END]\n", command.c_str());
            // break;
        }
        else
        {
            input_ip = ip;
            input_port = port;
        }
        int info = getaddrinfo(ip.c_str(), port.c_str(), &hints, &ptr1);
        if (info != 0)
        {
            cse4589_print_and_log("[%s:ERROR]\n", command.c_str());
            cse4589_print_and_log("[%s:END]\n", command.c_str());
            // break;
        }

        for (ptr2 = ptr1; ptr2 != NULL; ptr2 = ptr2->ai_next)
        {
            if (connect(SOCK_FD, ptr2->ai_addr, ptr2->ai_addrlen) == -1)
            {
                close(SOCK_FD);
                continue;
            }
            break;
        }

        if (ptr2 == NULL)
        {
            cse4589_print_and_log("[%s:ERROR]\n", command.c_str());
            cse4589_print_and_log("[%s:END]\n", command.c_str());
            // break;
        }

        freeaddrinfo(ptr1);
        isLoggedIn = true;
        send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
        cse4589_print_and_log("[%s:SUCCESS]\n", command.c_str());
        cse4589_print_and_log("[%s:END]\n", command.c_str());
        // break;
    }
    else
    {
        cse4589_print_and_log("[%s:ERROR]\n", command.c_str());
        cse4589_print_and_log("[%s:END]\n", command.c_str());
        // break;
    }
}

int runClient(string port)
{
    initSocket((char *)port.c_str());

    // variables
    fd_set fs_stdin;
    int fdmax = SOCK_FD;
    char _buf[MAX_SIZE];
    vector<string> input_tokens;

    string buf_str = "", input_ip = "", input_port = "";

    // event loop
    while (1)
    {
        FD_ZERO(&fs_stdin);
        std::fill_n(_buf, sizeof _buf, 0);

        if (!isLoggedIn)
        {
            FD_SET(fileno(stdin), &fs_stdin);
            select(1, &fs_stdin, NULL, NULL, NULL);
            if (FD_ISSET(fileno(stdin), &fs_stdin))
            {
                read(fileno(stdin), _buf, sizeof _buf);
                buf_str = _buf;
                buf_str = buf_str.substr(0, buf_str.length() - 1);
                vector<string> tokens = splitString(buf_str, ' ');
                int argc = tokens.size();
                fflush(stdin);

                string command = tokens[0];

                if (command == STR_LOGIN && argc == 3)
                {
                    loginHelper(tokens);
                }
                else if (command == STR_EXIT)
                {
                    cse4589_print_and_log("[%s:SUCCESS]\n", command.c_str());
                    string flag = "5 ";
                    buf_str = flag + IP;
                    send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                    cse4589_print_and_log("[%s:END]\n", command.c_str());
                    exit(0);
                }

                else if (command == STR_IP)
                {
                    CMD_IP();
                }

                else if (command == STR_AUTHOR)
                {
                    CMD_AUTHOR();
                }

                else if (command == STR_PORT)
                {
                    CMD_PORT();
                }
                else
                {
                    cse4589_print_and_log("[%s:ERROR]\n", command.c_str());
                    cse4589_print_and_log("[%s:END]\n", command.c_str());
                }
            }
            else
            {
                continue;
            }
        }
        else
        {
            FD_SET(fileno(stdin), &fs_stdin);
            FD_SET(SOCK_FD, &fs_stdin);
            fdmax = SOCK_FD;
            select(fdmax + 1, &fs_stdin, NULL, NULL, NULL);
            if (FD_ISSET(fileno(stdin), &fs_stdin))
            {
                read(fileno(stdin), _buf, sizeof _buf);
                buf_str = _buf;
                fflush(stdin);
                buf_str = buf_str.substr(0, buf_str.length() - 1);
                input_tokens = splitString(buf_str, ' ');

                if (input_tokens[0] == STR_LOGOUT)
                {
                    cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                    string flag = "4 ";
                    buf_str = flag + IP;
                    send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                    // close(SOCK_FD);
                    isLoggedIn = false;
                    cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                }
                else if (input_tokens[0] == STR_EXIT)
                {
                    cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                    string flag = "5 ";
                    buf_str = flag + IP;
                    send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                    cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                    exit(0);
                }
                else if (input_tokens[0] == STR_IP)
                {
                    CMD_IP();
                }
                else if (input_tokens[0] == STR_AUTHOR)
                {
                    CMD_AUTHOR();
                }
                else if (input_tokens[0] == STR_PORT)
                {
                    CMD_PORT();
                }
                else if (input_tokens[0] == STR_LIST)
                {
                    CMD_LIST();
                }
                else if (input_tokens[0] == STR_REFRESH)
                {
                    cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                    buf_str = "7";
                    buf_str = buf_str + " " + IP;
                    send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                    cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                }
                else if (input_tokens[0] == STR_BROADCAST)
                {
                    cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                    string flag = "6";
                    buf_str = input_tokens[1];
                    int i = 2;
                    while (i < input_tokens.size())
                    {
                        buf_str += " " + input_tokens[i];
                        i++;
                    }
                    buf_str = flag + " " + IP + " " + buf_str;
                    send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                    cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                }
                else if (input_tokens[0] == STR_BLOCK)
                {
                    if (findHostData(input_tokens[1]) == NULL || validateIP(input_tokens[1]))
                    {
                        cse4589_print_and_log("[%s:ERROR]\n", input_tokens[0].c_str());
                        cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                    }
                    else
                    {
                        // HostData* hd = findHostData(SOCK_FD);
                        HostData *hd = findHostData(IP);
                        if (hd == NULL)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                            string flag = "2 ";
                            buf_str = flag + IP + " " + input_tokens[1];
                            send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                            cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                            // break;
                        }

                        vector<string>::iterator ret;
                        ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), input_tokens[1]);
                        if (ret == hd->blockeduser.end())
                        {
                            hd->blockeduser.push_back(input_tokens[1]);
                            cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                            string flag = "2 ";
                            buf_str = flag + IP + " " + input_tokens[1];
                            send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                            cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                            // break;
                        }
                    }
                }
                else if (input_tokens[0] == STR_UNBLOCK)
                {
                    if (findHostData(input_tokens[1]) == NULL)
                    {
                        cse4589_print_and_log("[%s:ERROR]\n", input_tokens[0].c_str());
                        cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                    }
                    else
                    {
                        HostData *hd = findHostData(SOCK_FD);
                        if (hd == NULL)
                        {
                            string flag = "3 ";
                            buf_str = flag + IP + " " + input_tokens[1];
                            send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                            cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                            cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                        }
                        else
                        {
                            vector<string>::iterator ret;
                            ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), input_tokens[1]);
                            if (ret != hd->blockeduser.end())
                            {
                                string flag = "3 ";
                                buf_str = flag + IP + " " + input_tokens[1];
                                send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                                cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                                cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                            }
                        }
                    }
                }
                else if (input_tokens[0] == STR_SEND)
                {
                    string to_ip = input_tokens[1];
                    // cout<< buf_str;
                    string err = "SEND";
                    if (!validateIP(to_ip) || findHostData(to_ip) == NULL)
                    {
                        CMD_Error(err);
                    }
                    else
                    {
                        string buf_str = "9 ";
                        buf_str = buf_str + IP + " " + to_ip;
                        for (int i = 2; i < input_tokens.size(); ++i)
                        {
                            buf_str = buf_str + " " + input_tokens[i];
                        }
                        // cout<< buf_str;
                        send(SOCK_FD, (const char *)buf_str.c_str(), buf_str.length(), 0);
                        cse4589_print_and_log("[%s:SUCCESS]\n", input_tokens[0].c_str());
                        cse4589_print_and_log("[%s:END]\n", input_tokens[0].c_str());
                    }
                }
            }
            else if (FD_ISSET(SOCK_FD, &fs_stdin))
            {
                if (recv(SOCK_FD, _buf, sizeof _buf, 0) == 0)
                {
                    close(SOCK_FD);
                    SOCK_FD = 0;
                    isLoggedIn = false;
                }
                else
                {
                    buf_str = _buf;
                    input_tokens = splitString(buf_str, ' ');
                    int condition = atoi(input_tokens[0].c_str());
                    if (condition == 9)
                    {
                        // cout<< buf_str;
                        buf_str = input_tokens[3];
                        int i = 4;
                        while (i < input_tokens.size())
                        {
                            buf_str = buf_str + " " + input_tokens[i];
                            i++;
                        }
                        CMD_EVENT(input_tokens[1], buf_str);
                    }
                    else if (condition == 1)
                    {
                        HD.clear();
                        int i = 1;
                        while (i < (input_tokens.size() - 1))
                        {
                            if (findHostData(input_tokens[i + 1], input_tokens[i + 2]) == NULL)
                            {
                                HD.push_back(*createHostData(-2, input_tokens[i], input_tokens[i + 1], input_tokens[i + 2]));
                            }
                            i += 3;
                        }
                    }
                    else if (condition == 6)
                    {
                        buf_str = input_tokens[2];
                        int i = 3;
                        while (i < input_tokens.size())
                        {
                            buf_str += " " + input_tokens[i];
                            i++;
                        }
                        CMD_EVENT(input_tokens[1], buf_str);
                    }
                }
            }
        }
    }
    return 0;
}