/**
 * @file server.cpp
 * @author Tulika Sharma (tulikash@buffalo.edu)
 * @brief
 * @version 0.1
 * @date 2022-03-23
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "../include/global.h"
#include "../include/logger.h"
#include "../include/libs.h"

int runServer(string port)
{

	// init
	initSocket((char *)port.c_str());
	int yes = 1;
	setsockopt(SOCK_FD, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
	listen(SOCK_FD, PATH_LEN);

	// variables
	struct sockaddr_storage remoteADDR;
	socklen_t addrlen = sizeof remoteADDR;

	char buf_str[MAX_SIZE];
	string msg;
	vector<string> tokens;
	// struct addrinfo *ai, *p;

	fd_set readfds;
	int fdtemp;
	int mainlist[PATH_LEN] = {0};
	int fdmax = SOCK_FD;

	// core loop
	do
	{
		// init fd
		FD_ZERO(&readfds);
		FD_SET(fileno(stdin), &readfds);
		FD_SET(SOCK_FD, &readfds);

		int i = 0;

		while (i < PATH_LEN)
		{ // add child sockets to set
			if (mainlist[i] > 0)
				FD_SET(mainlist[i], &readfds);
			if (mainlist[i] > fdmax)
				fdmax = mainlist[i];
			i++;
		}
		memset(&buf_str[0], 0, sizeof(buf_str));
		msg = "";

		select(fdmax + 1, &readfds, NULL, NULL, NULL);

		if (FD_ISSET(fileno(stdin), &readfds))
		{
			read(fileno(stdin), buf_str, sizeof buf_str);
			fflush(stdin);
			msg = buf_str;
			msg = msg.substr(0, msg.length() - 1);
			vector<string> tokens = splitString(msg, ' ');

			if (tokens[0] == STR_LIST)
			{
				CMD_LIST();
			}
			else if (tokens[0] == STR_STATS)
			{
				CMD_STATISTICS();
			}
			else if (tokens[0] == STR_IP)
			{
				CMD_IP();
			}
			else if (tokens[0] == STR_AUTHOR)
			{
				CMD_AUTHOR();
			}
			else if (tokens[0] == STR_PORT)
			{
				CMD_PORT();
			}
			else if (tokens[0] == STR_BLOCKEDLIST)
			{
				CMD_BLOCKED(tokens[1]);
			}
			else
			{
				return -1;
			}
		}
		else if (FD_ISSET(SOCK_FD, &readfds))
		{
			fdtemp = accept(SOCK_FD, (struct sockaddr *)&remoteADDR, &addrlen);

			int i = 0;
			while (i < PATH_LEN)
			{
				if (mainlist[i] == 0)
				{
					mainlist[i] = fdtemp;
					break;
				}
				i++;
			}

			recv(fdtemp, buf_str, sizeof buf_str, 0);

			msg = buf_str;
			tokens = splitString(msg, ' ');

			int condition = atoi(tokens[0].c_str());

			if (condition == 9)
			{
				string from_ip = tokens[1];
				string to_ip = tokens[2];

				HostData *hd = findHostData(to_ip);
				HostData *hd2 = findHostData(from_ip);

				if (hd == NULL)
					break;
				// cout<< msg;
				vector<string>::iterator ret;

				ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), from_ip);
				if (ret == hd->blockeduser.end())
				{
					if (hd->status == STR_LOGGEDIN)
					{
						// cout<< msg;
						send(hd->cfd, (const char *)msg.c_str(), msg.length(), 0);
						hd->num_msg_rcv = hd->num_msg_rcv + 1;
						hd2->num_msg_sent = hd2->num_msg_sent + 1;
						string message;
						message = tokens[3];
						int m = 4;
						while (m < tokens.size())
						{
							message = message + " " + tokens[m];
							m++;
						}
						CMD_EVENTS(from_ip, message, to_ip);
					}
					else
					{
						hd->bufmsgs.push_back(msg);
						hd->num_msg_rcv = hd->num_msg_rcv + 1;
						hd2->num_msg_sent = hd2->num_msg_sent + 1;
						string message;
						message = tokens[3];
						int m = 4;
						while (m < tokens.size())
						{
							message = message + " " + tokens[m];
							m++;
						}
						CMD_EVENTS(from_ip, message, to_ip);
					}
				}
			}
			else if (condition == 1)
			{
				string host = tokens[1];
				string host_ip = tokens[2];
				string port = tokens[3];
				HostData *hd = findHostData(fdtemp);

				if (hd == NULL)
				{
					hd = createHostData(fdtemp, host, host_ip, port);
					HD.push_back(*hd);
				}
				else
				{
					hd->status = STR_LOGGEDIN;
					if (!hd->bufmsgs.empty())
					{
						string mgs = "";
						string hu = "/n";
						for (vector<string>::iterator it = hd->bufmsgs.begin(); it < hd->bufmsgs.end(); it++)
						{
							mgs = mgs + hu + *it;
						}
						send(hd->cfd, (const char *)mgs.c_str(), mgs.length(), 0);
						hd->bufmsgs.clear();
					}
				}
				string message = "1";
				for (unsigned int i = 0; i < HD.size(); ++i)
				{
					if (HD[i].status == STR_LOGGEDIN)
					{
						message = message + " " + HD[i].hostname + " " + HD[i].ip + " " + HD[i].port;
					}
				}

				send(fdtemp, message.c_str(), strlen(message.c_str()), 0);
			}
			else if (condition == 2)
			{
				string from_ip = tokens[1];
				string to_ip = tokens[2];
				HostData *hd = findHostData(from_ip);
				if (!(validateIP(to_ip)) || findHostData(to_ip) == NULL)
				{
					CMD_Error(STR_BLOCK);
					break;
				}
				vector<string>::iterator ret;
				ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), to_ip);
				if (ret == hd->blockeduser.end())
				{
					hd->blockeduser.push_back(to_ip);
					break;
				}
				else
				{
					CMD_Error(STR_BLOCK);
					break;
				}
			}
			else if (condition == 3)
			{
				string from_ip = tokens[1];
				string to_ip = tokens[2];
				HostData *hd = findHostData(from_ip);
				if (!(validateIP(to_ip)) || findHostData(to_ip) == NULL)
				{					
					break;
				}
				vector<string>::iterator ret;
				ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), to_ip);
				if (ret == hd->blockeduser.end())
				{
					CMD_Error(STR_BLOCK);
					break;
				}
				else
				{
					hd->blockeduser.erase(ret);
					break;
				}
			}
			else if (condition == 4)
			{
				string ip_addr = tokens[1];
				HostData *hd = findHostData(ip_addr);
				if (hd != NULL)
					hd->status = STR_LOGGEDOUT;
			}
			else if (condition == 5)
			{				
				int i = 0;

				while (i < HD.size())
				{
					if (HD[i].cfd == fdtemp)
						HD.erase(HD.begin() + i--);

					++i;
				}
			}
			else if (condition == 6)
			{
				string from_ip = tokens[1];
				HostData *hd2 = findHostData(from_ip);
				string con = "255.255.255.255";
				if (hd2 != NULL)
				{
					int i = 0;
					while (i < HD.size())
					{
						if (HD[i].ip == from_ip)
							continue;
						vector<string>::iterator ret;
						ret = find(hd2->blockeduser.begin(), hd2->blockeduser.end(), HD[i].ip);
						if (ret == hd2->blockeduser.end())
						{
							if (hd2->status == STR_LOGGEDIN)
							{
								send(hd2->cfd, (const char *)msg.c_str(), msg.length(), 0);
								HD[i].num_msg_rcv = HD[i].num_msg_rcv + 1;
								hd2->num_msg_sent = hd2->num_msg_sent + 1;
								string message;
								message = tokens[2];
								int m = 3;
								while (m < tokens.size())
								{
									message +=  " " + tokens[m];
									m++;
								}
								CMD_EVENTS(from_ip, message, con);
							}
						}
						i++;
					}
				}
			}
			else if (condition == 7)
			{
				string message = "1";
				unsigned int i = 0;
				while (i < HD.size())
				{
					if (HD[i].status == STR_LOGGEDIN)
					{
						message += " " + HD[i].hostname + " " + HD[i].ip + " " +
								   HD[i].port;
					}

					++i;
				}
				send(fdtemp, message.c_str(), strlen(message.c_str()), 0);
			}
		}
		else
		{
			int i = 0;
			while (i < PATH_LEN)
			{
				fdtemp = mainlist[i];
				if (FD_ISSET(fdtemp, &readfds))
				{
					if (read(fdtemp, buf_str, sizeof buf_str) == 0)
					{ // Check if closing
						close(fdtemp);
						mainlist[i] = 0;
					}
					else
					{ // handle events
						msg = buf_str;
						tokens = splitString(msg, ' ');
						int condition = atoi(tokens[0].c_str());
						if (condition == 9)
						{
							string from_ip = tokens[1];
							string to_ip = tokens[2];
							// cout<< msg;
							HostData *hd = findHostData(to_ip);
							HostData *hd2 = findHostData(from_ip);

							if (hd == NULL)
							{
								break;
							}
							vector<string>::iterator ret;
							ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), from_ip);
							if (ret == hd->blockeduser.end())
							{
								if (hd->status == STR_LOGGEDIN)
								{
									// cout<< msg;
									send(hd->cfd, (const char *)msg.c_str(), msg.length(), 0);
									hd->num_msg_rcv = hd->num_msg_rcv + 1;
									hd2->num_msg_sent = hd2->num_msg_sent + 1;
									string message;
									message = tokens[3];
									for (int m = 4; m < tokens.size(); m++)
									{
										message = message + " " + tokens[m];
									}
									CMD_EVENTS(from_ip, message, to_ip);
								}
								else
								{
									hd->bufmsgs.push_back(msg);
									hd->num_msg_rcv = hd->num_msg_rcv + 1;
									hd2->num_msg_sent = hd2->num_msg_sent + 1;
									string message;
									message = tokens[3];
									int m = 4;
									while (m < tokens.size())
									{
										message = message + " " + tokens[m];
										m++;
									}
									CMD_EVENTS(from_ip, message, to_ip);
								}
							}
						}
						else if (condition == 1)
						{
							string host = tokens[1];
							string host_ip = tokens[2];
							string port = tokens[3];
							HostData *hd = findHostData(fdtemp);

							if (hd == NULL)
							{
								hd = createHostData(fdtemp, host, host_ip, port);
								HD.push_back(*hd);
							}
							else
							{
								hd->status = STR_LOGGEDIN;
								if (!hd->bufmsgs.empty())
								{
									for (vector<string>::iterator it = hd->bufmsgs.begin(); it < hd->bufmsgs.end(); it++)
									{
										string mgs = *it;
										send(hd->cfd, (const char *)mgs.c_str(), mgs.length(), 0);
									}
									hd->bufmsgs.clear();
								}
							}
							string message = "1";
							unsigned int i = 0;
							while (i < HD.size())
							{
								if (HD[i].status == STR_LOGGEDIN)
								{
									message = message + " " + HD[i].hostname + " " + HD[i].ip + " " + HD[i].port;
								}
								++i;
							}

							send(fdtemp, message.c_str(), strlen(message.c_str()), 0);
						}
						else if (condition == 2)
						{
							string from_ip = tokens[1];
							string to_ip = tokens[2];
							HostData *hd = findHostData(from_ip);
							if (!(validateIP(to_ip)) || findHostData(to_ip) == NULL)
							{
								CMD_Error(STR_BLOCK);
							}
							vector<string>::iterator ret;
							ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), to_ip);
							if (ret == hd->blockeduser.end())
							{
								hd->blockeduser.push_back(to_ip);
							}
							else
							{
								CMD_Error(STR_BLOCK);
							}
						}
						else if (condition == 3)
						{
							string from_ip = tokens[1];
							string to_ip = tokens[2];
							HostData *hd = findHostData(from_ip);
							if (!(validateIP(to_ip)) || findHostData(to_ip) == NULL)
							{
								CMD_Error(STR_UNBLOCK);
							}
							vector<string>::iterator ret;
							ret = find(hd->blockeduser.begin(), hd->blockeduser.end(), to_ip);
							if (ret == hd->blockeduser.end())
							{
								CMD_Error(STR_UNBLOCK);
							}
							else
							{
								hd->blockeduser.erase(ret);
							}
						}
						else if (condition == 4)
						{
							string ip_addr = tokens[1];
							HostData *hd = findHostData(ip_addr);
							if (hd != NULL)
							{
								hd->status = STR_LOGGEDOUT;
							}
						}
						else if (condition == 5)
						{
							int i = 0;
							while (i < HD.size())
							{
								if (HD[i].cfd == fdtemp)
								{
									HD.erase(HD.begin() + i--);
								}
								++i;
							}
						}
						else if (condition == 6)
						{
							string from_ip = tokens[1];
							HostData *hd2 = findHostData(from_ip);
							if (hd2 == NULL)
							{
								break;
							}
							string con = "255.255.255.255";
							int i = 0;

							while (i < HD.size())
							{
								if (HD[i].ip == from_ip)
								{
									continue;
								}
								vector<string>::iterator ret;
								ret = find(HD[i].blockeduser.begin(), HD[i].blockeduser.end(), from_ip);
								if (ret == HD[i].blockeduser.end())
								{
									if (HD[i].status == STR_LOGGEDIN)
									{
										send(HD[i].cfd, (const char *)msg.c_str(), msg.length(), 0);
										HD[i].num_msg_rcv = HD[i].num_msg_rcv + 1;
										hd2->num_msg_sent = hd2->num_msg_sent + 1;
										string message;
										message = tokens[2];
										for (int m = 3; m < tokens.size(); m++)
										{
											message = message + " " + tokens[m];
										}

										CMD_EVENTS(from_ip, message, con);
									}
								}
								++i;
							}
						}
						else if (condition == 7)
						{
							string message = "1";
							unsigned int i = 0;
							while (i < HD.size())
							{
								if (HD[i].status == STR_LOGGEDIN)
								{
									message += " " + HD[i].hostname + " " + HD[i].ip + " " +
											   HD[i].port;
								}
								++i;
							}
							send(fdtemp, message.c_str(), strlen(message.c_str()), 0);
						}
					}
				}
				i++;
			}
		}
	} while (1);
	return 0;
}