#ifndef GLOBAL_H_
#define GLOBAL_H_

#define HOSTNAME_LEN 128
#define PATH_LEN 256
#define MAX_BUF_LEN 1024
#define MAX_SIZE 65535

#include <string>

using namespace std;

// string constants used in the program
const string STR_IP = "IP";
const string STR_PORT = "PORT";
const string STR_AUTHOR = "AUTHOR";
const string STR_EXIT = "EXIT";
const string STR_LIST = "LIST";
const string STR_BLOCK = "BLOCK";
const string STR_UNBLOCK = "UNBLOCK";
const string STR_SEND = "SEND";
const string STR_REFRESH = "REFRESH";
const string STR_BROADCAST = "BROADCAST";
const string STR_LOGIN = "LOGIN";
const string STR_LOGOUT = "LOGOUT";
const string STR_BLOCKEDLIST = "BLOCKED";
const string STR_STATS = "STATISTICS";
const string STR_RELAYED = "RELAYED";
const string STR_RECEIVED = "RECEIVED";
const string STR_LOGGEDIN = "logged-in";
const string STR_LOGGEDOUT = "logged-out";


#endif
