/**
 * @file libs.h
 * @author Tulika Sharma (tulikash@buffalo.edu)
 * @brief
 * @version 0.1
 * @date 03-02-2022
 */

#ifndef LIBS_H_
#define LIBS_H_

// all the includes
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>
#include <string>
#include <sstream>


#include "../include/global.h"
#include "../include/logger.h"

#define TRIM_SPACE(s) s.erase(remove(s.begin(), s.end(), ' '), s.end())
#define TRIM_NEWLINE(s) s.erase(remove(s.begin(), s.end(), '\n'), s.end())
#define TRIM_STR(s, l) s.substr(0, l-1)

using namespace std;

// core structure of the hostdata
struct HostData
{
  int cfd;
  std::string hostname;
  std::string ip;
  std::string port;
  int num_msg_sent;
  int num_msg_rcv;
  std::string status;
  std::vector<std::string> bufmsgs;
  std::vector<std::string> blockeduser;

  bool operator<(const HostData &rhs) const
  {
    return atoi(port.c_str()) < atoi(rhs.port.c_str());
  }
};

// variables
extern std::string HOSTNAME;
extern std::string PORT;
extern std::string IP;
extern struct addrinfo *ADDR;
extern struct addrinfo hints;
extern int SOCK_FD;
extern std::vector<HostData> HD;

// socket related functions
void initSocket(char *port);
HostData *createHostData(int cfd, string hostname, string ip, string port);
HostData *findHostData(string ip, string port);
HostData *findHostData(string ip);
HostData *findHostData(int cfd);

// utility functions
vector<string> splitString(string str, char delimiter);
bool validateIP(string ip);
bool validatePort(string port);


// logging methods
void CMD_Error(string cmd);
void CMD_AUTHOR();
void CMD_IP();
void CMD_PORT();
void CMD_LIST();
void CMD_EVENT(string client_ip, string msg);
void CMD_STATISTICS();
void CMD_EVENTS(string from_ip, string msg, string to_ip);
void CMD_BLOCKED(string cli_ip);

// the main processes in the application
int runServer(string MYPORT);
int runClient(string MYPORT);

#endif