/**
 * @lohitcho_assignment1
 * @author  Gaddipati Lohit Chowdary <lohitcho@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include<iostream>
#include<sstream>
#include<string>
#include<cstdlib>
#include<sys/types.h>
#include<netdb.h>
#include<sys/wait.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<signal.h>
#include<errno.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<ifaddrs.h>
#include<vector>
#include<algorithm>
#include<cctype>

#define PORT "9000"

#define STDIN 0

#include "../include/global.h"
#include "../include/logger.h"

using namespace std;
/* Here we create a structure for storing the IP address of the blockced receipient*/
struct Block
{
	char IP[50];
};
/* Here is a data structure for storing the message that needs to be sent across the servers*/
struct message
{
	char info[1400];

};
/* In this data structure we store the state of the each client, like the IP address, its log_status, if its in the block list or not and the message that needs to be sent*/
/* we use the data structures that are created above in the list below */


struct ListNode
{
        char IP[50];
	// inet number
        int sock_f_d;
        int port;
	//port number
        bool log_status;
	//login status true or false
	int number_sent;
        int number_receive;
	bool reges;
	//boolean blocked;
	/* Here we use vector to store the blocklist and store the message that is sent if the receiver is in the blocklist. Since they are similar data types we can use vector which allows it to grow dynamically*/
        vector<struct Block>BlockList;
	 // using the structure that we created above to declare Blocklist variable.
	vector<struct message>buffer;
	// to store the message in the buffer if the receipient is blocked and cannnot receive the message.
};


/*Compare the port from the login_list structure and return the boolean value if the condition of is satisfied */
bool my_com(ListNode a,ListNode b)
{

        return a.port<b.port;
}

 /*create a data structure to store the serial number, name, IP address and the port of the server or client that is connecting. This is like a log book that store and displays the details of the server when needed*/
 struct login_list
{
        char sno[2],name[100],IP[200],port[10];
};


/**
 * main function
 *
 * @param  argc is the Number of arguments
 * @param  argv is the argument list
 * @return 0 is done when EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Initializse the Logfile*/
	cse4589_init_log(argv[2]);

	/* Clear the LOGFILE*/
    fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	/* We are initializing two main classes one is client and the other is the server. we write all the functions that are needed in the server and the client in these respective files */
	
class Client
{
	/* The below client class. It contains all teh function and methods that can be and are suppposed to perform by a client end system. */
	// such as getting the IP address, receiving and sending messages, broadcating messages and other things
	// login_list and struct block are used to store the list of all the login that are done like a log_book
	vector<login_list> L;
	vector<struct Block> MyBlock;
	int sock_f_d,peer_2_peer,f_max,listsize;
	int port;
	char myAddr[20];
	struct addrinfo hints,*myres,*res,newhints;
	fd_set master,read_fds;
	bool loginflag;
 	struct sockaddr_in peer;	

	public:
	//Call the below function to get the port address and dispaly if teh connection is a sucess or not
	void myPort()
        {
               
		char command_str[]="PORT";

		cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
		fflush(NULL);
		cse4589_print_and_log("PORT:%d\n",port);
		fflush(NULL);
		cse4589_print_and_log("[%s:END]\n", command_str);
		fflush(NULL);
        }
	//call the below function to get the internet address of the server if the connection is established properly. 
	// If the connections isn't done properply its give an error

	void myIP()
        {
                struct ifaddrs *ifa,*p;
                char IP[2000];
		char command_str[]="IP";
                if(getifaddrs(&ifa)==-1)
                {
                        cse4589_print_and_log("[%s:ERROR]\n", command_str);
                        fflush(NULL);
			cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
			fflush(NULL);
                	
			return;
                }

                for(p=ifa;p!=NULL;p=p->ifa_next)
                {
                        struct sockaddr *s=p->ifa_addr;

                        if(s->sa_family==AF_INET)
                        {
                                inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

                                if(strcmp(IP,"127.0.0.1")!=0)
                                {
					cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
					fflush(NULL);
					strcpy(myAddr,IP);
					cse4589_print_and_log("IP:%s\n", IP);
					fflush(NULL);
					cse4589_print_and_log("[%s:END]\n", command_str);
					fflush(NULL);
					break;
				}
                        }
                }

        }

	bool myIPAdd()
        {
                struct ifaddrs *ifa,*p;
                char IP[2000];
                char command_str[]="IP";
                if(getifaddrs(&ifa)==-1)
                {
                        return false;
                }

                for(p=ifa;p!=NULL;p=p->ifa_next)
                {
                        struct sockaddr *s=p->ifa_addr;

                        if(s->sa_family==AF_INET)
                        {
                                inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

                                if(strcmp(IP,"127.0.0.1")!=0)
                                {
                                        
                                        strcpy(myAddr,IP);
                                  
                                        return true;
                                }
                        }
                }

		return false;

        }

	// in the following couple of methods we extract the charecters in the input pointer and store them in an input array
	char *extractFirst(char *input)
	{
		char *first=new char[30];
		int j=0;
		for(int i=0;input[i]!='\0'&&input[i]!=' ';i++,j++)
		 	first[j]=input[i];
		first[j]='\0';

		return first;
	}

	char *extractSecond(char * input)
	{
		char *second=new char[300];
		int j;
		int i=0;
		for(i;input[i]!=' '&&input[i]!='\0';i++);
	
		i++;
		for(j=0;input[i]!=' '&&input[i]!='\0';i++,j++)
			second[j]=input[i];

		second[j]='\0';
		
		return second;
	}
			
	char *extractThird(char *input)
	{
		char *third=new char[1000];
		int j=0;
		int i=0;
		for(;input[i]!=' '&&input[i]!='\0';i++);

			i++;
		for(;input[i]!=' '&&input[i]!='\0';i++);
		i++;
		
		for(;input[i]!='\0';i++,j++)
			third[j]=input[i];
			
		third[j]='\0';

		return third;
	}

	char* broadExtract(char *input)
	{
		char *third=new char[1024];
                int j;
                int i=0;
                for(i;input[i]!=' '&&input[i]!='\0';i++);

                
		i++;
                for(j=0;input[i]!='\0';i++,j++)
                        third[j]=input[i];

                third[j]='\0';

                return third;



	}
	
	//Based on teh given hints  or s by the user the following functions are used. The below can be called if teh user want to access teh client function.
	// the below client method is used to bind peer to peer from the host to server.
	
		Client(char *arg)
		
	{	
		loginflag=false;
		port=atoi(arg);
		memset(&hints,0,sizeof(hints));
		hints.ai_flags=AI_PASSIVE;
		hints.ai_family=AF_INET;
		hints.ai_socktype=SOCK_STREAM;
		//Referred from Beej		
		if(getaddrinfo(NULL,arg,&hints,&myres)==-1)
		{
			perror("getaddrinfo: ");
			//exit(-1);
		}
		
		if((peer_2_peer=socket(AF_INET,SOCK_STREAM,0))==0)
		{

			perror("p2p socket: ");
			
		}

		memset(&peer,0,sizeof(peer));
                peer.sin_family=AF_INET;
		peer.sin_port=htons(port);
                peer.sin_addr.s_addr=htonl(INADDR_ANY);
		
		int yes=1;

		if(setsockopt(peer_2_peer,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int))==-1)
                {
                        perror(" peer sockopt error: ");
                       
                }


                if(bind(peer_2_peer,(struct sockaddr*)&peer,sizeof(peer))==-1)
                {
                        perror(" peer bind error: ");
                        
                }

                if(listen(peer_2_peer,40)==-1)
                {
                        perror("peer listener error: ");
                        
                }
	
	}


	void list_split(char *p)
        {
		char str[500];
		strcpy(str,p);
                
		char *printer;
		vector<char*>s;
		//breaking the string into a serious of tokens and see if it null or not.
		//if its null then we update the list using list_update function and pushback the printer.
             	printer=strtok(str,"-");
		
		while(printer!=NULL)
		{
			s.push_back(printer);
			printer=strtok(NULL,"-");
			
		}

		//call a pre_defined function list_update
		 list_update(s); 
        }
	//list_update is used to update the list 
	//herer we use vector because it can grow dynamically unlike struct depending on the input
	void list_update(vector<char*>s)
	{
		//use the login_list to check if any are connected and then copy the name of teh server connected and update the list
		struct login_list ll;
		L.clear();
		listsize=s.size();
		char str[500];
		char *p;
		for(int i=0;i<listsize;i++)
		{	strcpy(str,s[i]);
			
			p=strtok(str," ");
			strcpy(ll.sno,p);
			p=strtok(NULL," ");
			strcpy(ll.name,p);
			p=strtok(NULL," ");
			strcpy(ll.IP,p);
			p=strtok(NULL," ");
			strcpy(ll.port,p);
			
			L.push_back(ll);
		}

	
	}
	//this method is used to copy the received messaage into the proper attributes
	char* recvmessage(int sock_f_d,char *message)
	{
		char *buf;
		char str[1500];
		int size;
		recv(sock_f_d,&size,sizeof(size),0);

		int total=0;
		int n;
		while(total<size)
		{
			n=recv(sock_f_d,str+total,size,0);
	
			if(n==-1)
			break;
		
			total+=n;
			size-=n;

		}

		str[total]='\0';


		strcpy(message,str);

		return message;
	}
	//we print the list that was mentioned above with the updated clients.
	void printList()
	{
		char command_str[]="LIST";
		cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
		fflush(NULL);
		
		for(int i=0;i<L.size();i++)
		cse4589_print_and_log("%-5d%-35s%-20s%-8s\n", i+1,L[i].name,L[i].IP,L[i].port);
		fflush(NULL);
	// once the connection establishment is a success, then it reflects it and displays all the connected clients
		cse4589_print_and_log("[%s:END]\n", command_str);
		fflush(NULL);
	}

// to check if the IP address is valid
	 bool isIP_Valid(char *IP)
        {
                //referred from beej's example on how to use inet_pton(),inet_ntop() functions

                struct sockaddr_in s;

                int i=inet_pton(AF_INET,IP,&(s.sin_addr));

                if(i==0)
                return false;

                return true;


        }
//to check if the port address is valid or not
	bool isPort_Valid(char *Portent)
	{
		bool flag=true;

		for(int i=0;i<strlen(Portent);i++)
			if(isdigit(Portent[i])==0)
				{ flag=false; break;}

		if(flag==false)
			return false;

		long v=atol(Portent);
		if(v<0 ||  v>65335)
			flag=false;

		if(flag==false)
			return false;
		return true;

	}

	bool isinthelist(char *IP)
	{
		if(myIPAdd()==true)
		{	for(int i=0;i<L.size();i++)
			{
				if(strcmp(L[i].IP,IP)==0 && strcmp(L[i].IP,myAddr)!=0)
					return true;
			}
		}

		return false;
	}

	char *port_find(char* IP)
	{
		int port=-1;
		char *portchar;
		for(int i=0;i<L.size();i++)
		{
			if(strcmp(L[i].IP,IP)==0)
				{ portchar=L[i].port;
				   break;
				}
		}

		return portchar;
	
	}

	bool isIPBlocked(char *IP)
	{
		for(int i=0;i<MyBlock.size();i++)
			if(strcmp(MyBlock[i].IP,IP)==0)
			{
				return true;
			}

		return false;

	}

	bool removeIPBlock(char *IP)
	{
		for(int i=0;i<MyBlock.size();i++)
			if(strcmp(MyBlock[i].IP,IP)==0)
			{
				MyBlock.erase(MyBlock.begin()+i);

			}
		return false;
	}
	//we send all the charecters that we got from the user and send it to the destination and delete it once its sent.
	
	void sendall(int sock_f_d,char *type,char* buf)
        {	
        	char *message=new char[1048];
                strcat(type,buf);
		strcpy(message,type);
                int size=strlen(message);
                int n;
                int total=0;
                send(sock_f_d,&size,sizeof(size),0);
                while(total<size)
                {
                        n=send(sock_f_d,message+total,size,0);

                        if(n==-1)
                        break;

                        total+=n;
                        size-=n;
                }
		delete[] message;	
             
        }

//this is for bonus point to send a file
//using the below method we can sedn file of anykind from one client to another
	void sendFile(int *sock,char *fileName)
	{
		FILE *fp;
		//to check if the file is empty or not	
		fp=fopen(fileName,"rb");
		int lsock=*sock;
		unsigned long nbytes;
		

		if(fp==NULL)
		 {	
			return ;
		 }

		fseek(fp,0L,SEEK_END);
		nbytes=ftell(fp);
		unsigned long nobytes=nbytes;
		
		unsigned char c;
		unsigned long total=0;
 
		
		send(lsock,&nbytes,sizeof(nbytes),MSG_DONTWAIT);
			

			
		fseek(fp,0L,SEEK_SET);
		
		unsigned long freads=1000;
		if(freads>nobytes)
		freads=nobytes;
		
		
		unsigned long tot=0;	
			
		while(tot<nobytes)
		{	
			
			c=fgetc(fp);	
			
			int n=send(lsock,&c,sizeof(c),0);

			
			tot+=n;
			
		}	
			
		fclose(fp);		
		int n=strlen(fileName);	
		send(lsock,&n,sizeof(n),MSG_DONTWAIT);
		send(lsock,fileName,n,MSG_DONTWAIT);
		//close(sock);
		//fclose(fp);
		//cout<<"end "<<endl;
			
		
	}
//similar to the above send a file method, teh below is used to receive a file
	void recvFile(int sock)
	{

		FILE *fp,*real;
		char filename[50];
		int n;	
		unsigned char c;
		int nsize;
		
		unsigned long nbytes;
		recv(sock,&nbytes,sizeof(nbytes),0);
		

		
		
		unsigned long total=0;
		fp=fopen("temp","w+b");
				
			while(total<nbytes)
			{	
		
			unsigned long n=recv(sock,&c,sizeof(c),0);
			if(n<=0)
			 { 	perror("error:");
				break;
			 }
			
			fputc(c,fp);
			//fflush(fp);
			total+=n;
				
			}

			
		//if an empty is sent
		fflush(fp);
		fclose(fp);
		int  nobytes;
		recv(sock,&nobytes,sizeof(nobytes),0);
		int t=0;
		int end=nobytes;
		while(t<nobytes)	
		{
			int n=recv(sock,filename,nobytes,0);
			t+=n;
			nobytes-=n;
		}
		filename[end]='\0';
		
		fp=fopen("temp","rb");
 		
	
		real=fopen(filename,"w+b");

		total=0;
		while(total<nbytes)
		{
			c=fgetc(fp);
			fputc(c,real);	
		
			total++;
		}
		//fflush(real);
		fclose(real);
		
		unlink("temp");	
	
		}
// this is essentially my host client that has details about the author, broadcast,block,send and all the other commands are given and stored
//each given command by the user is stored in a command_str and is sent to the respective method to get the output 
	void myClient()
	{	FD_ZERO(&master);
		f_max=peer_2_peer;
		FD_SET(STDIN,&master);
		FD_SET(peer_2_peer,&master);
		char input[1024];
		int i;
		while(1)
		{	//cout<<"one last time"<<endl;
			read_fds=master;
			if(select(f_max+1,&read_fds,NULL,NULL,NULL)==-1)
			{
				//perror("select: ");
				continue;
			}
			
			for(i=0;i<=f_max;i++)
			{
				if(FD_ISSET(i,&read_fds))
				{
					 if(i==STDIN)
					{
						fgets(input,1023,stdin);
						input[strlen(input)-1]='\0';
						char *first,*second,*third;
						
						//cout<<input<<endl;		
						first=extractFirst(input);
						//cout<<first<<endl;
	
						if(strcmp(first,"IP")==0)
						{
							myIP();
						}
						else if(strcmp(first,"PORT")==0)
						{
							myPort();
						}
						//the author of the program and the acedemic integrity statement
						else if(strcmp(first,"AUTHOR")==0)
						{	char command_str[]="AUTHOR";
							cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
							fflush(NULL);
							cse4589_print_and_log("I, roshansh, have read and understood the course academic integrity policy.\n");
							fflush(NULL);
							cse4589_print_and_log("[%s:END]\n",command_str);
							fflush(NULL);
						}
						// if a login command is given
						else if(strcmp(first,"LOGIN")==0)
						{
							memset(&newhints,0,sizeof(newhints));
							newhints.ai_family=AF_INET;
							newhints.ai_socktype=SOCK_STREAM;
							//newhints.ai_flags=AI_PASSIVE;

							second=extractSecond(input);
							third=extractThird(input);
							loginflag=loginflag;
							//cout<<second<<endl<<third<<endl<<loginflag<<endl;
						   if(isIP_Valid(second)==true && isPort_Valid(third)==true)
							{
							   if(loginflag==false)	
						 	   {		
								if(getaddrinfo(second,third,&newhints,&res)==-1)
								{
									//perror("getaddrinfo: ");
									//exit(-1);
								}
								int yes=1;
								if((sock_f_d=socket(AF_INET,SOCK_STREAM,0))==-1)
								{
									//perror("socket: ");
									//exit(-1);
								}
						
							
								if (setsockopt(sock_f_d,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof yes) == -1) {
 									//perror("setsockopt");
 									//exit(1);
								}

									
								if(connect(sock_f_d,res->ai_addr,res->ai_addrlen)==-1)
								{
									//perror("Connect error: ");
									//exit(-1);
								}

								FD_SET(sock_f_d,&master);
								//cout<<"Login Check: "<<endl;
								loginflag=true;
								(sock_f_d>f_max)?f_max=sock_f_d:f_max;
								send(sock_f_d,&port,sizeof(port),0);
							    }
							   else
								{

								
                                                                cse4589_print_and_log("[LOGIN:ERROR]\n");
                                                                fflush(NULL);
                                                                cse4589_print_and_log("[LOGIN:END]\n");
                                                                fflush(NULL);


								}
							}
						   else
							{
							//if there's an error in 
								//char command_str[]="LOGIN";
								cse4589_print_and_log("[LOGIN:ERROR]\n");
								fflush(NULL);
                                                                cse4589_print_and_log("[LOGIN:END]\n");
                                                                fflush(NULL);


							}
						
						}
						//if the given command is list
						else if(strcmp(first,"LIST")==0)
						{
							if(loginflag==true)
							{
								printList();
							}
							
						}
						//if the given command is refresh
						else if(strcmp(first,"REFRESH")==0)
						{	char command_str[]="REFRESH";
							//cout<<"Inside refresh"<<endl;
							if(loginflag==true)
							{
								char request[1024]="0";
								char trailer[1024]=" ";
								sendall(sock_f_d,request,trailer);
								cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);
							}
							else
							{
								cse4589_print_and_log("[%s:ERROR]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);

							}

						}
						//if teh given command is send
						else if(strcmp(first,"SEND")==0)
						{	char command_str[]="SEND";
							second=extractSecond(input);
							if(isIP_Valid(second)==true && isinthelist(second)==true && loginflag==true)
							{ 
								char request[1024]="1 ";
								strcat(request,second);
								strcat(request," ");
								third=extractThird(input);
								//cout<<third<<endl<<flush;
								sendall(sock_f_d,request,third);
								cse4589_print_and_log("[SEND:SUCCESS]\n");
								fflush(NULL);
								cse4589_print_and_log("[SEND:END]\n");
								fflush(NULL);
							}
							else
							{

								cse4589_print_and_log("[SEND:ERROR]\n");
								fflush(NULL);
                                                                cse4589_print_and_log("[SEND:END]\n");
                                                                fflush(NULL);

							}
							//cout<<"Input is fine: "<<input<<endl;
							//ut<<isIP_Valid(second)<<" "<<isinthelist(second)<<endl;
						}
						else if(strcmp(first,"BROADCAST")==0)
						{
							third=broadExtract(input);
							char request[1024]="2 ";
							myIPAdd();
							strcat(request,myAddr);
							strcat(request," ");
							sendall(sock_f_d,request,third);

							char command_str[]="BROADCAST";

							 cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
							 fflush(NULL);
                                                         cse4589_print_and_log("[%s:END]\n",command_str);
                                                         fflush(NULL);
						}
						else if(strcmp(first,"BLOCK")==0)
						{	char command_str[]="BLOCK";
							
							second=extractSecond(input);
							if(isIP_Valid(second)==true && isinthelist(second)==true && isIPBlocked(second)==false)
							  {	char request[]="3 ";
								struct Block temp;
								sendall(sock_f_d,request,second);
								strcpy(temp.IP,second);
								MyBlock.push_back(temp);
								cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);

							  }
							else
							  {
								cse4589_print_and_log("[%s:ERROR]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);

							  }
						}
						else if(strcmp(first,"UNBLOCK")==0)
						{	char command_str[]="UNBLOCK";
							
							second=extractSecond(input);
							if(isIP_Valid(second)==true && isinthelist(second)==true && isIPBlocked(second)==true)
							{	char request[]="4 ";
								sendall(sock_f_d,request,second);
								removeIPBlock(second);
								cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);

							}
							else
							{
								cse4589_print_and_log("[%s:ERROR]\n", command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("[%s:END]\n",command_str);
                                                                fflush(NULL);

							}

							
					
						}
						else if(strcmp(first,"SENDFILE")==0)
						{
							struct addrinfo myhints,*pres;
							memset(&myhints,0,sizeof(myhints));
                                                        myhints.ai_family=AF_INET;
                                                        myhints.ai_socktype=SOCK_STREAM;
							int tempfd;
							char *clientIP=extractSecond(input);
							char *fileName=extractThird(input);
							char *pno=port_find(clientIP);
							if(getaddrinfo(clientIP,pno,&myhints,&pres)==-1)
                                                                {
                                                                        //perror("getaddrinfo: ");
                                                                        //exit(-1);
                                                                }
                                                                int yes=1;

                                                                if((tempfd=socket(AF_INET,SOCK_STREAM,0))==-1)
                                                                {
                                                                        //perror("socket: ");
                                                                        //exit(-1);
                                                                }


                                                                if (setsockopt(tempfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof yes) == -1) {
                                                                        //perror("setsockopt");
                                                                        //exit(1);
                                                                }


                                                                if(connect(tempfd,pres->ai_addr,pres->ai_addrlen)==-1)
                                                                {
                                                                        //perror("Connect error: ");
                                                                        //exit(-1);
                                                                }
							//cout<<" "<<clientIP<<" "<<fileName<<" "<<pno<<" "<<endl;

							sendFile(&tempfd,fileName);
							cse4589_print_and_log("[%s:SUCCESS]\n", "SENDFILE");
                                                        fflush(NULL);
                                                        cse4589_print_and_log("[%s:END]\n","SENDFILE");
                                                        fflush(NULL);

							close(tempfd);
						}

									
						
						else if(strcmp(first,"LOGOUT")==0)
						{
							char command_str[]="LOGOUT";
							char request[]="X";
							char type[]=" ";
							loginflag=false;
							sendall(sock_f_d,request,type);
							FD_CLR(sock_f_d,&master);
							close(sock_f_d);
							cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
							fflush(NULL);
                                                        cse4589_print_and_log("[%s:END]\n",command_str);
                                                        fflush(NULL);

							
						}	
						else if(strcmp(first,"EXIT")==0)
						{
							char command_str[]="EXIT";
							char request[]="9";
							char type[]=" ";
							sendall(sock_f_d,request,type);
							FD_CLR(sock_f_d,&master);
							close(sock_f_d);
							cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
							fflush(NULL);
                                                        cse4589_print_and_log("[%s:END]\n",command_str);
                                                        fflush(NULL);
							exit(0);
						}
						
						
					}

					else if(i==sock_f_d)
					{	char r[500];
						char *m=recvmessage(sock_f_d,r);				
						if(m[0]=='0')
						{ 
						 list_split(m+2);
						 
						}
						 
						else if(m[0]=='1')
						{  
						   char command_str[]="RECEIVED";
						   char *sender=extractSecond(m);
						   char *message=extractThird(m);
						    cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
						    fflush(NULL);
						    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender,message);
						    fflush(NULL);
                                                    cse4589_print_and_log("[%s:END]\n",command_str);
                                                    fflush(NULL);


						}
						else if(m[0]=='2')
						{	char *sender=extractSecond(m);
                                                 	char *message=extractThird(m);
							
						    char command_str[]="RECEIVED";
                                                    cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
                                                    fflush(NULL);
                                                    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);
                                                    fflush(NULL);
                                                    cse4589_print_and_log("[%s:END]\n",command_str);
                                                    fflush(NULL);

						}
						else if(m[0]=='L')
						{
							list_split(m+2);
							char type[]="B";
							char req[]=" ";
							sendall(sock_f_d,type,req);
						}
						else if(m[0]=='B')
						{	char *sender=extractSecond(m+1);
                                                        char *message=extractThird(m+1);
							char command_str[]="RECEIVED";
                                                        cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
                                                        fflush(NULL);
                                                        cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);
                                                        fflush(NULL);
                                                        cse4589_print_and_log("[%s:END]\n",command_str);
                                                        fflush(NULL);

							char type[]="B";
							char req[]=" ";
							sendall(sock_f_d,type,req);
						}
						else if(m[0]=='F')
						{
							char *sender=extractSecond(m+1);
                                                        char *message=extractThird(m+1);
						    char command_str[]="RECEIVED";
                                                    cse4589_print_and_log("[%s:SUCCESS]\n", command_str);fflush(NULL);
                                                    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);fflush(NULL);
                                                    cse4589_print_and_log("[%s:END]\n",command_str);fflush(NULL);

						    char command[]="LOGIN";
                                                    cse4589_print_and_log("[%s:SUCCESS]\n", command);fflush(NULL);
                                                    cse4589_print_and_log("[%s:END]\n",command);fflush(NULL);

						}
						else if(m[0]=='N')
						{
						    char command[]="LOGIN";
                                                    cse4589_print_and_log("[%s:SUCCESS]\n", command);fflush(NULL);
                                                    cse4589_print_and_log("[%s:END]\n",command);fflush(NULL);

						}
						
					}

					else if(i==peer_2_peer)
					{
						int newfd;
						sockaddr peeraddr;
						socklen_t plen=sizeof(peeraddr);
						 newfd=accept(peer_2_peer,&peeraddr,&plen);
						// cout<<"Connected "<<endl;
						if(newfd==-1)
						{
							perror("newfd :");
							continue;
						}
						else
						{
							recvFile(newfd);
							close(newfd);
						}

						
					}
						
				}
			}
		}
	}
};

//most of the functions used in the server are same as the client as far as the logic and syntaxs go. the only main big difference is the calling and server side of things. You can refer teh client side methods if you get confused with any server side methods.
		
	class Server
{
	int sock_f_d,newfd;
	vector<struct ListNode>remoteList;
	//vector<struct Buffer>BufMap;
	struct sockaddr_in res;
	struct sockaddr remoteaddr;
	int f_max,yes;
	socklen_t addrlen;
	fd_set master,read_fds,write_fds;
	int port;
	/* Above we use mostly inbulit functions like sockaddr-in, sockaddr, remoteaddr in cpp, which helps to deal with the internet address */
	/* The below is the public class that we use to get the internet IP address of the system.*/
	/* By using the below function we print and log the port number of the server or client if the connection is success */
		
	public:
	void myIPgoogle() //Helper function to fetch the inet IP address and referred from Wenjun's Recitation Material
	{
		struct addrinfo ip_hints,*ip_res;
		struct sockaddr_in me;
		socklen_t mylen;
		char IP[2000];
		int tempfd;
		memset(&ip_hints,0,sizeof(ip_hints));
		ip_hints.ai_family=AF_INET;
		ip_hints.ai_flags=AF_UNSPEC;
		ip_hints.ai_socktype=SOCK_DGRAM;
/* Here we are using hints so that the user can specify what kind the user wants to access server or the receiver for which we use "hints" function in cpp */
		if(getaddrinfo("8.8.8.8","53",&ip_hints,&ip_res)==-1)
		{
			perror("ip getaddrinfo: ");
			exit(-1);
		}
		

		
		if((tempfd=socket(ip_res->ai_family,ip_res->ai_socktype,ip_res->ai_protocol))==-1)
		{
			perror("ip socket: ");
			exit(-1);
		}
	

		if(connect(tempfd,ip_res->ai_addr,ip_res->ai_addrlen)==-1)
		{
			perror("ip connect: ");
			exit(-1);
		}
		
		mylen=sizeof(me);

		if(getsockname(tempfd,(struct sockaddr*)&me,&mylen)==-1)
		{
			perror("getsock: ");
			exit(-1);
		}

		inet_ntop(AF_INET,&(me.sin_addr),IP,sizeof(IP));
		if(strcmp(IP,"127.0.0.1")!=0)
			cout<<IP<<endl<<flush;
		
		close(tempfd);
	}

		
		
/* This function is used to get the port address and project if the connections is properly established or not */
		
		void myPort()
			
	{	
			char command_str[]="PORT";

			cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
			fflush(NULL);
			cse4589_print_and_log("PORT:%d\n",ntohs(res.sin_port));
			fflush(NULL);
			//cout<<ntohs(res.sin_port)<<endl<<flush;
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
	}
	

	char* myList(char* m)
	{	
		char *p=new char[500];
		p[0]='\0';
		
		int i;
		char host[200],service[200];
		struct sockaddr_in s;
		socklen_t slen=sizeof(s);
		
		sort(remoteList.begin(),remoteList.end(),my_com);
		
		for(i=0;i<remoteList.size();i++)
		{
		 if(remoteList[i].reges==true&&remoteList[i].log_status==true)
		 {	strcat(p,"-");

			stringstream stream;
			stream<<(i+1); 
			string temp=stream.str();
			char *num=new char[temp.length()+1];
			strcpy(num,temp.c_str());

			//cout<<num<<endl;
			strcat(p,num);
			strcat(p," ");
			//cout<<p<<endl;
			inet_aton(remoteList[i].IP,&s.sin_addr);
			s.sin_family=AF_INET;
		
			getnameinfo((struct sockaddr*)&s,slen,host,sizeof(host),service,sizeof(service),NI_NAMEREQD);
			strcat(p,host);
			
			
			strcat(p," ");
			inet_ntop(AF_INET,&(s.sin_addr),host,INET_ADDRSTRLEN);

			strcat(p,host);
			strcat(p," ");
			stream.str("");
			stream<<remoteList[i].port;
			temp=stream.str();
			delete[] num;
			num=new char[temp.length()+1];
			strcpy(num,temp.c_str());
			strcat(p,num);
			delete[] num;
		 }
		}	
			

		strcpy(m,p);
	
		return m;
	}

		
	/* The below is the function for printing the name ip_address of the cconnected server if the connection is success and it is also reflected. */
	void printList()
	{	char hostname[200],service[100];
		sockaddr_in s;
		socklen_t size=sizeof(s);
		char command_str[]="LIST";
		cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
		fflush(NULL);
		for(int i=0;i<remoteList.size();i++)
		{	if(remoteList[i].reges==true && remoteList[i].log_status==true)
			{	inet_aton(remoteList[i].IP,&s.sin_addr);
                        	s.sin_family=AF_INET;
				getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);
				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", i+1, hostname, remoteList[i].IP, remoteList[i].port);
				fflush(NULL);
			//cout<<i+1<<" "<<hostname<<" "<<remoteList[i].IP<<" "<<remoteList[i].port<<endl<<flush;
			}

		}	
		cse4589_print_and_log("[%s:END]\n", command_str);
		fflush(NULL);
	}		
		
/* The below IP function is used to get the IP address of the respective server and also specifies if the connection has been sucessfully established or not. We get the IP only if the connections is properly established */ 
		
	void myIP()
	{
		struct ifaddrs *ifa,*p;
		char IP[2000];
		char command_str[]="IP";
		if(getifaddrs(&ifa)==-1)		//Referred from man pages 
		{
			cse4589_print_and_log("[%s:ERROR]\n", command_str);
			fflush(NULL);
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
			return;
		}
		
		

		for(p=ifa;p!=NULL;p=p->ifa_next)
		{	
			struct sockaddr *s=p->ifa_addr;
			
			if(s->sa_family==AF_INET)
			{
				inet_ntop(AF_INET,&(((struct sockaddr_in*)s)->sin_addr),IP,sizeof(IP));

				if(strcmp(IP,"127.0.0.1")!=0)
				{	cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
					fflush(NULL);
					cse4589_print_and_log("IP:%s\n",IP);
					fflush(NULL);
					cse4589_print_and_log("[%s:END]\n", command_str);
					fflush(NULL);
					//cout<<IP<<endl	
					break;
				}
			}
		
		}
	}

	
	
	void sendall(int sock,char *type,char* buf)
	{	//Referred from beej's partial send() example
		char *message=new char[1048];
		strcat(type,buf);
		strcpy(message,type);
		int size=strlen(type);
		int n;
		int total=0;
		send(sock,&size,sizeof(size),0);
		while(total<size)
		{	//ut<<type<<endl<<flush;
			n=send(sock,message+total,size,0);
		
			if(n==-1)
			break;
			
			total+=n;
			size-=n;
		}
		delete[] message;
		//cout<<n<<"bytes were sent"<<endl<<flush;
	}

	 char* recvmessage(int sock_f_d,char *buf)
        {
         	//Referred from beej again       
                char *str=new char[1500];
                int size;
                if(recv(sock_f_d,&size,sizeof(size),0)==0)
		{	
			FD_CLR(sock_f_d,&master);

			for(int i=0;i<remoteList.size();i++)
			{
				if(remoteList[i].sock_f_d==sock_f_d)
					remoteList.erase(remoteList.begin()+i);

			}

			close(sock_f_d);

		}
		
		
                int total=0;
                int n;
                while(total<size)
                {
                        n=recv(sock_f_d,str+total,size,0);

                        if(n==-1)
                        break;

                        total+=n;
                        size-=n;

                }

                str[total]='\0';

	 return str;
        }

	char *extractFirst(char *input)
        {
                char *first=new char[30];
                int j=0;
                for(int i=0;input[i]!='\0'&&input[i]!=' ';i++,j++)
                        first[j]=input[i];
                first[j]='\0';

                return first;
        }

        char *extractSecond(char * input)
        {
                char *second=new char[300];
                int j=0;
                int i;
                for(i=0;input[i]!=' '&&input[i]!='\0';i++);

                for(;isalnum(input[i])==0&&input[i]!='\0';i++);

                for(;input[i]!=' '&&input[i]!='\0';i++,j++)
                        second[j]=input[i];

                second[j]='\0';

                return second;
        }

        char *extractThird(char *input)
        {
                char *third=new char[1024];
                int j=0;
                int i;
                for(i=0;input[i]!=' '&&input[i]!='\0';i++);

                //for(;isalnum(input[i])==0&&input[i]!='\0';i++);

                i++;
		for(;input[i]!=' '&&input[i]!='\0';i++);
		
                //for(;isalnum(input[i])==0&&input[i]!='\0';i++);

		i++;
                for(;input[i]!='\0';i++,j++)
                        third[j]=input[i];

                third[j]='\0';

                return third;
        }

	int findClient(char *IP)
	{
		for(int i=0;i<remoteList.size();i++)
			
			if(strcmp(remoteList[i].IP,IP)==0)
			{
				return i;
			}
		
		return -1;
		
	}
		
	int findClient(int sock)
	{

		for(int i=0;i<remoteList.size();i++)
			if(remoteList[i].sock_f_d==sock)
				return i;

		return -1;
	}

	bool isIPBlocked(int sendsock,int rind)
	{
		int index=findClient(sendsock);
		
		for(int i=0;i<remoteList[rind].BlockList.size();i++)
			if(strcmp(remoteList[index].IP,remoteList[rind].BlockList[i].IP)==0)
				return true;
			
		return false;
	}

	void printStatistics()
	{
		char hostname[200],service[100];
                sockaddr_in s;
                socklen_t size=sizeof(s);
		char log[20];
		cse4589_print_and_log("[%s:SUCCESS]\n","STATISTICS");
		for(int i=0;i<remoteList.size();i++)
		{ 
		     if(remoteList[i].reges==true)
			{
				inet_aton(remoteList[i].IP,&s.sin_addr);
                        	s.sin_family=AF_INET;
                        	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

				if(remoteList[i].log_status==true)
				{
					 strcpy(log,"logged-in");
					//cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname, remoteList[i].number_sent, remoteList[i].number_receive, "logged-in")
					//cout<<i+1<<" "<<remoteList[i].IP<<" "<<remoteList[i].number_sent<<" "<<remoteList[i].number_receive<<" "<<"logged-in"<<endl<<flush;

				}
				else
				{	strcpy(log,"logged-out");
					//cout<<i+1<<" "<<remoteList[i].IP<<" "<<remoteList[i].number_sent<<" "<<remoteList[i].number_receive<<" "<<"logged-out"<<endl<<flush;
				}

			cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname,remoteList[i].number_sent, remoteList[i].number_receive,log);
			fflush(NULL);
			}
		}
		cse4589_print_and_log("[%s:END]\n","STATISTICS");
	}
		
	void removeIPBlock(int sock_f_d, char *IP)
	{	
		int index;
		int eind;
		index=findClient(sock_f_d);
		
		for(int i=0;i<remoteList[index].BlockList.size();i++)
		{	
			if(strcmp(remoteList[index].BlockList[i].IP,IP)==0)
			{	eind=i;	
				break;
			}

		}

		remoteList[index].BlockList.erase(remoteList[index].BlockList.begin()+eind);

	}
	
	void printBlockList(char *IP)
	{
		char hostname[200],service[100];
                sockaddr_in s;
                socklen_t size=sizeof(s);
		int i;
		vector<ListNode>tempBlock;
		char command_str[]="BLOCKED";
		int index=findClient(IP);
		if(index!=-1 && remoteList[index].reges==true)
		{	cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
			fflush(NULL);

			for(i=0;i<remoteList[index].BlockList.size();i++)
			{	 int j=findClient(remoteList[index].BlockList[i].IP);
			   	  tempBlock.push_back(remoteList[j]);
			 	

			}
		
			sort(tempBlock.begin(),tempBlock.end(),my_com);
			for(i=0;i<tempBlock.size();i++)
			{
				inet_aton(tempBlock[i].IP,&s.sin_addr);
                        	s.sin_family=AF_INET;
                        	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",i+1,hostname,tempBlock[i].IP,tempBlock[i].port);
				fflush(NULL);
			}
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
		}
		else
		{	//Non-existent/Incorrect IP address

			cse4589_print_and_log("[%s:ERROR]\n", command_str);
			fflush(NULL);
			cse4589_print_and_log("[%s:END]\n", command_str);
			fflush(NULL);
		}
		
	}

	char *prepareBuffer (int rind,char *message)
	{
		char *mod=new char[1024];
		char* third=new char[1500];
		third=extractThird(message);	
		mod[0]=message[0];
		mod[1]=message[1];
		strcat(mod,remoteList[rind].IP);
		strcat(mod," ");
		strcat(mod,third);
		cout<<mod<<endl;	
		delete[] third;
		return mod;	 
	}

	bool isIP_Valid(char *IP)
	{
		//referred from beej's example on how to use inet_pton(),inet_ntop() functions

		struct sockaddr_in s;
		
		int i=inet_pton(AF_INET,IP,&(s.sin_addr));
		
		if(i==0)
		return false;

		return true;
		

	}
			
	Server(char *P)
	{	//Referred from Beej's guide 
		yes=1;

		memset(&res,0,sizeof(res));
		res.sin_family=AF_INET;
		stringstream convertport(P);

		if(! (convertport>>port))
			port=0;

		res.sin_port=htons(port);
		res.sin_addr.s_addr=htonl(INADDR_ANY);
		
		if((sock_f_d=socket(AF_INET,SOCK_STREAM,0))==-1)
		{
			perror("socket error: ");
			exit(-1);
		}
		

		if(setsockopt(sock_f_d,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int))==-1)
		{
			perror("sockopt error: ");
			exit(-1);
		}
		

		if(bind(sock_f_d,(struct sockaddr*)&res,sizeof(res))==-1)
		{
			perror("bind error: ");
			exit(-1);
		}

		if(listen(sock_f_d,40)==-1)
		{
			perror("listener error: ");
			exit(-1);
		}

		
	}		
		
	void runServer()
	{
			
		f_max=sock_f_d;
		FD_SET(STDIN,&master);
		FD_SET(sock_f_d,&master);
		char buf[500],remoteIP[INET6_ADDRSTRLEN];
		int buflen;
		int i;
		int index;
		while(true)
		{	//Select part from beej's example and Wenjun's material
			read_fds=master;
			//write_fds=master; //copy it --> why??
			if(select(f_max+1,&read_fds,NULL,NULL,NULL)==-1)
			{
				perror("select: ");
				exit(-1);
			}
			for(i=0;i<=f_max;i++)
			{
				if(FD_ISSET(i,&read_fds))
				{
					if(i==sock_f_d)
					{	//vector<struct sockaddr>list=myList();
						addrlen=sizeof(remoteaddr);
						newfd=accept(sock_f_d,&remoteaddr,&addrlen);
						struct ListNode temp;
						 
						if(newfd==-1)
						{
							perror("accept: ");
							exit(-1);
						}
						else
						{	
							FD_SET(newfd,&master);
							(newfd>f_max)?f_max=newfd:f_max;
							inet_ntop(AF_INET,&(((struct sockaddr_in*)&remoteaddr)->sin_addr),remoteIP,INET_ADDRSTRLEN);
							recv(newfd,&temp.port,sizeof(int),0);
							 
							 if((index=findClient(remoteIP))==-1)
							 {	strcpy(temp.IP,remoteIP);
								temp.sock_f_d=newfd;
								temp.number_sent=0;
								temp.number_receive=0;
								temp.reges=true;
								temp.log_status=true;
								//cout<<"IP"<<endl;						 
							 	remoteList.push_back(temp);
							 }
							else
							{	//cout<<"Second Login"<<endl;	
								remoteList[index].reges=true;
								remoteList[index].log_status=true;
								strcpy(remoteList[index].IP,remoteIP);
								remoteList[index].sock_f_d=newfd;
								remoteList[index].port=temp.port;
							}

							
							char list[500],*l;
							l=myList(list);		

							char type[]="L ";
							//cout<<list<<endl<<flush;
							sendall(newfd,type,list);
							
						}
					}
					else if(i==STDIN)
					{
						char input[500]="";
						
						
							fgets(input,sizeof(input),stdin);
							input[strlen(input)-1]='\0';
							//cout<<"Echo: "<<input<<endl;
							char *first=extractFirst(input);

							if(strcmp(first,"AUTHOR")==0)
							{	char command_str[]="AUTHOR";
								cse4589_print_and_log("[%s:SUCCESS]\n", command_str);
								fflush(NULL);
								cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "roshansh");
								fflush(NULL);
								cse4589_print_and_log("[%s:END]\n", command_str);
								fflush(NULL);
							}
						
							else if(strcmp(first,"LIST")==0)
							{	char *p,l[500];
								p=myList(l);
								printList();
							}
							
							else if(strcmp(first,"PORT")==0)
							{	
								
								myPort();
								
							}
						
							else if(strcmp(first,"IP")==0)
							{	
								
								myIP();
								
							}
			\
							else if(strcmp(first,"STATISTICS")==0)
							{
								printStatistics();
								
								
							}
						

							else if(strcmp(input,"EXIT")==0)
							{	
								close(sock_f_d);
								exit(-1);
							}	
						
							else if(strcmp(first,"BLOCKED")==0)
								
							{	
								char command_str[]="BLOCKED";

								char *IP=extractSecond(input);
								
								if(isIP_Valid(IP)==true)
									
								{	
									printBlockList(IP);
								
								}
								else
								{
									cse4589_print_and_log("[%s:ERROR]\n", command_str);
									fflush(NULL);
									cse4589_print_and_log("[%s:END]\n", command_str);
									fflush(NULL);
								}
							}
						
					 }

						
					else
					{
						char* message;
						char response[1500];
						message=recvmessage(i,response);
						
						
						if(message[0]=='0')
						{	char list[500];
							char type[1024]="0 ";
							char* p=myList(list);
							//cout<<list<<endl<<flush;
							sendall(i,type,p);
						}
						else if(message[0]=='1')
						{	char m[1400];
							int send=findClient(i);
							remoteList[send].number_sent++;
							//char str[]="RELAYED";
							char *IP=extractSecond(message);
							char *third=extractThird(message);	
							int j=findClient(IP);
							if(j!=-1)
							{
								
								if(isIPBlocked(i,j)==false)
								{	char type[]="";
									
									strcpy(m,message);

									if(remoteList[j].log_status==true)
									{	char cmd[]="RELAYED";
										char *prep=prepareBuffer(send,m);
										sendall(remoteList[j].sock_f_d,prep,type);
										remoteList[j].number_receive++;
										//cout<<"In Relaying Send: "<<m<<endl;
										
										cse4589_print_and_log("[%s:SUCCESS]\n",cmd);
										fflush(NULL);
                                                                		cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",remoteList[send].IP,remoteList[j].IP,third);
                                                                		fflush(NULL);
                                                        //message
                                                                		cse4589_print_and_log("[%s:END]\n",cmd);
                                                                		fflush(NULL);

										
									}
									else
									{
										struct message mbuf;
										//strcpy(mbuf.info,message);
										char *prep=prepareBuffer(send,message);
										strcpy(mbuf.info,prep);
										remoteList[j].buffer.push_back(mbuf);
										//cout<<"Am I here"<<endl<<flush;
									}
								}
								
							}
							else
							{
								strcpy(m,message);
								struct ListNode temp2;
								strcpy(temp2.IP,IP);
								temp2.reges=false;
								temp2.log_status=false;
								temp2.number_sent=0;
								temp2.number_receive=0;
								remoteList.push_back(temp2);
								int ind=findClient(temp2.IP);
								//cout<<ind<<" "<<remoteList[ind].IP<<"X"<<flush;
								if(ind!=-1)
								{	struct message mbuf;
									char *prep=prepareBuffer(send,message);
									strcpy(mbuf.info,prep);
									remoteList[ind].buffer.push_back(mbuf);
								}
								
								//cout<<"Am I here 2"<<endl<<flush;
							}
							
			

						}

						else if(message[0]=='2')
						{		int send=findClient(i);
								remoteList[send].number_sent++;
								bool flag=false;
								int client;
								char command_str[]="RELAYED";
							for(int j=1;j<=f_max;j++)
							{	char trailer[]="";
								client=findClient(j);
								if(FD_ISSET(j,&master))
								{	
									if(j!=i && j!=sock_f_d )
									{	
									
										if(remoteList[client].log_status==true && isIPBlocked(i,client) == false)
										{	sendall(j,message,trailer);
								 			flag=true;
											
											remoteList[client].number_receive++;
										}	
									}
								}
								
								else if(client!=-1 && isIPBlocked(i,client)==false)
								{	//BUffering 

									struct message m;
									strcpy(m.info,message);
									remoteList[client].buffer.push_back(m);
								}
							}
							if(flag==true)
							{	char *third=extractThird(message);
								cse4589_print_and_log("[RELAYED:SUCCESS]\n");
								fflush(NULL);
								cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",remoteList[send].IP,third);
								fflush(NULL);
							//message
								cse4589_print_and_log("[RELAYED:END]\n",command_str);
								fflush(NULL);
							}

						}
						else if(message[0]=='3')
						{
							Block tempBlock;
							index=findClient(i);
							//if(index==-1)
							//cout<<"youre an invalid client"<<endl<<flush;
							if(index!=-1)
							{ char* second=extractSecond(message);
							  strcpy(tempBlock.IP,second);
							  remoteList[index].BlockList.push_back(tempBlock);

							}
						}

						else if(message[0]=='4')
						{

							Block tempBlock;
							index=findClient(i);
					
							//if(index==-1)
							//cout<<"youre an invalid client"<<endl<<flush;
							if(index!=-1)
							{
								char* second=extractSecond(message);
								
								removeIPBlock(i,second);
							}
						}
						else if(message[0]=='9')
						{
							int ind=findClient(i);
							remoteList[ind].log_status=false;
							remoteList[ind].reges=false;
							remoteList[ind].number_sent=0;
							remoteList[ind].number_receive=0;
							FD_CLR(i,&master);
							close(i);

						}
						else if(message[0]=='X')
						{
							int ind=findClient(i);
							//cout<<remoteList[ind].IP<<" logged out"<<endl;
							remoteList[ind].log_status=false;
							FD_CLR(i,&master);
							close(i);		
	
						}
						else if(message[0]=='B')
						{	int j=findClient(i);
							//cout<<"Am I getting this req "<<endl<<flush;
							//cout<<"Buffer Size"<<remoteList[j].buffer.size()<<endl<<flush;
							int c=-1;
							char *from,*message;
							char command_str[]="RELAYED";
							int size=remoteList[j].buffer.size();
							if(size>1)
							{	char type[1024]="B";
								sendall(remoteList[j].sock_f_d,type,remoteList[j].buffer[0].info);
								from=extractSecond(remoteList[j].buffer[0].info);
								message=extractThird(remoteList[j].buffer[0].info);
								remoteList[j].number_receive++;
								remoteList[j].buffer.erase(remoteList[j].buffer.begin());
								
								if(remoteList[j].buffer[0].info[0]=='2')
									c=1;
								else
									c=0;
						
							}
							
							else if(size==1)
							{	char type[1024]="F";
								sendall(remoteList[j].sock_f_d,type,remoteList[j].buffer[0].info);
								remoteList[j].number_receive++;
								from=extractSecond(remoteList[j].buffer[0].info);
								message=extractThird(remoteList[j].buffer[0].info);
								remoteList[j].buffer.erase(remoteList[j].buffer.begin());
							
								if(remoteList[j].buffer[0].info[0]=='2')
                                                                        c=1;
                                                                else
                                                                        c=0;
							}
							else 
							{
								//size =0;
								char type[]="N";
								char resp[]=" ";
								sendall(remoteList[j].sock_f_d,type,resp);
							}


							if(c==1)
							{
								//char *third=extractThird(message);
								cse4589_print_and_log("[RELAYED:SUCCESS]\n",command_str);
								fflush(NULL);
                                                                cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",from,message);
                                                                fflush(NULL);
                                                        //message
                                                                cse4589_print_and_log("[RELAYED:END]\n",command_str);
                                                                fflush(NULL);
								//Broadcast

							}
							else if(c==0) 
							{	//cout<<from<<endl;
								//char *third=extractThird(message);
								cse4589_print_and_log("[RELAYED:SUCCESS]\n");
								fflush(NULL);
                                                                cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from,remoteList[j].IP,message);
                                                                fflush(NULL);
                                                        //message
                                                                cse4589_print_and_log("[RELAYED:END]\n");
                                                                fflush(NULL);

							}

						} delete[] message;
					}
				}
			}
		}

	}
};




//This is the actual  main function where we call the above defined classes and the methods and run them using instances and print the outputs.

	if(argc==3)
	{
		if(strcmp(argv[1],"s")==0)
		{ Server S(argv[2]);
	  	S.runServer();
		}
		else if(strcmp(argv[1],"c")==0)
		{
			Client C(argv[2]);
			C.myClient();
		}
	}

	else
	cout<<"Enter right command"<<endl;

	
	return 0;
}
