/**
 * @ishaanil_assignment1
 * @author  Isha Anil Chhawchharia <ishaanil@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include "../include/global.h"
#include "../include/logger.h"


#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 100
#define BUFFER_SIZE 256

#define MSG_LENGTH 1024
#define EPHEMERAL_PORT 53
#define AUTHOR "ishaanil"
#define IP "IP\n"
#define LOGIN "LOGIN\n"
#define LIST "LIST\n"
#define PORT "PORT\n"


struct client{
    int listid;
    char *ip;
    int fd_cli;
    char *name_of_host;
    int blck_stat;
    int client_status;
    int port_number;
    struct client *next;
       
};



char client_ip[5][100];
int server(struct client **head_ref, int port_number, int fdListen);
int port_number[5];
int client(struct client **ref_cli , int port_number, int fdListen);
int c_var =1;
void push(struct client** head_ref, int port_number, char* ip);
void print(struct client *headref);
//void get_portnum(int port_number);
int port_a_num[10];
void send_to_client(int socket_idx, char *send_to_ip, char *buffer, struct client *temp);
char* find_ip(char *str);
void send_port(int listening_port, int server_fd);
void assign_port(char * buffer, struct client *temp);
void tostring(char str[], int num);
int pol=0;
void send_client_list(struct client* headref,char client_list[]);
void create_client_list(struct client **ref_cli,char *buffer);
int reply_cli[10];
void broadcast(struct client *ref_cli, char *msg, int srver_fd);
void add_new_client(struct client **head_ref,int fdAcc, struct sockaddr_in client_addr);
int isValidIP(char *ip);
int valid_digit(char *ip_str);
char from_ip[25];

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
 
 
int main(int argc, char *argv[]) {
    
    /*Init. Logger*/
    cse4589_init_log(argv[2]);
    
    /* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));
    
    struct client *head_ref = NULL;
    struct client *ref_cli = NULL;
    struct sockaddr_in listen_addr;
    
    if(argc!=3)     //If input is not 3(Enter either s or c with port number)
    {
        exit(-1);
    }
    int fdListen=0;
    fdListen = socket(AF_INET, SOCK_STREAM, 0);
    int flg;
    if(fdListen == 0)
    {
        exit(EXIT_FAILURE);
    }
    listen_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    listen_addr.sin_family = AF_INET;
    listen_addr.sin_port = htons(atoi(argv[2]));
    int tempRes;
    // printf("Binding the socket to a port")
    tempRes = bind(fdListen, (struct sockaddr *)&listen_addr,sizeof(listen_addr));
    // Check for Bind
    if(tempRes <0)
    {
        exit(EXIT_FAILURE);
    }
    tempRes =listen(fdListen, 4);
    // Check for Listen Function
    if(tempRes>=0){
        int x;
    }
    else
    {
        exit(EXIT_FAILURE);
    }
    
    if(*argv[1] != 's')
        client(&ref_cli, atoi(argv[2]), fdListen);
    else
        server(&head_ref,atoi(argv[2]), fdListen);
    int flg1;
    return 0;
    
    
}

int server(struct client **head_ref, int port_number, int fdListen)
{
    
    int selectRtn;
    struct sockaddr_in client_addr;
    fd_set master_list, watch_list;
    int fdAcc;
    FD_ZERO(&master_list);
    FD_ZERO(&watch_list);
    int cli_add_len=0;
    FD_SET(fdListen, &master_list);
    //Listening socket is being registered
    
    FD_SET(STDIN, &master_list);      //STDIN reg
    int sHead;
    sHead = fdListen;
    fdAcc = 0;
    while(1){
        memcpy(&watch_list, &master_list, sizeof(master_list));
        
        
        /* select() system call. This will BLOCK */
        selectRtn = select(sHead + 1, &watch_list, NULL, NULL, NULL);
        if(selectRtn < 0){
            perror("Failed to select");
        }
        int flg;
        /* Check if we have sockets/STDIN to process */
        if(selectRtn > 0){
            /* Loop through socket descriptors to check which ones are ready */
            for(int socket_idx = 0; socket_idx <= sHead; socket_idx += 1){
                
                if(FD_ISSET(socket_idx, &watch_list)){

                    /* Check if new client is requesting connection */
                    if(socket_idx == fdListen){
                        cli_add_len = sizeof(client_addr);
                        fdAcc = accept(fdListen, (struct sockaddr *)&client_addr, (socklen_t*)&cli_add_len);
                        if(fdAcc >= 0){
                            /* Add to watched socket list */
                            FD_SET(fdAcc, &master_list);
                            if(fdAcc > sHead){
                                sHead = fdAcc;
                            }
                            add_new_client(head_ref, fdAcc, client_addr);
                        }
                        else
                        {
                            perror("Accept failed.");
                        }
                        
                    }
                    
                    if(socket_idx == STDIN){         // Check for new commands in STDIN 
                        char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
                        memset(cmd, '\0', CMD_SIZE);
                        /* Writes the newline char to cmd */
                        int t;
                        char ubit[] = "ishaanil";
                        if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) 
                            exit(-1);
                        //Process PA1 commands here ...
                        if(strcmp(cmd, "AUTHOR\n")==0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n","AUTHOR");
            			    //char *author = (char*) malloc(sizeof(char)*CMD_SIZE);
            			    //author = "I/We have read and understood the course academic integrity policy.\n";
            			    cse4589_print_and_log("I, %s,  have read and understood the course academic integrity policy.\n", ubit);
            			    cse4589_print_and_log("[%s:END]\n","AUTHOR");               
                        }
                        else if(strcmp(cmd, PORT)==0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n","PORT");
                            cse4589_print_and_log("PORT:%d\n",port_number);
                            cse4589_print_and_log("[%s:END]\n","PORT");
                        }    
                        else if(strcmp(cmd, IP)==0)
                        {
                            char ip_str[INET_ADDRSTRLEN];
                            strcpy(ip_str,find_ip(ip_str));
                        }
                        else if(strcmp(cmd, LIST)==0)
                        {
                            print(*head_ref);
                        }
                        
                        
                     
                    }
                    
                    /* Read from existing clients */
                    else{
                        int recd_bytes;
                        /* Initialize buffer to receieve response */
                        if(socket_idx == 0)
                            break;
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
                        memset(buffer, '\0', BUFFER_SIZE);
                        if(recv(recd_bytes = socket_idx, buffer, BUFFER_SIZE, 0) > 0)
                        {
                            struct client *temp = *head_ref;
                            char *send_to_ip = (char*) malloc(sizeof(char)*INET_ADDRSTRLEN);
                            int t;
                            // printf("%s", buffer);
                            send_to_ip = strtok(buffer, " ");
                            
                            if(strcmp(send_to_ip, "Port") != 0)
                            {
                                char * msg = (char*) malloc(sizeof(char)*MSG_LENGTH);
                               // buffer = strtok(NULL, "\n");
                                struct client * temp = *head_ref;
                                while(buffer != NULL)
                                {
                                    buffer= strtok(NULL, " ");
                                    if(buffer!=NULL)
                                    {
                                        strcpy(msg,buffer);
                                    }
                                 }                               
                                temp = *head_ref;
                                send_to_client(socket_idx, send_to_ip, msg ,temp);
                            }
                            else if(strcmp(send_to_ip, "Port") == 0)
                            {
                                int success = 0;
                                char client_list_buf[500];
                                assign_port(buffer, temp);
                                send_client_list(*head_ref, client_list_buf);
                                if(send(fdAcc, client_list_buf, strlen(client_list_buf), 0) == strlen(client_list_buf)){
                                    success = 1;
                                }
                            }
                            
                            fflush(stdout);

                            
                        }
                        else
                        {
                            close(socket_idx);
                            /* Remove from watched list */
                            FD_CLR(socket_idx, &master_list);   
                        }
                        
                        // free(buffer);
                        
                    }
                    
                }
            }
        }
    }
    
    return 0;
}

void add_new_client(struct client **head_ref,int fdAcc, struct sockaddr_in client_addr)
{
    char str_0[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(client_addr.sin_addr), str_0, INET_ADDRSTRLEN);
    struct hostent *name_of_host = NULL;
    struct in_addr ipv4addr;
    int p;
    char str_1[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(client_addr.sin_addr), str_1, INET_ADDRSTRLEN);
    inet_pton(AF_INET, str_1, &ipv4addr);
    int c_var;
    name_of_host = gethostbyaddr(&ipv4addr, sizeof(ipv4addr), AF_INET);
    struct client* new_node = (struct client*) malloc(sizeof(client));
    int t;
    new_node->ip = (char*)malloc(sizeof(MSG_LENGTH));
    strcpy(new_node->ip,str_0);
    c_var = 1;
    strcpy(client_ip[c_var],str_0);
    new_node->listid = c_var;
    c_var++;
    new_node->fd_cli = fdAcc;
    int len_h = (int)strlen(name_of_host->h_name);
    new_node->name_of_host = (char*)malloc(sizeof(len_h));
    strcpy(new_node->name_of_host, name_of_host->h_name);
    new_node->client_status =1;
    
    
    if(*head_ref != NULL){
        new_node->next = *head_ref;
        *head_ref = new_node;
        
    }
    else{
        *head_ref = new_node;
        new_node->next = NULL;
    }
    
    
}


// void get_portnum(int port_number)
// {
//     cse4589_print_and_log("[%s:SUCCESS]\n","PORT");
//     cse4589_print_and_log("PORT:%d\n",port_number);
//     cse4589_print_and_log("[%s:END]\n","PORT");
// }
//void push(struct client** head_ref, int port_number, char* ip)
/* function to swap data of two nodes a and b*/

///// Devansh stopped editing here.

void swap(struct client *a, struct client *b)
{
    int temp;
    temp = a->port_number;
    a->port_number = b->port_number;
    b->port_number = temp;
}


void print(struct client *headref)
{
    cse4589_print_and_log((char *)"[%s:SUCCESS]\n", "LIST");
    struct client *temp = headref;
    int listid = 1;
    
    struct client *start = headref;
    int swap_var;
    struct client *ptr1 = start;
    struct client *lptr = NULL;
    
    if (ptr1 != NULL){
        do
    {
        swap_var = 0;
        ptr1 = start;
        
        while (ptr1->next != lptr)
        {
            if (ptr1->port_number > ptr1->next->port_number)
            {
                swap(ptr1, ptr1->next);
                swap_var = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    }
    while (swap_var);
    
    }
    int flg;
    while(1)
    {
        if(temp==NULL){
            break;
        }
        if(temp->client_status == 1)
        {   cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", listid,temp->name_of_host, client_ip[temp->listid], temp->port_number);}
        temp = temp->next;
        listid = listid +1;
    }
    cse4589_print_and_log((char *)"[%s:END]\n", "LIST");
}
void send_to_client(int socket_idx, char *send_to_ip, char *buffer, struct client *temp)
{
    int j = 1;
    char *str = (char*)malloc(sizeof(MSG_LENGTH));
    char *str1 = (char*)malloc(sizeof(MSG_LENGTH));
    int success;
    char *str2 = (char*)malloc(sizeof(MSG_LENGTH));
    char *from_ip = (char*)malloc(sizeof(MSG_LENGTH));
    struct client *temp1 = temp;

    while(j<=5){
        if(strcmp(send_to_ip,client_ip[j])==0)
        {
            break;
        }
        j = j + 1;
    }
    success = 1;
    while(temp1!= NULL)
                                {
                                    if(temp1->fd_cli == socket_idx)
                                        strcpy(from_ip,client_ip[temp1->listid]);
					temp1 = temp1->next;
                                }
        int pd;
        strcat(str,from_ip);
        strcat(str, " ");
        strcat(str, buffer);

         while(temp->listid != j)
           temp = temp->next;
	
        if(send(temp->fd_cli,str,strlen(str),0) != -1)
          success = 1;
        else { success = 0;}
    
    if(success != 1)
    {
        cse4589_print_and_log("[RELAYED:ERROR]\n");
        //cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from_ip,send_to_ip,buffer);
        cse4589_print_and_log("[RELAYED:END]\n");
    }
    
    else
    {
        cse4589_print_and_log("[RELAYED:SUCCESS]\n");
        cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from_ip,send_to_ip,buffer);
        cse4589_print_and_log("[RELAYED:END]\n");

    }
}

void assign_port(char *buffer, struct client *temp)
{
    char *port,*clientip;int count =0;
    int j=1;

    for(count=0;count<2;count++){
        char *a = (char*) malloc(sizeof(char)*MSG_LENGTH);
        int id;
        strcpy(a,buffer);
        if (count == 1){
            buffer = strtok(NULL, "\n");
                strcpy(a,buffer);
                port = a;
                break;
        }
        else if(count == 0){
            buffer = strtok(NULL, " ");
                strcpy(a,buffer);
                clientip = a;
        }
    }
    
    while(j<=5){
        if(strcmp(clientip,client_ip[j])==0)
        {
            break;
        }
        j = j + 1;
    }
    
    if(j!=6)
    {
        while(temp->listid != j)
            temp = temp->next;
        if(temp != NULL){
            temp->port_number = atoi(port);
        }
        
    }
}

//ISHA EDIT ENDS HERE


void send_port(int listening_port, int server_fd)
{
    char send_port[100];
    //printf("\n String temp %s", port);
    char str_cip[INET_ADDRSTRLEN];
    int pd;
    struct sockaddr_in udp;
    int temp_udp =socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    int len = sizeof(udp);
    //char str[INET_ADDRSTRLEN];
    int result;
    
    memset((char *) &udp, 0, sizeof(udp));
    udp.sin_family = AF_INET;
    udp.sin_port = htons(EPHEMERAL_PORT);
    inet_pton(AF_INET, "8.8.8.8", &udp.sin_addr);
    //udp.sin_addr.s_addr = inet_addr("8.8.8.8");
    int result1;
    if (connect(temp_udp, (struct sockaddr *)&udp, sizeof(udp)) < 0)
    {
        //printf("\nConnection Failed \n");
        result = 0;
    }
    int flg;
    if (getsockname(temp_udp,(struct sockaddr *)&udp,(unsigned int*) &len) == -1)
    {
        perror("getsockname");
        result = 0;
    }
    
    inet_ntop(AF_INET, &(udp.sin_addr), str_cip, len);
    int flg2;
    char port[INET_ADDRSTRLEN];
    //printf("\n fdListen = %d:", listening_port);
    tostring(port, listening_port);
    //printf("%s\n", port);
    strcat(send_port, "Port ");
    strcat(send_port, str_cip);
    strcat(send_port, " ");
    strcat(send_port, port);
    strcat(send_port, "\n");
    int flg3;
    if( send(server_fd, send_port, strlen(send_port),0) == -1 )
        perror("Send");
}
char* find_ip(char *str)
{
    struct sockaddr_in udp;
    int temp_udp =socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    
    //char str[INET_ADDRSTRLEN];
    
    // if (temp_udp == -1)
    // {
    //     //printf("Socket creation failed!");
    // }
    
    memset((char *) &udp, 0, sizeof(udp));
    udp.sin_family = AF_INET;
    udp.sin_port = htons(EPHEMERAL_PORT);
    inet_pton(AF_INET, "8.8.8.8", &udp.sin_addr);
    //udp.sin_addr.s_addr = inet_addr("8.8.8.8");
    int result;
    if (connect(temp_udp, (struct sockaddr *)&udp, sizeof(udp)) < 0)
    {
        //printf("\nConnection Failed \n");
        result = 0;
    }
    int len = sizeof(udp);
    if (getsockname(temp_udp,(struct sockaddr *)&udp,(unsigned int*) &len) == -1)
    {
        perror("getsockname");
        result = 0;
    }
    
    inet_ntop(AF_INET, &(udp.sin_addr), str, len);
    //printf("%s", str);
    
    //Success
    if( result==0)
    {
        //Error
        cse4589_print_and_log("[%s:ERROR]\n", "IP");
        cse4589_print_and_log("[%s:END]\n", "IP");
        
    }
    else{
        cse4589_print_and_log("[%s:SUCCESS]\n","IP");
        cse4589_print_and_log("IP:%s\n", str);
        cse4589_print_and_log("[%s:END]\n","IP");
    }
    return str;
}
int isValidIP(char *ip)
{
    int dots;
    char *ptr = ip;
    strcat(ptr,"\0");
    dots = 0;
    if(ip == NULL)
        return 0;
    int flag;
    ptr = strtok(ptr, ".");
    while(ptr != NULL )
    {
        // if (!valid_digit(ptr))
        //     return 0;
        
        flag = 1;
        while (*ptr) {
            if (*ptr >= '0' && *ptr <= '9')
                ptr = ptr +1;
            else
                flag=0;
        }

        if (flag == 0)
            return 0;

        if(atoi(ptr)>=0 && atoi(ptr)<=255)
        {
            ptr = strtok(NULL, ".");
            if (ptr != NULL)
                dots = dots + 1;
        }
        else
            return 0;
    }
    
    if(dots==3){
        return 1;
    }
    else{
        return 0;
    }
} 


void tostring(char str[], int num)
{
    int rem, n;
    
    n = num;
    int len =0;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    int i = 0;
    while (i<len){
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
        i++;
    }
    str[len] = '\0';
}

void send_client_list(struct client* headref, char client_list[])
{
    struct client* temp = headref;
    char buf[500] = "";
    strcat(buf, "List");
    int flg;
    char str[20]= "";
    char listid[10]= "";
    while(1)
    {
        if(temp == NULL){
            break;
        }
        if(temp->client_status == 1)
        {
            strcat(buf, " ");
            tostring(listid, temp->listid);
            strcat(buf, listid);
            strcat(buf, " ");
            tostring(str,temp->port_number);
            strcat(buf,str);
            strcat(buf, " ");
            strcat(buf, temp->name_of_host);
            strcat(buf, "\n");
            strcat(buf,client_ip[temp->listid]);
            // strcat(buf, temp->blck_stat);
            strcat(buf, "\n");
        }
        temp = temp->next;
    }
    // printf("\n List: %s", buf);
    strcpy(client_list,buf);
    
    //return client_list;
}
void create_client_list(struct client **ref_cli, char *buffer)
{
    int i;
    char *string[256];
    //char delim = "\n";
    i =0;
    string[i]=strtok(buffer,"\n");
    while(string[i]!=NULL)
    {
        i = i + 1;
        string[i]=strtok(NULL,"\n");
    }
    
    for (int j=0;j<i;j++)
    {
        int counter = 0;
        // printf("%s \n", string[j]);
        char *val = strtok(string[j], " ");
        
        struct client *new_node = (struct client*) malloc(sizeof(client));
        while (val != NULL)
        {
            
            //printf("%s\n", val);
            if(j != 0)
            {
                switch(counter){
                    case 0:
                        new_node->listid = atoi(val);
                        break;
                    case 1:
                        new_node->port_number = atoi(val);
                        break;
                    case 2:
                        new_node->name_of_host = (char*)malloc(sizeof(MSG_LENGTH));
                        strcpy(new_node->name_of_host,val);
                        break;
                    case 3:
                        new_node->ip = (char*)malloc(sizeof(MSG_LENGTH));
                        strcpy(new_node->ip, val);
                        strcpy(client_ip[new_node->listid],val);
                        break;
                }                
            }
            else
            {
                switch(counter){
                    case 0:
                        break;
                    case 1:
                        new_node->listid = atoi(val);
                        break;
                    case 3:
                        new_node->name_of_host = (char*)malloc(sizeof(MSG_LENGTH));
                        strcpy(new_node->name_of_host,val);
                        break;
                    case 2:
                        new_node->port_number = atoi(val);
                        break;
                    case 4:
                        new_node->ip = (char*)malloc(sizeof(MSG_LENGTH));
                        strcpy(new_node->ip, val);
                        strcpy(client_ip[new_node->listid],val);
                        break;

                }
            }
                        
            val = strtok(NULL, " ");
            counter +=1;
            
        }
        if(*ref_cli!=NULL){
            new_node->next = *ref_cli;
            *ref_cli = new_node;
        }
        else{
            *ref_cli = new_node;
            new_node->next = NULL;
        }
    }
}


void broadcast(struct client *ref_cli, char *msg, int server_fd)
{
    char ip_str[INET_ADDRSTRLEN];
    //strcpy(ip_str,find_ip(ip_str));
    int i;
    struct sockaddr_in udp;
    int temp_udp =socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    
    int len = sizeof(udp);
    memset((char *) &udp, 0, sizeof(udp));
    udp.sin_family = AF_INET;
    udp.sin_port = htons(EPHEMERAL_PORT);
    inet_pton(AF_INET, "8.8.8.8", &udp.sin_addr);
    //udp.sin_addr.s_addr = inet_addr("8.8.8.8");
    int result;
    if (connect(temp_udp, (struct sockaddr *)&udp, sizeof(udp)) < 0)
    {
        //printf("\nConnection Failed \n");
        result = 0;
    }
    int pd;
    if (getsockname(temp_udp,(struct sockaddr *)&udp,(unsigned int*) &len) == -1)
    {
        perror("getsockname");
        result = 0;
    }
    
    inet_ntop(AF_INET, &(udp.sin_addr), ip_str, len);
    //printf("%s", str);
    int check;
    struct client *temp = ref_cli;
    char *send_buf = (char*)malloc(sizeof(char)*MSG_LENGTH);
    int count = 0;
    int p;
    while(temp!=NULL)
    {
        p = strcmp(client_ip[temp->listid],ip_str);
        if(p!=0)
        {
            
            strcat(send_buf,client_ip[temp->listid]);
            strcat(send_buf," ");
            strcat(send_buf,msg);
            int ct;
            if(send(server_fd, send_buf, strlen(send_buf),0) > 0 )
                count= count +1;
                // ct++
        }
        temp = temp->next;
        //free(send_buf);
        //send_buf = NULL;

    }
    if(count <= 0)
    {
        cse4589_print_and_log("[RELAYED:ERROR]\n");
        //cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from_ip,send_to_ip,buffer);
        cse4589_print_and_log("[RELAYED:END]\n");
    }
    else
    {
        cse4589_print_and_log("[RELAYED:SUCCESS]\n");
        cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",ip_str,msg);
        cse4589_print_and_log("[RELAYED:END]\n");
    }

}

/// Edit done by Devansh till 880

int client(struct client **ref_cli, int port_number, int fdListen)
{
    struct sockaddr_in server_addr;
    int server_fd;
    int loggedin = 0;
    fd_set masterlist, watchlist;
    char *cmd= (char*) malloc(sizeof(char)*MSG_LENGTH);
    char *input;
    int flg;
    char *in_port= (char*) malloc(sizeof(char)*MSG_LENGTH);
    char *recv_buf= (char*) malloc(sizeof(char)*MSG_LENGTH);
    int pd;
    char *send_buf= (char*) malloc(sizeof(char)*MSG_LENGTH);
    char *clientip;
    int f;
    int server;
    char ubit[] = "ishaanil" ;
    char *msg=(char*) malloc(sizeof(char)*MSG_LENGTH);
    char *serverip = (char*) malloc(sizeof(char)*MSG_LENGTH);
    size_t nbyte_recvd;
    char *command= (char*) malloc(sizeof(char)*MSG_LENGTH);
    int cmax;
    FD_ZERO(&masterlist);
    FD_ZERO(&watchlist);
    FD_SET(0,&masterlist);
    cmax =0;
    server = fdListen;
    
    while(1)
    {
        watchlist = masterlist;
        int selectRtn = select(cmax+1, &watchlist, NULL, NULL, NULL);
        if( selectRtn == -1)
        {
            perror("select");
        }
        
        if(selectRtn > 0)
        {
            
            for(int i=0; i<=cmax; i++)
            {
                if(FD_ISSET(i, &watchlist))
                {
                    memset(cmd, '\0', MSG_LENGTH);
                    memset(recv_buf, '\0', MSG_LENGTH);
                    if (i == STDIN)
                    {
                        if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to cmd
                            exit(-1);
                        strcpy(command,cmd);
                        input = strtok(cmd, " ");
                        
                        if(strcmp(cmd, "AUTHOR\n")==0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n","AUTHOR");
                            cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", ubit);
                            cse4589_print_and_log("[%s:END]\n","AUTHOR");
                        }
                        int flg;
                        if(strcmp(cmd,IP)==0)
                        {
                            char ip_str[INET_ADDRSTRLEN];
                            strcpy(ip_str,find_ip(ip_str));
							int ct2;
                        }
                        else if(strcmp(cmd,"LIST\n")==0) {
                            print(*ref_cli);
						}
                        else if(strcmp(cmd,"PORT\n")==0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n","PORT");
                            cse4589_print_and_log("PORT:%d\n",port_number);
                            cse4589_print_and_log("[%s:END]\n","PORT");
                        }
                        else if (strcmp(input ,"LOGIN") == 0)
                        {
                            int count =0, result = 1;
                            server_fd = socket(AF_INET, SOCK_STREAM, 0);
                            if(server_fd > 0)
                            {
                                FD_SET(server_fd, &masterlist);
                                if(server_fd > cmax)cmax = server_fd;
                                
                            }
                            else
                            {
                                exit(EXIT_FAILURE);
                                
                            }
                            
                            while(count != 2)
                            {
                                char *a = (char*) malloc(sizeof(char)*CMD_SIZE);
                                int pd;
                                if(count == 0)
                                {
                                    input = strtok(NULL, " ");
                                    strcpy(a,input);
                                    serverip = a;
                                }
                                else if(count == 1)
                                {
                                    
                                    input = strtok(NULL, "\n");
                                    if(input != NULL){
                                        strcpy(a,input);
                                        in_port = a;
                                        break;
                                    }
                                    else{
                                        result = 0;
                                    }
                                }
                                
                                count +=1;
                            }
                            char *temp = serverip;
                            int in;
                            if(result == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", "LOGIN");
                                cse4589_print_and_log("[%s:END]\n", "LOGIN");
                            }
                            else{
                                
                                server_addr.sin_family = AF_INET;
                                unsigned int port_temp = atoi(in_port);
                                int x;
                                server_addr.sin_port = htons(port_temp);
                                inet_pton(AF_INET, serverip, &(server_addr.sin_addr));
                                if (connect(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) >0)
                                {
                                    send_port(port_number, server_fd);
                                }
                                
                                else
                                {
                                    cse4589_print_and_log("[%s:ERROR]\n", "LOGIN");
                                    cse4589_print_and_log("[%s:END]\n", "LOGIN");
                                    
                                }
                                

                                cse4589_print_and_log("[%s:SUCCESS]\n", "LOGIN");
                                cse4589_print_and_log("[%s:END]\n", "LOGIN");
                            }
                            
                        }
                        else if((strcmp(msg,"REFRESH"))==0&&
								loggedin==0)
				        {  
				        	cse4589_print_and_log("[REFRESH:SUCCESS]\n"); 
				        	cse4589_print_and_log("[REFRESH:END]\n");                 
				        }
                        else if(strcmp(input, "SEND")==0)
                        {
                            int count;
                            count = 0;
                            while(count != 2)
                            {
                                char *a = (char*) malloc(sizeof(char)*MSG_LENGTH);
                                strcpy(a,input);
                                if(count == 1)
                                {
                                    input = strtok(NULL, "\n");
                                    strcpy(a,input);
                                    msg = a;
                                    break;
                                }
                                else if(count == 0)
                                {
                                    input = strtok(NULL, " ");
                                    strcpy(a,input);
                                    clientip = a;
                                    
                                }
                                
                                count = count + 1;
                            }
                            memset(send_buf, '\0', MSG_LENGTH);
                            int pd;
                            server_addr.sin_family = AF_INET;
                            server_addr.sin_port = port_number;
                            inet_pton(AF_INET, clientip, &(server_addr.sin_addr));
                            int flg;
                            strcat(send_buf,clientip);
                            strcat(send_buf," ");
                            strcat(send_buf,msg);
                            strcat(send_buf, "\n");
                            send(server_fd, send_buf, strlen(send_buf),0);
                            
                        }
                        else if(strcmp(input, "BROADCAST")==0)
                        {
                            char *a = (char*) malloc(sizeof(char)*MSG_LENGTH);
                            int pld;
			 	            while(input != NULL)
                            {
                                input= strtok(NULL, "\n");
       						    if(input!=NULL)
        					    strcpy(a,input);
                                break;
                            }
                            broadcast(*ref_cli,a, server_fd);
                            
                        }
                        else if(strcmp(input, "BLOCK")== 0)
                        {
                         
                            input = strtok(NULL, "\n");
                            
                            int found;
                            struct client *temp = *ref_cli;
                            
                            found = 0;
                            while(temp != NULL)
                            {
                            if(strcmp(input,client_ip[temp->listid]) == 0)
                            {
                               temp->blck_stat = 1;
                                found=found +1;
                            }
                                
                            temp = temp->next;
                                
                            }
                            if(found<1)
                            {
                                cse4589_print_and_log((char *)"[%s:ERROR]\n","BLOCK");
                                cse4589_print_and_log((char *)"[%s:END]\n","BLOCK");
                                
                            }
                            else
                            {
                                cse4589_print_and_log((char *)"[%s:SUCCESS]\n","BLOCK");
                                cse4589_print_and_log((char *)"[%s:END]\n","BLOCK");
                            }
                            
                            
                        }
                        else if(strcmp(input, "UNBLOCK")== 0)
                        {
                            // char *a = (char*) malloc(sizeof(char)*MSG_LENGTH);
                            input = strtok(NULL, "\n");
                            int found;
                           // printf("%s", input);
                            
                            struct client *temp = *ref_cli;
                            found = 0;
                            while(temp != NULL)
                            {
                                if(strcmp(input,client_ip[temp->listid]) == 0)
                                {
                                    temp->blck_stat = 0;
                                    found= found+1;
                                }
                                
                                temp = temp->next;
                                
                            }
                            int flg;
                            if(found>=1)
                            {
                                cse4589_print_and_log((char *)"[%s:SUCCESS]\n","UNBLOCK");
                                cse4589_print_and_log((char *)"[%s:END]\n","UNBLOCK");
                            }
                            else{
                                cse4589_print_and_log((char *)"[%s:ERROR]\n","UNBLOCK");
                                cse4589_print_and_log((char *)"[%s:END]\n","UNBLOCK");
                            }
                            
                            
                        }

                        
                        else if(strcmp(cmd,"LOGOUT\n")==0){
                            cse4589_print_and_log((char *)"[%s:SUCCESS]\n","LOGOUT");
                            close(server_fd );
                            cse4589_print_and_log((char *)"[%s:END]\n","LOGOUT");
							int x;
                            return 0;
                        }
                        else if(strcmp(cmd, "EXIT\n")==0) {
                            cse4589_print_and_log((char *)"[%s:SUCCESS]\n", (char*)"EXIT");
                            close(server_fd);
                            cse4589_print_and_log((char *)"[%s:END]\n", (char*)"EXIT");
                            exit(0);
                        }    
                    }
                    
                    
                    else
                    {
                        memset(recv_buf, '\0', MSG_LENGTH);
                        if(i == 0 && i==fdListen)
                            break;
                        else
                        {
                            nbyte_recvd = recv(i, recv_buf, MSG_LENGTH, 0);
                            recv_buf[nbyte_recvd] = '\0';
 			    char *input = (char*) malloc(sizeof(char)*MSG_LENGTH);;
                            strcpy(input, recv_buf);
                            struct client *temp = *ref_cli;
                            char *identify = (char*) malloc(sizeof(char)*MSG_LENGTH);
                            strcpy(identify,recv_buf);
                            identify = strtok(identify, " ");
                            if(strcmp(identify, "List") == 0)
                            {
                                create_client_list(ref_cli, recv_buf);
                            }
                            else
                            {
				char *msg_from = (char*)malloc(sizeof(MSG_LENGTH));
				    char *a = (char*)malloc(sizeof(MSG_LENGTH));
				    char *msg = (char*)malloc(sizeof(MSG_LENGTH));
					
                                int count = 0;
                                if(recv_buf!=NULL)
                                {
							
					input = strtok(input, " ");
    					strcpy(msg_from, input);
    					while(input != NULL)
    					{
        					input= strtok(NULL, " ");
       						 if(input!=NULL)
        					strcpy(msg,input);

    					}

                                    cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
                                    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",msg_from,msg);
                                    cse4589_print_and_log("[RECEIVED:END]\n");
				
                                }
                                else
                                {
                                    cse4589_print_and_log("[RECEIVED:ERROR]\n");
                                    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",msg_from,msg);
                                    cse4589_print_and_log("[RECEIVED:END]\n");
                                }
                                
                            }
                        }
                        fflush(stdout);
                    }
                }
            }
        }
    }
    
}
