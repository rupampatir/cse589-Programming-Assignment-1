#include <iostream>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>
//#include "../include/server.h"
using namespace std;
#include "../include/global.h"
#include "../include/logger.h"
int client_num;
fd_set master_list, watch_list;
struct client{
	int socket_id;
	int no;
	char hostname[128];
	char ip_addr[INET_ADDRSTRLEN];
	int port_no;
	char blockedList[10][INET_ADDRSTRLEN];
	int block_num;
    int login_status;
    int send_msg_num;
    int recv_msg_num;
    char msg_buffer[100][BUFFER_SIZE];
	int buffered_msg;
}clients[BACKLOG];
int create_server(int port) {
    //fd_set master_list, watch_list;
    //setup a socket and connection tools
    cout<<port;
    int yes = 1;
    socklen_t caddr_len;
    int head_socket, selret, sock_index, fdaccept = 0;
    struct sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = INADDR_ANY;
    servAddr.sin_port = htons(port);
 
    //open stream oriented socket with internet address
    //also keep track of the socket descriptor
    int serverSd = socket(AF_INET, SOCK_STREAM, 0);
    if(serverSd < 0)
    {
        exit(0);
    }
    if(serverSd == 0)
    {
        exit(0);
    }
    //bind the socket to its local address
    int bindStatus = bind(serverSd, (struct sockaddr*) &servAddr, 
        sizeof(servAddr));
    if(bindStatus < 0)
    {
        close(serverSd);
        exit(0);

    }

 	setsockopt(serverSd,SOL_SOCKET,SO_REUSEADDR, &yes,sizeof(int));   

	// Listen
	if(listen(serverSd, BACKLOG) < 0)
    	perror("Unable to listen on port");
	
    FD_ZERO(&master_list);
    FD_ZERO(&watch_list);
    
   
    FD_SET(serverSd, &master_list);
    
    FD_SET(STDIN, &master_list);
	
	head_socket = serverSd;
	char* ip_addr;
	ip_addr = get_ip();
    //get the user input from command prompt 
    while(TRUE){
        memcpy(&watch_list, &master_list, sizeof(master_list));
        
        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
        if(selret < 0)
            perror("select failed.");

        
        if(selret > 0){
            
            for(sock_index=0; sock_index<=head_socket; sock_index+=1){

                if(FD_ISSET(sock_index, &watch_list)){

                    
                    if (sock_index == STDIN){
                    	char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);

                    	memset(cmd, '\0', CMD_SIZE);
						if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) 
							exit(-1);

						printf("\nServer got: %s\n", cmd);
						cmd[strlen(cmd)-1]='\0';
						
						
						if(strcmp(cmd, "AUTHOR") == 0){

							author(cmd);

						}
						else if(strcmp(cmd, "IP") == 0){

							ip(ip_addr, cmd);

						}
						else if(strcmp(cmd, "PORT") == 0){

							get_port(serverSd, cmd, port);

						} 
                        else if(strcmp("EXIT",cmd) == 0){

							close(serverSd);
							exit(0);

						}
                        else if(strcmp(cmd, "LIST") == 0){
							cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
							for (int i = 0; i < client_num; i++){

								if(clients[i].login_status == 1){
						
									cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",clients[i].no,clients[i].hostname,clients[i].ip_addr,clients[i].port_no);

								}
							}
							cse4589_print_and_log("[%s:END]\n", cmd);  
						}
                        else if(strcmp(cmd, "STATISTICS") == 0){

							cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
							for (int i = 0; i < client_num; i++){
								char status[25];
								bzero(status,25);
								if(clients[i].socket_id > 0){
									if(clients[i].login_status == 1){
										strcpy(status,"logged-in");
									}
									else if(clients[i].login_status == 0){
										strcpy(status,"logged-out");
									}
									else{
										continue;
									}
									cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", clients[i].no, clients[i].hostname, clients[i].send_msg_num, clients[i].recv_msg_num, status);
								}
							}
							cse4589_print_and_log("[%s:END]\n", cmd);  
						}
						else if(strncmp(cmd, "BLOCKED", 7)==0){

							char *p;
							p = strtok(cmd," ");
							if(p!=NULL){
								p = strtok(NULL," ");
							}else{
								cse4589_print_and_log("[%s:ERROR]\n", cmd);
								cse4589_print_and_log("[%s:END]\n", cmd);
								return 0;

							}
							char check_b_ip[INET_ADDRSTRLEN];
							strcpy(check_b_ip,p);
							struct client blocklist[15];
							int n = 0;
							
							for (int i = 0; i < client_num; i++){
								if(strcmp(clients[i].ip_addr,check_b_ip)==0){
									if(clients[i].block_num>0){
										for(int j = 0; j < clients[i].block_num;j++){
											printf("%s\n", clients[i].blockedList[j]);
											for (int m = 0; m < client_num; m++){
												if(strcmp(clients[m].ip_addr,clients[i].blockedList[j])==0){
													strcpy(blocklist[n].hostname, clients[m].hostname);
													strcpy(blocklist[n].ip_addr, clients[m].ip_addr);
													blocklist[n].port_no = clients[m].port_no;
													n++;
													
												}
											}
										}
									}
								}
								
							}
							struct client temp;
    						for (int i = 0; i < n; i++){
    							for (int j = i + 1; j < n; j++){
      								if(blocklist[i].port_no>blocklist[j].port_no){
       									temp = blocklist[i];
       									blocklist[i] = blocklist[j];
       									blocklist[j] = temp;
      
      								}
     							}
    						}
    						cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
    						for(int i = 0; i < n; i++){

    							cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",i+1,blocklist[i].hostname,blocklist[i].ip_addr,blocklist[i].port_no);

    						}

							cse4589_print_and_log("[%s:END]\n", cmd);  

						}

						free(cmd);
                    }
                    
                    else if(sock_index == serverSd){
                    	char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
						struct sockaddr_in client_addr;
                        caddr_len = sizeof(client_addr);
                        fdaccept = accept(serverSd, (struct sockaddr *)&client_addr, &caddr_len);
                        if(fdaccept < 0){
                            perror("Accept failed.");
						}
						printf("\nRemote Host connected!\n the fd is: %d\n",fdaccept);    
						 
						FD_SET(fdaccept, &master_list);

						client_num = add_to_clients(fdaccept, client_addr, client_num, 0);
						
						free(buffer);
						if(fdaccept > head_socket) head_socket = fdaccept;
                    }
                    
                    else{
                       
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
                        memset(buffer, '\0', BUFFER_SIZE);

                        if(recv(sock_index, buffer, BUFFER_SIZE, 0) <= 0){
                            close(sock_index);
                            printf("Remote Host terminated connection!\n");
                            client_num--;

                            
                            FD_CLR(sock_index, &master_list);
                        }
                        else {
                        	
                        	char *cmd = buffer;
	                       	printf("\nClient sent me: %s\n", cmd);
							process_cmd_from_client(cmd, sock_index);	                        	
							fflush(stdout);


                        }

                        free(buffer);
                    }
                }
            }
        }
    }
    
    
    return 0;
}

int process_cmd_from_client(char *msg, int sock_index){

	char *sender_ip;
	int sender_no;
    for(int i =0; i<client_num; i++)
    {
        if(sock_index ==clients[i].socket_id)
        { 
           sender_ip = clients[i].ip_addr;
           sender_no = i;
           break;
        }
    }	
    
    char *cmd, c_ip[INET_ADDRSTRLEN], *token, c_msg[MSG_SIZE], send_buf[BUFFER_SIZE];

    bzero(send_buf,BUFFER_SIZE);
    bzero(c_msg,MSG_SIZE);
    bzero(c_ip,INET_ADDRSTRLEN);

    token = strtok(msg, " ");

    if(token != NULL)
    {      
        cmd = token;
        token = strtok(NULL, " ");
    }
    else{
    	cmd = msg;
    }

    printf("We get this CMD:%s\n", cmd);

    if (strcmp("SEND",cmd)==0) {
    	int target_socket = 0;
    	int count = 0;
		char *words[10];

		while( token != NULL){

			words[count] = token;
			count++;
    		token = strtok (NULL, " ");

		}
		if(count<1){
			cse4589_print_and_log("[RELAYED:ERROR]\n");
        	cse4589_print_and_log("[RELAYED:END]\n");
        	return 0;
		}

		if(count>=1){
			for(int i = 1; i < count; i++){
				strcat(c_msg,words[i]);
				strcat(c_msg," ");
			}
		}
		if(c_msg[strlen(c_msg)-1]==' '){
			c_msg[strlen(c_msg)-1]='\0';
		}
		strcpy(c_ip,words[0]);
		strcat(send_buf,"msg_send ");
		strcat(send_buf,sender_ip);		
        strcat(send_buf," ");
        strcat(send_buf,c_msg);

        fflush(stdout);
        int n = 0;
        int if_login = check_if_login(c_ip);
        int if_block = check_if_block(c_ip,sender_ip);
		if(if_login == 1 && if_block == 0){
			target_socket = search_client_by_ip(c_ip);
			if(target_socket > 0){
				if(send(target_socket, send_buf, strlen(send_buf),0)>0){
					n++;
					for (int i =0; i< client_num;i++){
						if(strcmp(clients[i].ip_addr,c_ip)==0){
							clients[i].recv_msg_num++;
							clients[sender_no].send_msg_num++;
							break;
						}
					}
					fflush(stdout);
				}
			}
		}else if(if_login == 0 && if_block == 0){
			if( target_socket = search_client_by_ip(c_ip)>0){
				for (int i =0; i< client_num;i++){
					if(strcmp(clients[i].ip_addr,c_ip)==0&&clients[i].buffered_msg<100){
						strcpy(clients[i].msg_buffer[clients[i].buffered_msg],send_buf);
						n++;
						clients[i].buffered_msg++;
						clients[sender_no].send_msg_num++;
						break;
					}
				}
			}
		}
		else{
        	cse4589_print_and_log("[RELAYED:ERROR]\n");
        	cse4589_print_and_log("[RELAYED:END]\n");
		}

		if(n > 0){
			cse4589_print_and_log("[RELAYED:SUCCESS]\n");
			cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip, c_ip, c_msg);
			cse4589_print_and_log("[RELAYED:END]\n");
		}else{
			cse4589_print_and_log("[RELAYED:ERROR]\n");
			cse4589_print_and_log("[RELAYED:END]\n");
		}

		bzero(send_buf,BUFFER_SIZE);


    }
    else if (strcmp("BROADCAST",cmd) == 0){
    	int target_socket = 0;
    	char broadcast_msg[MSG_SIZE];
    	bzero(broadcast_msg,MSG_SIZE);
    	if( token != NULL){

			strcpy(broadcast_msg,token);
    		token = strtok (NULL, " ");

		}
		
		strcat(send_buf,"msg_broad ");
		strcat(send_buf,sender_ip);		
        strcat(send_buf," ");
        strcat(send_buf,broadcast_msg);
        int count = 0;
		for(int i = 0; i < client_num; i++){
			if(i != sender_no){
				target_socket = clients[i].socket_id;
				if(clients[i].login_status == 1 && check_if_block(clients[i].ip_addr,sender_ip) == 0){
					if(send(target_socket, send_buf, strlen(send_buf),0)>0){
						count++;
						clients[i].recv_msg_num++;
						clients[sender_no].send_msg_num++;
						fflush(stdout);
					}
				}
				else if(clients[i].login_status == 0 && check_if_block(clients[i].ip_addr,sender_ip) == 0){
					for (int m =0; m< client_num;m++){
						if(strcmp(clients[m].ip_addr,clients[i].ip_addr)==0&&clients[m].buffered_msg<100){
							strcpy(clients[m].msg_buffer[clients[m].buffered_msg],send_buf);
							count++;
							clients[m].buffered_msg++;
							clients[sender_no].send_msg_num++;
						}
					}
				}
			}
		}
		if(count>0){
			cse4589_print_and_log("[RELAYED:SUCCESS]\n");
			cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip, "255.255.255.255", broadcast_msg);
			cse4589_print_and_log("[RELAYED:END]\n");
		}else{
			cse4589_print_and_log("[RELAYED:ERROR]\n");
			cse4589_print_and_log("[RELAYED:END]\n");
		}
	}
	else if (strcmp("LOGOUT",cmd) == 0){

    	for(int i = 0;i<client_num;i++)
        {
            if(sock_index == clients[i].socket_id)
            {
            	
                clients[i].login_status = 0;
                close(sock_index);
            	FD_CLR(sock_index,&master_list);
                break;
            }
        }

    }
    else if (strcmp("REFRESH",cmd) == 0){
    	for(int i = 0;i<client_num;i++)
        {
            if(sock_index == clients[i].socket_id)
            {
                sort_list();
                send_login_list_refresh(sock_index);
				break;
            }
        }
    }
    else if(strcmp("PORT_SEND",cmd) == 0){
		char temp[MSG_SIZE];	

		strcpy(temp,token);		
		int client_port = atoi(temp);
		
		for(int i = 0; i< client_num; i++){
		
			if(clients[i].socket_id == sock_index){
				clients[i].port_no = client_port;
				clients[i].login_status = 1;
				break;
			}
		
		}
		
        sort_list();
		send_login_list(sock_index);
		if(clients[sender_no].buffered_msg > 0){
			int buf_num = clients[sender_no].buffered_msg;
			for (int k = 0; k < buf_num; k++){
				if(send(sock_index,clients[sender_no].msg_buffer[k],strlen(clients[sender_no].msg_buffer[k]),0)>0){
					bzero(clients[sender_no].msg_buffer[k],BUFFER_SIZE);
					clients[sender_no].buffered_msg--;
					clients[sender_no].recv_msg_num++;
					usleep(5000);
				}
			}
			usleep(5000);
			send(sock_index,"LOGINSUCCESS",12,0);
		}else{
			usleep(5000);
			send(sock_index,"LOGINSUCCESS",12,0);
		}

	}
	else if(strcmp("BLOCK_IP",cmd) == 0){
		char c_ip[INET_ADDRSTRLEN];
		bzero(c_ip,INET_ADDRSTRLEN);
		if( token != NULL){

			strcat(c_ip,token);
    		token = strtok (NULL, " ");

		}
		for(int i = 0; i < client_num; i++){
			if (clients[i].socket_id == sock_index){
				strcat(clients[i].blockedList[clients[i].block_num],c_ip);
				clients[i].block_num++;
				break;
			}
		}

	}else if(strcmp("UNBLOCK_IP",cmd) == 0){
		char c_ip[INET_ADDRSTRLEN];
		bzero(c_ip,INET_ADDRSTRLEN),INET_ADDRSTRLEN;
		if( token != NULL){

			strcat(c_ip,token);
    		token = strtok (NULL, " ");

		}
		for(int i = 0; i < client_num; i++){
			if (clients[i].socket_id == sock_index){
				for(int j = 0; j<clients[i].block_num;j++){
					if (strcmp(clients[i].blockedList[j],c_ip)==0 ){
						bzero(clients[i].blockedList[j],INET_ADDRSTRLEN);
						
						break;
					}
				}
			}
			break;
		}
	}
}
int check_if_block(char ip[INET_ADDRSTRLEN],char sender_ip[INET_ADDRSTRLEN]){

	for(int i = 0; i< client_num; i++){
		
		if(strcmp(clients[i].ip_addr,ip) == 0){

			for (int j = 0; j < clients[i].block_num; i++){

				if(strcmp(clients[i].blockedList[j],sender_ip) == 0){
					return 1;
					break;
				}

			}
			break;
		}


	}
	return 0;
}
int add_to_clients(int fdaccept, struct sockaddr_in client_addr, int i, int client_port){
	for(int j = 0; j < client_num; j++){
		if(strcmp(clients[j].ip_addr,inet_ntoa(client_addr.sin_addr))==0){
			return i;

			break;
		}
	}

	char host[1024];
	char service[20];
	clients[i].socket_id = fdaccept;
	clients[i].no = i + 1;
	getnameinfo((struct sockaddr *) &client_addr, sizeof client_addr, host, sizeof host, service, sizeof service, 0);
	strcpy(clients[i].hostname, host);
	strcpy(clients[i].ip_addr, inet_ntoa(client_addr.sin_addr));
	clients[i].login_status = 1;
	clients[i].send_msg_num = 0;
	clients[i].recv_msg_num = 0;
	clients[i].block_num = 0;

	return i+1;
}
int author(char *cmd){

	char your_ubit_name[10] = "nivethak";

	cse4589_print_and_log("[%s:SUCCESS]\n", cmd); 
	cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", your_ubit_name);
	cse4589_print_and_log("[%s:END]\n", cmd);
	
	return 0;
}
//print ip
int ip(char* ip_addr, char *cmd){

	cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
	cse4589_print_and_log("IP:%s\n", ip_addr);
	cse4589_print_and_log("[%s:END]\n", cmd);

	return 0;
}
//print port
int get_port(int socket,char *cmd, int the_port){

	cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
	cse4589_print_and_log("PORT:%d\n", the_port);
	cse4589_print_and_log("[%s:END]\n", cmd);
    return 0;
}
//parse ip of current host
char* get_ip(void)
{
       int s;
       struct ifconf conf;
       struct ifreq *ifr;
       char buff[BUFFER_SIZE];
       int num;
       int i;

       s = socket(PF_INET, SOCK_DGRAM, 0);
       conf.ifc_len = BUFFER_SIZE;
       conf.ifc_buf = buff;

       ioctl(s, SIOCGIFCONF, &conf);
       num = conf.ifc_len / sizeof(struct ifreq);
       ifr = conf.ifc_req;

       for(i=0;i < num;i++)
       {
            struct sockaddr_in *sin = (struct sockaddr_in *)(&ifr->ifr_addr);
            ioctl(s, SIOCGIFFLAGS, ifr);
           if(((ifr->ifr_flags & IFF_LOOPBACK) == 0) && (ifr->ifr_flags & IFF_UP))
            {
                char* ipaddr = inet_ntoa(sin->sin_addr);
                return ipaddr;
            }
            ifr++;
       }
}
//send list of loggedin users
int send_login_list(int client_socket){

	char login_msg[1024];
	char temp[1024];
	memset(login_msg,'\0',1024);
	memset(temp,'\0',1024);

	strcat(login_msg,"CLIST ");
	for(int i = 0;i < client_num;i++){
		if(clients[i].login_status>0){

			sprintf(temp, "%d", clients[i].no);
			strcat(login_msg, temp);
			memset(temp,'\0',1024);
			strcat(login_msg, ",");
			strcat(login_msg, clients[i].hostname);
			strcat(login_msg, ",");
			strcat(login_msg, clients[i].ip_addr);
			strcat(login_msg, ",");
			sprintf(temp, "%d", clients[i].port_no);
			strcat(login_msg, temp);
			strcat(login_msg, " ");

		}
	}

	int len = send(client_socket, login_msg, sizeof(login_msg), 0);
	if (len > 0)
		printf("Done in list send\n");
	fflush(stdout);

	return 0;
}
//send loggedin users after refresh
int send_login_list_refresh(int client_socket){

	char login_msg[1024];
	char temp[1024];
	memset(login_msg,'\0',1024);
	memset(temp,'\0',1024);

	strcat(login_msg,"refresh ");
	for(int i = 0;i < client_num;i++){
		if(clients[i].login_status>0){

			sprintf(temp, "%d", clients[i].no);
			strcat(login_msg, temp);
			memset(temp,'\0',1024);
			strcat(login_msg, ",");
			strcat(login_msg, clients[i].hostname);
			strcat(login_msg, ",");
			strcat(login_msg, clients[i].ip_addr);
			strcat(login_msg, ",");
			sprintf(temp, "%d", clients[i].port_no);
			strcat(login_msg, temp);
			strcat(login_msg, " ");

		}
	}

	int len = send(client_socket, login_msg, sizeof(login_msg), 0);
	if (len > 0)
		printf("Done in refresh list send\n");
	fflush(stdout);

	return 0;
}
int check_if_login(char ip[INET_ADDRSTRLEN]){

	for(int i = 0; i< client_num; i++){
		
		if(strcmp(clients[i].ip_addr,ip) == 0 && clients[i].login_status == 1){
			return 1;
			break;
		}
		
	}
	return 0;
}
//parse users list for the list command
int sort_list(){
	struct client temp;
	int temp_no;
    for (int i = 0; i < client_num; i++){
    	for (int j = i + 1; j < client_num; j++){
      		if(clients[i].port_no>clients[j].port_no){
       			temp = clients[i];
       			clients[i] = clients[j];
       			clients[j] = temp;
				clients[i].no = i+1;
				clients[j].no = j+1;
      		}
     	}
    }	
}

int search_client_by_ip(char ip[INET_ADDRSTRLEN]){
	int socket = 0;
	for(int i = 0; i< client_num; i++){
		
		if(strcmp(clients[i].ip_addr,ip) == 0){
			socket = clients[i].socket_id;
			return socket;
			break;
		}	
	}	
}
