#ifndef GLOBAL_H_
#define GLOBAL_H_
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <strings.h>
#include <unistd.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>

#define HOSTNAME_LEN 128
#define PATH_LEN 256

#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 512
#define BUFFER_SIZE 1024
#define MSG_SIZE 256

int create_server(int port) ;
int author(char *cmd);
int ip(char* ip_addr, char *cmd);
int get_port(int socket,char *cmd, int the_port);
char* get_ip(void);
int process_cmd_from_client(char *msg, int sock_index);
int check_if_block(char ip[INET_ADDRSTRLEN],char sender_ip[INET_ADDRSTRLEN]);
int add_to_clients(int fdaccept, struct sockaddr_in client_addr, int i, int client_port);
int send_login_list(int client_socket);

int send_login_list_refresh(int client_socket);
int check_if_login(char ip[INET_ADDRSTRLEN]);
int sort_list();
int search_client_by_ip(char ip[INET_ADDRSTRLEN]);
#endif
