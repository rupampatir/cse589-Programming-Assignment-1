#ifndef CLIENT_H_
#define CLIENT_H_
#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 512
#define BUFFER_SIZE 1024
#define MSG_SIZE 256

int create_client(int port) ;
int login(char *cmd, int client_socket);
int isValidAddr(char addr[INET_ADDRSTRLEN], char port[CMD_SIZE]);
int put_author(char *cmd);
int put_ip(char* ip_addr, char *cmd);
int put_port(int socket,char *cmd, int the_port);
char* get_ip_addr(void);
int process_res_from_server(char *cmd);

//struct client this_client;



#endif