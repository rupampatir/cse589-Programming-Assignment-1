#ifndef SERVER_H_
#define SERVER_H_

int create_server(int port) ;
int author(char *cmd);
int ip(char* ip_addr, char *cmd);
int port(int socket,char *cmd, int the_port);

#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 512
#define BUFFER_SIZE 1024
#define MSG_SIZE 256

#endif