#ifndef processCommands_H_
#define processCommands_H_

#define FILEPATH_LEN 256

extern char LOGFILE[FILEPATH_LEN];

extern int ret_print, ret_log;

int processCommands (char *cmd,char* port); 
int IPS(char* port);  
void author(); 
int validIP (char *ip, char *cmd);


#endif
