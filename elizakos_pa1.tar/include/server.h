#ifndef SERVER_H_
#define SERVER_H_


int server(int argc, char **argv);
int connect_to_host(char *server_ip, char* server_port);

#endif

