#ifndef ClienttoServerCommands_H_
#define ClienttoServerCommands_H_

//return 3 if it handles filling a new clientstat structure. 
//return 0 otherwise. 
int processHNandPort(char *buffer, struct Stats * clientStat);

//fill in a client structure given a string. 
//return 3 if it fills a clientStructure
//return 0 otherwise.
int processListStructure(struct clientStruct *currClient, char *clientString);


//process commands sent by the client to the server.
int processServertoClientCommands(struct clientStruct *currClient,char *buffer, char* nbuffer);
#endif