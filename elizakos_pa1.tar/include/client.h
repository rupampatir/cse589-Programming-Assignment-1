#ifndef SERVER_H_
#define SERVER_H_

int client(int argc, char **argv);
int connect_to_host(char *server_ip, char* server_port);
void loggedOut(char* port); 
#endif
