#ifndef NEWCLIENTT_H_
#define NEWCLIENTT_H_

void newClientt(int argc, char **argv);

#endif