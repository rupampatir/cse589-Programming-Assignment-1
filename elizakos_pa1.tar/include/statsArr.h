#ifndef STATSARR_H_
#define STATSARR_H_


//struct for keeping the stats of the clients connected to server
struct Stats{
    int index;
    char* IP; 
    int port;
    int sd; //socket descriptor -> this is just shorter and I like it better. 
    int messReciv;
    int messSent;
    int status; //0 or 1
    char* hostName; 
    struct addrInfo *blocked; 
    //add something to store the blocked ips like an array of blocked ips?
};

struct clientStruct {
    int index; 
    char* hostname; 
    char* ip; 
    int port; 

};

//gets client from sd
struct Stats * getClient(int sd, struct Stats *arr);

//remove client from the array after the exit command
void removeClient (int sd, struct Stats *arr);

//gets sd from ip from arr
int getSD (char *ip, struct Stats *arr);

//sorts stats struct
void sortStatsStruct(struct Stats *arr);

//sorts client struct
void sortClientStruct(struct clientStruct *arr);

//prints list
void printList (struct Stats *arr);

//prints stast
void printStats (struct Stats *arr);






#endif









 