#ifndef PROCESSCLIENTCOMMANDS_H_
#define PROCESSCLIENTCOMMANDS_H_

int processClientCommands (char *cmd, struct Stats *client, struct Stats *arr, int sd);
int login(char *buffer, int *loggedIn);
int connect_to_host(char *server_ip, char* server_port);


#endif
