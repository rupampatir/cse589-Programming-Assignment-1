//here, we realized that we needed to use select() inorder to handle both receiving and sending in an unpredictable manner.
//so we established a new function called newClient() which would replace the old client() function. 
//I used the server sample code and the client sample code fot his.


#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#include <strings.h> 
#include <strings.h> 
#include <arpa/inet.h> 
#include<sys/types.h> 
#include<netdb.h> 


#include "../include/statsArr.h"
#include "../include/newClientt.h"
#include "../include/processCommands.h"
#include "../include/processClientCommands.h"


#define BACKLOG 5 
#define STDIN 0 
#define TRUE 1 
#define CMD_SIZE 100 
#define BUFFER_SIZE 256 

void newClientt(int argc, char **argv) { 
    struct clientStruct *loggedInClients = (struct clientStruct *) calloc(5,sizeof(struct clientStruct)); 
    for (int x = 0; x < 5; x++) { 
        (loggedInClients+x)->index = -1; 
    } 
    char *port = argv[2]; 
    int result, server_socket_descriptor, client_socket, head_socket, sock_index, fdaccept = 0, caddr_len,selret;
    struct sockaddr_in sock_addr; 
    struct addrinfo hints, *res;
    fd_set master_list, watch_list; 

    

    memset(&hints, 0, sizeof(hints)); 
        hints.ai_family = AF_INET; 
        hints.ai_socktype = SOCK_STREAM; 
        hints.ai_flags = AI_PASSIVE; 
    int loggedIn = 0; 
    int connected = 0; 

    
    if (getaddrinfo(NULL, port, &hints, &res) != 0) {perror("getaddrinfo failed"); }

    client_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol); 
    if (client_socket < 0) { 
        perror("Cannot create socket"); 
    }
    if (bind(client_socket, res->ai_addr, res->ai_addrlen) < 0) { 
        perror("bind failed"); 
    } freeaddrinfo(res); 

    if (listen(client_socket, BACKLOG) < 0) { 
        perror("Unable to listen on port"); 
    }
    FD_ZERO(&master_list);
    FD_ZERO(&watch_list); 

    FD_SET(client_socket, &master_list); 
    FD_SET(STDIN, &master_list); 

    head_socket = client_socket; 
   // printf("\nThe head socket is:%d\n",head_socket);
    char *c = port + strlen(port); 
    *c = '\0';
   // printf("\nportis: %st\n",port);
    //fflush(stdout);

    while(TRUE) {
        result = -10;
        memcpy(&watch_list, &master_list, sizeof(master_list));
        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL); 
    
        if (selret<0) { 
            perror("select failed."); 
        } 
       
        if (selret > 0) { 
            for (sock_index = 0; sock_index<=head_socket; sock_index+=1) {
    
                if(FD_ISSET(sock_index, &watch_list)) { 
                  
                    if (sock_index == STDIN) {
                      
                        char *cmd = (char*) malloc(sizeof(char) *CMD_SIZE);
                        memset(cmd,'\0',CMD_SIZE); 

                        char *cmdCopy = (char*)malloc(sizeof(char)*CMD_SIZE); 
                        memset(cmdCopy,'\0',CMD_SIZE);

                        char *ncmdCopy = (char*) malloc(sizeof(char) *CMD_SIZE);
                        memset(ncmdCopy,'\0',CMD_SIZE); 

                        if (fgets(cmd,CMD_SIZE-1,stdin) == NULL) { 
                            exit(-1); 
                        }
                        strcpy(cmdCopy,cmd);
                        strcpy(ncmdCopy,cmd);
                      //  printf("the current cmdcopy string is: %s\n",cmdCopy);
                       // fflush(stdout);



                        if (processCommands(cmd,port) != 1) { //process loggedIn commands first. 
                            char *loginstr = strtok(cmd," ");

                            if (loggedIn == 0 && connected == 0) { //process login 
                                if (strcmp(loginstr, "LOGIN") == 0) { 
                                    server_socket_descriptor = login(loginstr,&loggedIn);
                                    char *finalStringg = (char*)malloc(100 * sizeof(char*)); 
                                    makeString(finalStringg, port);
                                    if (send(server_socket_descriptor, finalStringg, strlen(finalStringg),0) != strlen(finalStringg)){ 
                                     //   printf("failed to send port \n");
                                    } else { 
                                        free(finalStringg);
                                       // printf("\nfinalString%sfinalString\n",finalStringg);
                                       // fflush(stdout); 
                                        connected = 1; 
                                        FD_SET(server_socket_descriptor, &master_list); 
                                        if(server_socket_descriptor > head_socket) {
                                            head_socket = server_socket_descriptor;  
                                        } 
                                        loggedIn = 1; 
                                        cse4589_print_and_log("[%s:SUCCESS]\n", loginstr);
                                        cse4589_print_and_log("[%s:END]\n", loginstr);
                                       // printf("loggedInSuccessful");
                                       // fflush(stdout);
                                    }

                                }  else { 
                                   // printf("return the exception that the client is not logged in.");
                                }
                            } else { //process all other commands. 
                                char *cmd = strtok(cmdCopy, " ");
                               // printf("test"); 
                               // fflush(stdout);
                                //result = loggedInClientCommands()
                                    //for now just handling exit seperatly.
                                // if (strcmp(cmdCopy,"LOGOUT\n") == 0) { 
                                //     printf("wtf");
                                //     fflush(stdout);
                                // }
                                if (strcmp(cmdCopy, "EXIT\n")==0){
                                    exit(0);
                                    if (send(server_socket_descriptor, cmdCopy, strlen(cmdCopy),0) != strlen(cmdCopy)){ printf("failed to send port \n");}
                                }  else if (strcmp(cmdCopy,"LIST\n") == 0) { 
                                    if (loggedIn == 1) {
                                        sortClientStruct(loggedInClients);
                                        printListC(loggedInClients);
                                        
                                    } else {
                                        //printf("not loggedIn");
                                        //return error.
                                    }
                                } else if ((strcmp(cmdCopy, "LOGIN") == 0))  { 
                                   // printf("login\n");
                                   // fflush(stdout);
                                    char *cmd = strtok(NULL, " "); 
                                    char *nip = (char *)malloc(sizeof(char)*35); 
                                    strcpy(nip, cmd); 
                                   // printf("%s",nip);
                                   // fflush(stdout);
                                    if (validIP(nip, cmdCopy)==1) {
                                     //   printf("valid ip");
                                       // fflush(stdout);
                                        loggedIn = 1; 
                                        cse4589_print_and_log("[%s:SUCCESS]\n", cmdCopy);
                                        cse4589_print_and_log("[%s:END]\n", cmdCopy);
                                        if (send(server_socket_descriptor, cmdCopy, strlen(cmdCopy),0) != strlen(cmdCopy)){ printf("failed to send port \n");}
                                    }
                                }  else if (strcmp(cmdCopy, "SEND") == 0) {
                                    char *cmd = strtok(NULL, " "); 
                                    char *nip = (char *)malloc(sizeof(char)*35); 
                                    strcpy(nip, cmd); 
                                   // printf("%s",nip);
                                   // fflush(stdout);
                                    if (validIP(nip, cmdCopy)==1) {
                                     //   printf("valid ip");
                                       // fflush(stdout);
                                       
                                        if (send(server_socket_descriptor, ncmdCopy, strlen(ncmdCopy),0) != strlen(ncmdCopy)){
                                            char * send = "SEND";
                                            cse4589_print_and_log("[%s:ERROR]\n", send);
                                            //printf("failed to send port \n");
                                            cse4589_print_and_log("[%s:END]\n", send);
                                        } else { 
                                            char * send = "SEND";
                                            cse4589_print_and_log("[%s:SUCCESS]\n", send);
                                            //printf("failed to send port \n");
                                            cse4589_print_and_log("[%s:END]\n", send);
                                        }
                                    } else { 
                                        char * send = "SEND";
                                        cse4589_print_and_log("[%s:ERROR]\n", send);
                                        //printf("failed to send port \n");
                                        cse4589_print_and_log("[%s:END]\n", send);
                                    }

                                    
                                }  else if (strcmp(cmdCopy, "BROADCAST")== 0) { 
                                    //printf("ncmd%s",ncmdCopy);
                                    //fflush(stdout);
                                    if (send(server_socket_descriptor, ncmdCopy, strlen(ncmdCopy),0) != strlen(ncmdCopy)){
                                            char * send = "BROADCAST";
                                
                                            cse4589_print_and_log("[%s:ERROR]\n", send);
                                            //printf("failed to send port \n");
                                            cse4589_print_and_log("[%s:END]\n", send);
                                        } else { 
                                            char * send = "BROADCAST";
                                            cse4589_print_and_log("[%s:SUCCESS]\n", send);
                                            cse4589_print_and_log("[%s:END]\n", send);
                                        }
                                        
                                     }
                                     // else { 
                                    //     char * send = "BROADCAST";
                                    //     cse4589_print_and_log("[%s:ERROR]\n", send);
                                    //     printf("failed to send port \n");
                                    //     cse4589_print_and_log("[%s:END]\n", send);
                                    // }


                                    
                                else if (strcmp(cmdCopy, "LOGOUT\n") == 0) { 
                                   // printf("Test");
                                   // fflush(stdout);
                                    loggedIn = 0;
                                    cse4589_print_and_log("[%s:SUCCESS]\n", "LOGOUT");
                                    cse4589_print_and_log("[%s:END]\n", "LOGOUT");

                                    if (send(server_socket_descriptor, cmdCopy, strlen(cmdCopy),0) != strlen(cmdCopy)){ printf("failed to send port while logout\n");} 
                                }else if(strcmp(cmdCopy, "REFRESH\n")==0){

                                    for (int i = 0; i < 5; i++){
                                        if ((loggedInClients+i)->index != -1){
                                            free((loggedInClients+i)->ip);
                                            free((loggedInClients+i)->hostname);

                                        }
                                        (loggedInClients+i)->index = -1;
                                        (loggedInClients+i)->port = 0;
                                        //printf("logged in client index: %d\n", (loggedInClients+i)->index);
                                        //fflush(stdout);
                                    }
                                    if (send(server_socket_descriptor, cmdCopy, strlen(cmdCopy),0) != strlen(cmdCopy)){ printf("failed to send port while refresh\n");}


                                } else { 
                                    //printf("why"); 
                                    //fflush(stdout);
                                }
                                 
                            }
                        } 
                        free(cmd); 
                        free(cmdCopy);
                        free(ncmdCopy);
                    } else if (sock_index == server_socket_descriptor) { 
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE); //allocate the buffer size. 
                        memset(buffer,'\0',BUFFER_SIZE);
                        
                        if(recv(sock_index,buffer, BUFFER_SIZE, 0) <= 0) { 
                            close(sock_index); 
                           // printf("Remote Host terminated connection!\n"); 

                            //remove it from the master list because it is no longer communicating.
                            FD_CLR(sock_index,&master_list); 

                        } else { 
                            //printf("\nbuffer: %s\n", buffer);
                            char *bufferCopy2 = (char*) malloc(sizeof(char)*BUFFER_SIZE);
                            memset(bufferCopy2,'\0',BUFFER_SIZE);
                            strcpy(bufferCopy2, buffer);

                            char *s;
                            char *each = strtok_r(bufferCopy2,"-", &s);
                            
                            char *s2;
                            
                            while ((each != NULL)){
                                
                                //printf("\neach: %s\n", each);

                                if (strcmp(each, "refreshsuccess") == 0){
                                    cse4589_print_and_log("[%s:SUCCESS]\n", "REFRESH");
                                    cse4589_print_and_log("[%s:END]\n", "REFRESH");
                                    each = strtok_r(NULL,"-", &s);

                                }else{

                                char *bufferCopy = (char*) malloc(sizeof(char)*BUFFER_SIZE); //allocate the buffer size. 
                                // printf("the clientinfo string is:%s",buffer);
                                memset(bufferCopy,'\0',BUFFER_SIZE);

                                strcpy(bufferCopy, each);

                                char *bufferCopyn = strtok_r(bufferCopy," ",&s2);
                                //printf("\nBUFFERCOPYN: %s\n", bufferCopyn);
                                //fflush(stdout);
                                result = processServertoClientCommands(loggedInClients,bufferCopyn, each);   

                                free(bufferCopy);
                                
                                //printf("\neach: %s\n", each);
                                each = strtok_r(NULL,"-", &s);
                                //printf("\neach: %s\n", each);
                                //fflush(stdout);

                                }

                            }
            
                            free(bufferCopy2);
                            free(buffer);     
                        } 
                        
                        
        

                    }

                }

            }

        }
    }



}

 
