#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <strings.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <netdb.h> 

#include "../include/server.h"
#include "../include/client.h"
#include "../include/statsArr.h"
#include "../include/newClientt.h"
#include "../include/global.h"
#include "../include/logger.h"

//get client from socket descriptor
struct Stats * getClient(int sd, struct Stats *arr){
    for (int i = 0; i < 5; i++){
        //printf("\nfor print%d\n", (arr+i)->sd);
        //fflush(stdout);
        if ((arr+i)->sd == sd){
            return (arr + i);
        }
    }
}

//remove client from socket descriptor
void removeClient (int sd, struct Stats *arr){
    for (int i = 0; i < 5; i++){
        if ((arr+i)->sd == sd){
           (arr+i)->sd = -1;
           free((arr+i)->IP);
           free((arr+i)->hostName);
           //return 0;
        }
    }
    //return 1;
}

//getting sd from ip address in statsArrC 
//returns the sd, if not found returns -1
int getSD (char *ip, struct Stats *arr){
    
    for (int i = 0; i < 5; i++){
        if ((arr+i)->sd != -1){
            //printf("\nip1:%sy\n",(arr+i)->IP);
            //printf("\n%sy\n",ip);
            fflush(stdout);
            if (strcmp((arr+i)->IP, ip) == 0){
    
                //printf("\n\n\nfound\n\n\n"); 
                //fflush(stdout);
                return (arr+i)->sd;
            }
        }
    }
    return -1;
}


//sorts StastStructArr, sets index to # order
void sortStatsStruct(struct Stats *arr){
    //printf("sort entered\n");
    //fflush(stdout);
    for (int i = 0; i < 5; i++){
        (arr+i)->index = -1;
    }
    int cnt = 0;
    for (int i = 0; i < 5; i++){
        int smallPort = 10000;
        int didit = 0;
        for (int j = 0; j < 5; j++){  
            if ((arr+j)->sd != -1){
                if ((arr+j)->index == -1 && (arr+j)->port != 0){
                    if ((arr+j)->port <= smallPort){
                        smallPort = (arr+j)->port;
                        //printf("small port: %d", smallPort);
                        //fflush(stdout);
                        cnt = j;
                        //printf("poss: %d", j);
                        //fflush(stdout);
                        didit = 1;
                    }
                }
            }
        }
        if (didit == 1){
            //printf("i + 1: %d\n", i+1);
            //fflush(stdout);
            (arr+cnt)->index = i+1;
        }
        
        
    }
    

}

//sorts clientStruct, sets index to # order
void sortClientStruct(struct clientStruct *arr){
    for (int i = 0; i < 5; i++){
        (arr+i)->index = -1;
    }
    int cnt = 0;
    for (int i = 0; i < 5; i++){
        int smallPort = 10000;
        int didit = 0;
        for (int j = 0; j < 5; j++){
            if ((arr+j)->index == -1 && (arr+j)->port != 0){
                if ((arr+j)->port <= smallPort){
                    smallPort = (arr+j)->port;
                    cnt = j;
                    didit = 1;
                }
            }
        }
        if (didit == 1){
            (arr+cnt)->index = i+1;
        }   
    }
}

//prints list from server side
void printList (struct Stats *arr){
    int cnt = 1;
    int cntprint = 1;
    while (cnt <= 5){
        for (int i = 0; i < 5; i++){
            if ( ((arr+i)->status != 0) && ((arr+i)->index == cnt)){
                cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", 
                    cntprint,
                    (arr+i)->hostName, 
                    (arr+i)->IP, 
                    (arr+i)->port); 
                cntprint++;
    
            }
        }
        cnt++;
    }
}

void printStats (struct Stats *arr){
    //printf("print entered\n");
    //fflush(stdout);
    int cnt = 1;
    while (cnt <= 5){
        for (int i = 0; i < 5; i++){
            if ( (arr+i)->index == cnt){
                if ((arr+i)->sd != -1){
                char *sta;
                if ((arr+i)->status == 1){
                    sta = "logged-in";
                }
                else{
                    sta = "logged-out";
                }
                cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", 
                    (arr+i)->index,
                    (arr+i)->hostName, 
                    (arr+i)->messSent, 
                    (arr+i)->messReciv,
                    sta);
 
                }
            }
        }
        cnt++;
    }
}


