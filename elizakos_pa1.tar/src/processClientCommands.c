
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <strings.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <netdb.h> 

#include <errno.h>

//printing unit32 https://stackoverflow.com/questions/12120426/how-do-i-print-uint32-t-and-uint16-t-variables-value
#include <inttypes.h>

#include "../include/global.h"
#include "../include/processCommands.h"
#include "../include/logger.h"
#include "../include/server.h"
#include "../include/statsArr.h"

//file to handle client commands, working on getting loggout and exit to work
//returns 3 for EXIT, 4 for SEND
int processClientCommands (char *cmd, struct Stats *client, struct Stats *arr, int sd){
    //read from buffer and call other fuctions to execute respective functions
    //printf("command is%st",cmd);
    if (strcmp(cmd, "LOGOUT\n") == 0) { 
        client->status = 0; //client logged out
        return 0; 
    }
    if (strcmp(cmd, "EXIT\n") == 0) { 
        client->status = 0; //client logged out
        removeClient(sd, arr);
   
        int extcode = close(sd);
        return 3; 
    }
    //char *cpcmd = 
    if (strcmp(cmd,"SEND")==0 ){

        return 4;
    }
    if (strcmp(cmd,"BROADCAST") == 0) { 
        return 11; 
    }
    if (strcmp(cmd,"LIST\n") == 0) { 
        return 3; 
    } 
    if (strcmp(cmd,"REFRESH\n") == 0) { 
        //printf("Refresh called on server");
        //fflush(stdout);
        return 7; 
    } 
    if (strcmp(cmd,"LOGIN") == 0) { 
        return 9; 
    }
    else { return 1;}

}


int login(char *buffer, int *loggedIn) { 
    char *nbuffer = (char *)malloc(sizeof(char) * 75);
    memset(nbuffer,'\0',75);
    //printf("here\n");
    //fflush(stdout);
    strcpy(nbuffer,buffer);
    char *loginstr = strtok(NULL," "); 
    char *ipaddress = loginstr;

    //printf("%s\n",loginstr);
    //fflush(stdout);
    if (validIP(ipaddress, nbuffer) == 0) {
        //cse4589_print_and_log("[%s:ERROR]\n",nbuffer);
        //cse4589_print_and_log("[%s:END]\n",nbuffer);
        return 0;
    } 
    free(nbuffer);
    loginstr = strtok(NULL, " "); 
    char *portt = loginstr; 
    int s; 
    char *c = portt + (strlen(portt)-1); 
    *c = '\0';

    s = connect_to_host(ipaddress,portt);
    //printf("%d",s);
    //fflush(stdout);
    if ( s == 0) { 
        //printf("failed to connect to host."); 
        //fflush(stdout);
        return 0; 
    } 
    return s;  
}

void makeString(char *finalStringg, char *port) { 
    char finalString[100]; 
    strcpy(&finalString,"NEWPORT: ");
    strcat(finalString,port); 
    char hostString[50]; 
    char hostname[50];
    gethostname(&hostname,50); 
    strcpy(hostString," HOSTNAME: "); 
    strcat(&hostString,&hostname); 
    strcat(&finalString,&hostString); 
    strcpy(finalStringg,finalString);
   
}

int connect_to_host(char *server_ip, char* server_port) { 
    //here

    //printf("\n serverIP: %s, port: %stttttt",server_ip, server_port);
    //fflush(stdout);
    int fdsocket; 
    struct addrinfo hints, *res; 

    memset(&hints, 0, sizeof(hints)); 
        hints.ai_family = AF_INET; 
        hints.ai_socktype = SOCK_STREAM; 
        //ai is not set to passive because this is getting the address from the server 
        //and establisthing a connection/attempting to establish a connection to the server. 
   // printf("step1"); 
    if (getaddrinfo(server_ip, server_port, &hints, &res) != 0) { 
        perror("getaddrinfo failed"); 
    }
   // printf("step2"); 
   // fflush(stdout); 
    fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol); 
    if(fdsocket <0) { 
        //printf("socket could not be created");
        perror("failed to create socket"); 
        //fflush(stdout);
    }
   // printf("step3");
   // fflush(stdout); 
    if (connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0) { 
        perror("connect failed"); 
    }
    //printf("step4");
    //fflush(stdout); 
    freeaddrinfo(res); 
    //printf("step5");
    //fflush(stdout); 
    //printf("\nfdsocket%dfdsocket:\n",fdsocket);
    //fflush(stdout);
    return fdsocket; 
    
}