//copying in the server.c api from the sample code off of piazza for now. 


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netdb.h>

#include "../include/server.h"
#include "../include/client.h"
#include "../include/statsArr.h"
#include "../include/ClienttoServerCommands.h"

#include "../include/processClientCommands.h"

#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 100
#define BUFFER_SIZE 400


//I will be routing to server or client depending on input from assigment.c

int server(int argc, char **argv) {
    char *cliString;
    int numClients = 0;
    struct Stats *statsArrC;
    statsArrC = (struct Stats* ) calloc(5,sizeof(struct Stats));


    for (int x = 0; x < 5; x++) {
        (statsArrC+x)->sd = -1;
        (statsArrC+x)->status = 0;
        (statsArrC+x)->IP = (char *)malloc(sizeof(char) * INET_ADDRSTRLEN);
        memset((statsArrC+x)->IP, '\0',sizeof(char) * INET_ADDRSTRLEN);
        (statsArrC+x)->messReciv = 0;
        (statsArrC+x)->messSent = 0;
    }
    // printf("statsArr has been initlized");
    // fflush(stdout);
    //error check the args in routing.

    int server_socket, head_socket, selret, sock_index, fdaccept= 0, caddr_len;
    struct sockaddr_in client_addr;
    struct addrinfo hints, *res;
    fd_set master_list, watch_list;

    //setting hints to 0 first because of flags for my own IP.
    memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_PASSIVE;

    //here, NULL because ai_flags is passive.
    //argv[1] is the port number.
    //&res will be a linked list of the possible IP addresses

    struct Stats* sendToClient;
    struct stats *receiveFromClient;
    int sendToSd;


    if (getaddrinfo(NULL, argv[2],&hints, &res) != 0){
        perror("getadrrinfo failed");
    }

    //may want to cycle through res like from the BEEJs networking programming guide.
    server_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    //not sure why the sample code does the formatting for error checking differently from getaddrinfo.
    if(server_socket < 0) {
        perror("Cannot create socket");
    }
    if (bind(server_socket, res->ai_addr, res->ai_addrlen) < 0) {
        perror("bind failed"); //still bothered by the inconsistency of formatting
    }
    freeaddrinfo(res);

    if(listen(server_socket,BACKLOG) < 0) {
        perror("Unable to listen on port");
    }

    FD_ZERO(&master_list);
    FD_ZERO(&watch_list);
    //from beej's programming guide, the master_list is like a set and the watch list is pulling out of that set based on the result of select().
    //it is necessary to preserve the master_list.

    FD_SET(server_socket, &master_list);

    FD_SET(STDIN, &master_list);

    int result;
    char *sendToIp;
    head_socket = server_socket;

    while(TRUE) {
        //start with the original pool of connections before calling select.
        //select will modify the watchlist according to which connection has been made.
        memcpy(&watch_list, &master_list, sizeof(master_list));

        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
        if (selret<0) {
            perror("select failed.");
        }
        //select() returns the number of file descriptors contained in the 3
        //returned file descriptor sets.
        //if it's 0, then the connection timed out.
        //if it's -1 then the file descriptor sets are unmodified
        //(man page for select())
        if (selret > 0) { //then there are connections.
            for (sock_index = 0; sock_index<=head_socket; sock_index+=1) {
                //if the current sd is inside of the watch_list then:
                if(FD_ISSET(sock_index, &watch_list)) {
                    //checking the commands on STDIN.
                    //that means that the command is from the server side.
                    if(sock_index == STDIN) {
                        char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
                        //so here, set a pointer to the first char in the command.
                        //now, multiply the size of char by the command size (allocate the total command size
                        memset(cmd, '\0', CMD_SIZE);
                        if(fgets(cmd, CMD_SIZE-1,stdin) == NULL) {  //"mind the newline character that will be written to cmd." {
                            exit(-1);
                        }
                        int pc = processCommands(cmd,argv[2]);
                        if (pc == 0){
                            //printf("processCommands was 0\n");
                            if (strcmp(cmd,"STATISTICS\n") == 0) { 
                                //printf("calling sort\n");
                                sortStatsStruct (statsArrC);
                                //printf("calling print\n");
                                cse4589_print_and_log("[%s:SUCCESS]\n", "STATISTICS");
                                printStats(statsArrC);
                                cse4589_print_and_log("[%s:END]\n", "STATISTICS");
                                //fflush(stdout);
                            }
                            if (strcmp(cmd,"LIST\n") == 0) { 
                                //printf("calling sort\n");
                                sortStatsStruct (statsArrC);
                                //printf("calling print\n");
                                cse4589_print_and_log("[%s:SUCCESS]\n", "LIST");
                                printList(statsArrC);
                                cse4589_print_and_log("[%s:END]\n", "LIST");
                                //fflush(stdout);
                            }
                        }
                        //free the space from the heap after alloting it.
                        free(cmd);

                    } //do not forget to make sure the brackets are all in order if a bug occurs.
                    //if the sock_index = server_socket then that means that there is a new connection attempting to be established with the server.
                    //so that means that a new connection is attempting to be had.
                    //
                    else if (sock_index == server_socket) {
                        //note that server_socket is listening to new connections.
                        //accept will open up a new socket for the client attempting to connect.
                        //through this new, seperate connection send/recvs can occur.
                        //this new socket must also be added to the master_list.
                        caddr_len = sizeof(client_addr);

                        //fdaccept will be the new sd for the new client connection.
                        //here, client_addr is the address that will be filled with information relating to the
                        //incoming connection / peer side.
                        //after accept, the client_addr will store the addrinfo of client
                        fdaccept = accept(server_socket, (struct sockaddr *)&client_addr, &caddr_len);  
                        if (fdaccept < 0) { 
                            perror("ACCEPT failed."); 
                        } 
                        
                        //get the ip and allocate memory for it in the respective client's stats structure. 
                        char ip4[INET_ADDRSTRLEN]; 
                        inet_ntop(AF_INET, &client_addr.sin_addr, ip4, INET_ADDRSTRLEN);  
                      //  (statsArrC+numClients)->IP = (char *)malloc(sizeof(char) * INET_ADDRSTRLEN); 
                        //copy the IP into the string. 
                        strcpy((statsArrC+numClients)->IP, ip4); 
                         
               
                        FD_SET(fdaccept, &master_list); 
                        if(fdaccept > head_socket) { 
                            head_socket = fdaccept; 
                        } //beejs: fdmax requirement, fdmax + 1. 
                        (statsArrC+numClients)->sd = fdaccept; 
                        (statsArrC+numClients)->status = 1; 
                        
                        //printf("\nnumclients%d\n",numClients);
                        //printf("\n%d\n socketDescriptor",(statsArrC+numClients)->sd);
                        fflush(stdout);
                        numClients += 1;


                    } else {
                        //the final case is not sdin or the server listener socket.
                        //then it is an existing socket descriptor sending to the server.
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE); //allocate the buffer size.
                        memset(buffer,'\0',BUFFER_SIZE);

                        if(recv(sock_index,buffer, BUFFER_SIZE, 0) <= 0) {
                            close(sock_index);
                            //printf("Remote Host terminated connection!\n");

                            //remove it from the master list because it is no longer communicating.
                            FD_CLR(sock_index,&master_list);

                        } else { 
                            //process incoming data from existing clients here. 
                            
                            struct Stats *test = getClient(sock_index, statsArrC); 
                            char *tempBuffer = (char*) malloc(sizeof(char)*BUFFER_SIZE); //allocate the buffer size. 
                            memset(tempBuffer,'\0',BUFFER_SIZE); 
                            strcpy(tempBuffer,buffer); 
                            tempBuffer = strtok(tempBuffer," ");
                            result = processClientCommands(tempBuffer,test,statsArrC,sock_index);
                            //printf("sockeind: %d", sock_index);
                            //fflush(stdout);
                            // 3 is exit.
                            if (result == 3){
                                FD_CLR(sock_index,&master_list);
                            }
                            if (result == 9) { 
                               // printf("=9");
                               // fflush(stdout);
                                test->status = 1; 
                            }
                            //4 is send.
                            else if (result == 4){
                                //I made process send inorder to avoid the strtok issues. 
                                char *processSend = (char*) malloc(sizeof(char)*BUFFER_SIZE); 
                                memset(processSend,'\0',BUFFER_SIZE); 
                                strcpy(processSend,buffer);

                                char *newSendString = strtok(processSend," ");
                                newSendString = strtok(NULL," "); //round 1. newSendString = IP. 

                                char *sendToIp = (char*)malloc(35 * sizeof(char));
                                memset(sendToIp,'\0',32);
                                strcpy(sendToIp,newSendString); //copy the ip into sendto ip. 

                                sendToSd = getSD(sendToIp,statsArrC); //get the sd for the corrosponding ip. 
                              
                                newSendString = strtok(NULL," ");
                              
                                char *c = newSendString + (strlen(newSendString)-1); 
                                *c = '\0';
                                char* finalSendString[BUFFER_SIZE];
                                //receiveFromClient = getClient(sock_index,statsArrC);

                                memset(finalSendString,'\0',BUFFER_SIZE);
                                char *sendcommand = "FROM ";
                                strcpy(&finalSendString,sendcommand);

                                strcat(&finalSendString,test->IP);
                                
                                char * t = " "; 
                                strcat(&finalSendString, t);
                                strcat(&finalSendString,newSendString);
                               
                                //implement blocking logic here
                                char *relayed = "RELAYED";
                                if (send(sendToSd,finalSendString,strlen(finalSendString),0) == strlen(finalSendString)) {
                                   // ("msg from:%s\n[msg]:%s\n", client-ip, msg)
                                  
                                    cse4589_print_and_log("[%s:SUCCESS]\n", relayed);
                                    cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",test->IP, sendToIp, newSendString);
                                    
                                    cse4589_print_and_log("[%s:END]\n", relayed);
                                    sendToClient = getClient(sendToSd,statsArrC);
                                    sendToClient->messReciv += 1;
                                    test->messSent += 1;
                                } else { 
                                    cse4589_print_and_log("[%s:ERROR]\n", relayed);
                                    cse4589_print_and_log("[%s:END]\n", relayed);
                                }
                                free(processSend);
                                 free(sendToIp);
                                //free(finalSendString);
                            } else if (result == 11) { 
                                //printf("testing result broadcast!");
                                char *processSend = (char*) malloc(sizeof(char)*BUFFER_SIZE); //string to break
                                memset(processSend,'\0',BUFFER_SIZE); 
                                strcpy(processSend,buffer);

                                char *newBroadcastString = strtok(processSend," "); //should = broadcast
                                char *newSendString = strtok(NULL," ");//then newSendString = the message

                                char *sendMessage[BUFFER_SIZE];
                                memset(sendMessage,'\0',BUFFER_SIZE); //the message = sendMessage

                                char * sendToIp = "255.255.255.255"; 
                                char *from = "FROM ";
                                strcat(&sendMessage,from);
                                strcat(&sendMessage,test->IP); 
                                char *space = " ";
                                strcat(&sendMessage,space);
                                strcat(&sendMessage,newSendString);
                                //printf("%s",sendMessage); 
                                //fflush(stdout);

                                for (int x = 0; x < 5; x++) { 
                                    if ((statsArrC+x)->status != 0) {  //storing unloggedin commands here.. 
                                        if ((statsArrC+x)->sd != sock_index) { 
                                            (statsArrC+x)->messReciv++;
                                            if (send((statsArrC+x)->sd,sendMessage,sizeof(sendMessage),0) != strlen(sendMessage)) { 
                                                //printf("failure");
                                            } 
                                        }
                                        if ((statsArrC+x)->sd == sock_index) {
                                            (statsArrC+x)->messSent++;
                                        }
                                    } //else if (statsArrC+x)->sd != -1... 
                                }



                            }
                            else if ( (result == 7)  || (processHNandPort(buffer, test) == 0)) { 
                                for (int x = 0; x < 5; x++) { 
                                    if (result == 7){
                                        //printf("refresh sending statsarr\n");
                                        //fflush(stdout);
                                    }
                                    if (((statsArrC+x)->sd != -1) && ((statsArrC+x)->status != 0)) { 
                                        cliString = (char *)malloc(sizeof(char) * BUFFER_SIZE); 
                                        sprintf(cliString,"ClientInfo %d %s %s %d-", x, (statsArrC+x)->hostName, (statsArrC+x)->IP, (statsArrC+x)->port);
                                        // printf("\nbuffer befere sending to client: %s\n", cliString);
                                        // fflush(stdout);
                                        //printf("fdaccept: %d\n", fdaccept);
                                        //fflush(stdout);
                                        if(send(sock_index,cliString,strlen(cliString),0) != strlen(cliString) ) { 
                                            if (result == 7){
                                                cse4589_print_and_log("[%s:ERROR]\n", "REFRESH");
                                                cse4589_print_and_log("[%s:END]\n", "REFRESH");
                                            }
                                            // printf("\nsending\n");
                                            // fflush(stdout);
                                            //send(fdaccept,"",strlen(""),0);
                                        } free(cliString);   
                                    }

                                }
                                if (result == 7){
                                    //printf("sent refresh successs\n");
                                    //fflush(stdout);
                                    send(sock_index, "refreshsuccess-", strlen("refreshsuccess-"),0);
                                }
                            }; free(tempBuffer);

                        } free(buffer);
                       

                    }
                }
            }

        }

    } free (statsArrC);

}
