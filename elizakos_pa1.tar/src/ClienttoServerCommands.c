#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <strings.h>
#include <strings.h>
#include <arpa/inet.h>
#include<sys/types.h>
#include<netdb.h>
#include "../include/statsArr.h"
#include "../include/server.h"
#include "../include/client.h"
#include "../include/ClienttoServerCommands.h"

#define BUFFER_SIZE 256 



//take a buffer and pointer to the client stats structure to modify and return 0 if it is successfully modified with port and host.
//otherwise return 1.
int processHNandPort(char *buffer, struct Stats *clientStat) {

    char *test = strtok(buffer, " ");

    if (strcmp(test,"NEWPORT:") == 0) {
        test = strtok(NULL, " ");
        char *port = test;
        clientStat->port = atoi(port);

        test = strtok(NULL, " ");

        if ((strcmp(test, "HOSTNAME:") == 0)) {
            test = strtok(NULL, " ");
            clientStat->hostName = (char *)malloc(50*sizeof(char)) ;
            strcpy(clientStat->hostName, test);
            return 0;
        }
    return 1;
    }   return 1;

}

//fill in a client structure given a string. 
//return the corrosponding index of the client that it filled. 

 
int processListStructure(struct clientStruct *currClient, char *clientString) {     
    char *test = strtok(clientString, " "); //ClientInfo
       // printf("\nclientString: %s\n",clientString);
       // fflush(stdout);
  //  if (strcmp(test,"ClientInfo") == 0) { 
        test = strtok(NULL, " "); //number
        int num =atoi(test);  
        //printf("\nnum in processListStruct: %d\n", num);
        //fflush(stdout);;  
        (currClient+num)->index = num+1; 
        //printf("\ncurrClient+num->index: %d\n",(currClient+num)->index);
        //fflush(stdout);

        (currClient+num)->hostname = (char* )malloc(50 * sizeof(char));
        test = strtok(NULL, " "); //hostname
        //printf("\nhostname: %s\n", test); 
        //fflush(stdout); 
        strcpy((currClient+num)->hostname, test);
       // printf("\nhostname%s\n\n",(currClient+num)->hostname);
       // fflush(stdout);;

        test = strtok(NULL, " "); //ip
        //printf("\nip: %s\n", test); 
        //fflush(stdout); 
        (currClient+num)->ip = (char*)malloc(50*sizeof(char)); 
        strcpy((currClient+num)->ip, test); 

        test = strtok(NULL, " "); //port
        //printf("\nport: %s\n", test); 
        //fflush(stdout); 
        (currClient+num)->port = atoi(test); 
        //printf("%d", (currClient+num)->index);
        //fflush(stdout);
        return currClient->index; 
    //} 
    //return 0; 
}

int processServertoClientCommands(struct clientStruct *currClient,char *buffer, char* nbuffer) { 
    //printf("the buffer for processServerToClientCommands is :%st",buffer);
    //fflush(stdout);
    if (strcmp(buffer,"ClientInfo") == 0) { 
       // printf("it equals clientInfo!");
        int num = processListStructure(currClient,nbuffer);
       // printf("\nhostname: %s\n",(currClient+num)->hostname); //printf("%d",(currClient+num-1)->port)
       // fflush(stdout); 
        return 0; 
    } else if (strcmp(buffer,"FROM")== 0) { //send as FROM <IP> <msg> ("msg from:%s\n[msg]:%s\n", client-ip, msg) 
        char *c = strtok(nbuffer," "); 
        char *ip[35]; 
        char *message[275];
        c = strtok(NULL, " "); 
        strcpy(ip,c);
        //printf("%s",c);
        c = strtok(NULL, " "); 
        strcpy(message,c);
        char *t = "RECEIVED";
        cse4589_print_and_log("[%s:SUCCESS]\n", t);
        cse4589_print_and_log("msg from:%s\n[msg]:%s\n", ip, message);
        cse4589_print_and_log("[%s:SUCCESS]\n", t);    
        return 2;
    } else { 
        //printf("buffer for processServertoClientCommands%sn",buffer);
    }
    return -1;
}
