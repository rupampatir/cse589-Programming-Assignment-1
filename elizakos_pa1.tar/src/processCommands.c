
#include <stdio.h> 
#include <stdlib.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <strings.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <netdb.h> 

#include <errno.h>

//printing unit32 https://stackoverflow.com/questions/12120426/how-do-i-print-uint32-t-and-uint16-t-variables-value
#include <inttypes.h>

#include "../include/global.h"
#include "../include/processCommands.h"
#include "../include/logger.h"
#include "../include/statsArr.h"

//make processCommands return an integer which says if IP, AUTHOR, or Port were there 
//if the command was not IP, Author, port return 0. 
//if it was IP, AUTHOR, PORT return 1 
//return 7 for refresh. 


//return 3 if the command is list.  

int processCommands (char *cmd,char* port) { //change the name of this to be servercommands. 

    // printf("testing");
    // printf("printing this command %s",cmd);

    //compare ip and cmd.
    char* ip = "IP\n";
    if (strcmp(cmd, ip) == 0) { 
        IPS(port) ;
        cse4589_print_and_log("[%s:END]\n", "IP");
        return 1; 
    }
    if (strcmp(cmd,"AUTHOR\n") == 0) { 
        cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
        author(); 
        cse4589_print_and_log("[%s:END]\n", "AUTHOR");
        return 1; 
    }
    if(strcmp(cmd,"PORT\n") == 0) { 
        cse4589_print_and_log("[%s:SUCCESS]\n", "PORT");
        cse4589_print_and_log("PORT:%d\n", atoi(port));
        cse4589_print_and_log("[%s:END]\n", "PORT");
        return 1; 
    } 
    return 0; 
} 


void printListC(struct clientStruct *currClient) {
    char *t = "LIST";
    cse4589_print_and_log("[%s:SUCCESS]\n", t);
    int cnt = 1;
    while (cnt <= 5){
        for (int x = 0; x < 5; x++) {
            if ((currClient+x)->index != -1 && (currClient+x)->index == cnt) {
                cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",
                (currClient+x)->index, 
                (currClient+x)->hostname, 
                (currClient+x)->ip, 
                (currClient+x)->port);
            }
        }
        cnt++;
    }
    cse4589_print_and_log("[%s:END]\n", t);
}
//return 1 = exit, logout, refresh 
//return 2 = SEND, BROADCAST 
//return 3 = 
 
//return -1 on error, 0 otherwise. 
//this is the IP function for the server side. 
//cite the link from the project description. 
int IPS(char* port) {

    int sd; 
    char *ip = "8.8.8.8"; 
    char *tempPort = "53";
    if ((sd = connect_to_host(ip, tempPort)) == 0) {
        // printf("failure");
        // fflush(stdout);
        cse4589_print_and_log("[%s:ERROR]\n", "IP");
        return -1; 
    }
    //printf("host has been connected to");
    struct sockaddr_in sa; 
    int len = sizeof(sa); 
    //documentation for getsocketname example that I used-> https://support.sas.com/documentation/onlinedoc/ccompiler/doc750/html/lr2/zockname.htm
    if (getsockname(sd,&sa, &len) == -1) { 
        // printf("failure2");
        // fflush(stdout);
        cse4589_print_and_log("[%s:ERROR]\n", "IP");
        return -1; 
    }
    // printf("socketnume has been received.");

    //beejs 3.4 page 16
    char ip4[INET_ADDRSTRLEN]; 

    inet_ntop(AF_INET, &sa.sin_addr, ip4, INET_ADDRSTRLEN); 
    // char* ip_addr = inet_ntoa(sa.sin_addr);//make sure ipaddr is null terminated 
    // printf("%s",ip_addr);
    cse4589_print_and_log("[%s:SUCCESS]\n", "IP");
    cse4589_print_and_log("IP:%s\n", ip4);
    close(sd);
    return 0;
 }


 void author() { 
    cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "elizakos") ;
    
 }

 //verify IP is valid 
 int validIP (char *ip, char *cmd){
     if (strlen(ip) != 13){
        cse4589_print_and_log("[%s:ERROR]\n", cmd);
        cse4589_print_and_log("[%s:END]\n", cmd);
        return 0;
     }
     else{
     for (int i = 0; i < strlen(ip); i++){
         if (i == 0 || i == 1 || i == 2 || i == 4 || i == 5 || i == 6 || i == 8 || i == 9 || i == 11 || i == 12) {
             if (!(ip[i] >= 48 && ip[i] <= 57)){
                 cse4589_print_and_log("[%s:ERROR]\n", cmd);
                 cse4589_print_and_log("[%s:END]\n", cmd);
                 return 0;
             }
         }
         else if (i == 3 || i == 7 || i == 10){
             if (!(ip[i] == 46)){
                 cse4589_print_and_log("[%s:ERROR]\n", cmd);
                 cse4589_print_and_log("[%s:END]\n", cmd);
                 return 0;
             }
         }
         
     }
     }
     return 1;
 }