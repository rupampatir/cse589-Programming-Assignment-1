// #include <stdio.h> 
// #include <stdlib.h>
// #include <sys/socket.h>
// #include <strings.h>
// #include <strings.h>
// #include <arpa/inet.h>
// #include<sys/types.h>
// #include<netdb.h>

// #include "../include/server.h"
// #include "../include/client.h"

// #define CMD_SIZE 100
// #define TRUE 1
// #define MSG_SIZE 256
// #define BUFFER_SIZE 256
// #include "../include/statsArr.h"


// int connect_to_host(char *server_ip, char *server_port);
// int loggedIn;
// int s;
// char * port;
// int logincommand;

// //routing so this is not main, like the sample code from piazza states.
// int client(int argc, char**argv) {
//     int numClients = 0;
//     logincommand =0;

//     struct clientStruct *loggedInClients = (struct clientStruct *) calloc(5,sizeof(struct clientStruct));
//     for (int x = 0; x < 5; x++) {
//         (loggedInClients+x)->index = -1;
//     }
//     loggedIn = 0;

//     port = argv[2];
//     int command = 0;

//     while(TRUE) { //if we are logged out, we would enter a new while loop.
//         printf("\n[pa1-clientCSE489/589]");
//         fflush(stdout);
//         logincommand = 0;

//         //make an if/else statement to determine if the command needs to get sent to the server.
//         //ip, port, and author don't need to be sent to the server.

//         char *msg = (char*) malloc(sizeof(char)*MSG_SIZE);
//         memset(msg, '\0', MSG_SIZE);
//         //due to strtok
//         char *msgcopy = (char*)malloc(sizeof(char)*MSG_SIZE);
//         memset(msg,'\0',MSG_SIZE);

//         //fgets gets a string from a stream.
//         //so here, space has been allocated for the message.
//         //its just going to continuously (while true) check if anything has been inputted into the terminal
//         if (fgets(msg, MSG_SIZE-1, stdin) == NULL)//mind the new line character.
//         {
//             exit(-1);
//         } //no message!
//         strcpy(msgcopy,msg);

//         if (strcmp(msg, "EXIT\n")==0){
//             exit(0);
//         }

//         fflush(stdout);
//         command = processCommands(msg,port,loggedIn);

//         if (command == 0) {
//             printf("I got: %s(size:%d chars)", msg, (strlen(msg)));
//             char *login = strtok(msg," ");
//             char *sending = (char*)malloc(100 * sizeof(char));
//             strcpy(sending,login);
//             if (loggedIn == 0) {
//                 if (strcmp(login,"LOGIN") == 0) {
//                     login = strtok(NULL, " ");
//                     char *ipaddress = login;
//                     login = strtok(NULL, " ");
//                     char *portt = login;
//                     char* nport = strtok(portt,"\n");

//                     printf("t%s");

//                     if ((s = connect_to_host(ipaddress, nport)) != 0) {
//                         loggedIn = 1;
//                         char finalString[100];
//                         strcpy(finalString,"NEWPORT: ");
//                         strcat(finalString,port);
//                         char hostname[50];
//                         gethostname(&hostname,50);
//                         char hostString[50];
//                         strcpy(hostString," HOSTNAME: ");
//                         strcat(&hostString,hostname);
//                         strcat(&finalString,&hostString);
//                         logincommand = 1;
//                          //don't forget server ip error checking

//                         if (send(s, finalString, strlen(finalString),0) == -1){ printf("failed to send port \n");}
//                         char *buffer = (char*) malloc(sizeof(char) * BUFFER_SIZE);
//                         memset(buffer, '\0', BUFFER_SIZE);
//                         if(recv(s, buffer, BUFFER_SIZE, 0) >= 0) {

//                             char *compareString = strtok(buffer, " ");

//                             if (strcmp(compareString, "ClientInfo") == 0) {
//                                 processListStructure(loggedInClients, buffer) ;
//                                 printf("testing%s",loggedInClients->hostname);
//                                 fflush(stdout);
//                                 free(buffer);
//                             }
//                         }


//                     }
//                 }
//             }  else if (command == 0 && strcmp(sending,"SEND") == 0) {
//                     printf("should be send");
//                     fflush(stdout);
//                     char teststr[100];
//                     strcpy(&teststr,msgcopy);
//                     //don't forget server ip error checking.
//                     if (send(s, teststr, strlen(teststr),0) == -1){ printf("failed to send port \n");}
//                     else {printf("sent!");
//                     fflush(stdout);}
//                 }   else {
//                     printf("eh");
//                     fflush(stdout);
//                 }
//         } else if (command == 3) {
//             //need to print it organized by port.
//             for (int x = 0; x < 5; x++) {
//                 if ((loggedInClients+x)->index != -1) {

//                     cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",
//                     (loggedInClients+x)->index,
//                     (loggedInClients+x)->hostname,
//                     (loggedInClients+x)->ip,
//                     (loggedInClients+x)->port);
//                     fflush(stdout);

//                 }
//             }
//         }
//         // else {
//             printf("\n\nloggedIn %d, command %d, logincommand %d\n\n",loggedIn, command, logincommand);
//             if (loggedIn == 1 && command != 1 && command != 3 && command != 0 && logincommand == 0) {
//                 printf("entering this section");

//                 char *buffer = (char*) malloc(sizeof(char) * BUFFER_SIZE);
//                 memset(buffer, '\0', BUFFER_SIZE);

//                 char *nbuffer = (char*) malloc(sizeof(char) * BUFFER_SIZE);
//                 memset(nbuffer, '\0', BUFFER_SIZE);
//                 strcpy(nbuffer, buffer);
//                 //getting frustrated with time and hardcoding inefficiently everything.
//                 char *compareString = (char*) malloc(sizeof(char) * BUFFER_SIZE);
//                 memset(compareString, '\0', BUFFER_SIZE);

//                 if(recv(s, buffer, BUFFER_SIZE, 0) >= 0) {

//                     char *compareString = strtok(compareString, " ");

//                     if (strcmp(compareString, "ClientInfo") == 0) {
//                         processListStructure(loggedInClients, buffer) ;
//                         printf("testing%s",loggedInClients->hostname);
//                         fflush(stdout);
//                         free(buffer);
//                     } else {
//                         free(buffer);
//                         printf("%s", buffer);
//                         fflush(stdout);

//                     }


//                 } else {
//                     printf("fail");
//                 }
//                 // free(msg);
//                 // free(buffer);

//             }
//        // }
//        printf("test");
//             fflush(stdout);



//         //im confused about receiving from the server unicast connections given the sample code.
//     }
// }


// //this will take the server id and the server port and
// //return a new socket descriptor for the server.
// //it will return 0 if it fails to connect to the server.
// int connect_to_host(char *server_ip, char* server_port) {

//     int fdsocket;
//     struct addrinfo hints, *res;

//     memset(&hints, 0, sizeof(hints));
//         hints.ai_family = AF_INET;
//         hints.ai_socktype = SOCK_STREAM;
//         //ai is not set to passive because this is getting the address from the server
//         //and establisthing a connection/attempting to establish a connection to the server.
//    // printf("step1");
//     if (getaddrinfo(server_ip, server_port, &hints, &res) != 0) {
//         perror("getaddrinfo failed");
//     }
//    // printf("step2");
//    // fflush(stdout);
//     fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
//     if(fdsocket <0) {
//         printf("socket could not be created");
//         perror("failed to create socket");
//         fflush(stdout);
//     }
//    // printf("step3");
//    // fflush(stdout);
//     if (connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0) {
//         perror("connect failed");
//     }
//     //printf("step4");
//     //fflush(stdout);
//     freeaddrinfo(res);
//     //printf("step5");
//     fflush(stdout);
//     return fdsocket;

// }
