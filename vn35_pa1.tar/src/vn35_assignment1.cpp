/**
 * @vn35_assignment1
 * @author  Venkata Sai dheeraj Narayanabhatla <vn35@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */

#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<sstream>
#include<ifaddrs.h>
#include<string>
#include<sys/types.h>
#include<cctype>
#include<cstdlib>
#include<sys/wait.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>
#include<vector>
#include<netdb.h>
#include<sys/socket.h>
#include<signal.h>
#include<errno.h>
#include<stdlib.h>
#include "../include/global.h"
#include "../include/logger.h"

using namespace std;
struct text
{
	char data[1000];
};

struct BlockedIP
{
	char IP[30];
};

struct ClientInfo
{
	int socket;
        char IP[30];        
        int port;
	vector<struct BlockedIP>BlockedClientList;
	vector<struct text>bufferedMessages;
        bool isLoggedIn;
	int messages_sent;
        int messages_received;
	bool enter;
};

struct statisticsData
{
        char id[2],clientName[50],IP[50],port[6];
};

vector<statisticsData> L;
vector<struct BlockedIP> clientBlockList;
int sockfd,maxsocketfd;
int port;
char IPAddress[20];
struct addrinfo hints,*myres,*result,newhints;
fd_set master,read_fds,write_fds;
bool loginflag;
struct sockaddr_in cli,res;
socklen_t addrlen;
vector<struct ClientInfo>remoteList;
struct sockaddr remoteaddr;

vector<string> splitCommand(char *inputCommand)
{
	vector<string> listOfInputs;
	string str="";
	for(int i=0;inputCommand[i]!='\0';i++)
	{
		if(inputCommand[i]==' ')
		{
			str+='\0';
			listOfInputs.push_back(str);
			str="";
			continue;
		}
		str+=inputCommand[i];
	}
	str+='\0';
	listOfInputs.push_back(str);
	return listOfInputs;
}
bool compare(ClientInfo c1,ClientInfo c2)
{
	return (c1.port<c2.port);
}

void splitList(char *p)
{
	char str[500];
	strcpy(str,p);
	char *printer;
	vector<char*>s;
     	printer=strtok(str,"-");
	while(printer!=NULL)
	{
		s.push_back(printer);
		printer=strtok(NULL,"-");
		
	}

	struct statisticsData data;
	L.clear();
	char str1[500];
	char *temp;
	for(int i=0;i<s.size();i++)
	{	strcpy(str1,s[i]);
		temp=strtok(str1," ");
		strcpy(data.id,temp);
		temp=strtok(NULL," ");
		strcpy(data.clientName,temp);
		temp=strtok(NULL," ");
		strcpy(data.IP,temp);
		temp=strtok(NULL," ");
		strcpy(data.port,temp);
	
		L.push_back(data);
	}

}

char* recvClientMessage(int sockfd,char *message)
{
	char *buf;
	char str[1500];
	int size;
	recv(sockfd,&size,sizeof(size),0);

	int total=0;
	int n;
	while(total<size)
	{
		n=recv(sockfd,str+total,size,0);

		if(n==-1)
		break;
	
		total+=n;
		size-=n;

	}

	str[total]='\0';

	strcpy(message,str);
	return message;
}


bool checkInClientList(char *IP)
{
	for(int i=0;i<L.size();i++)
	{
		if(strcmp(L[i].IP,IP)==0 && strcmp(L[i].IP,IPAddress)!=0)
			return true;
	}
	return false;
}

bool checkIP(char *IP)
{
        struct sockaddr_in sock;
        int checkAddr=inet_pton(AF_INET,IP,&(sock.sin_addr));
        return checkAddr>0?true:false;
}

bool checkPort(char *Portent)
{
	int tempPort = atoi(Portent);
	return (tempPort<=0 || tempPort>65335)?false:true;
}
bool checkClientBlocked(char *IP)
{
	for(int i=0;i<clientBlockList.size();i++)
		if(strcmp(clientBlockList[i].IP,IP)==0)
		{
			return true;
		}

	return false;

}

void sendall(int sock,char *type,char* buf)
{	
	char *message=new char[1048];
	strcat(type,buf);
	strcpy(message,type);
	int size=strlen(type);
	int n;
	int total=0;
	send(sock,&size,sizeof(size),0);
	while(total<size)
	{	
		n=send(sock,message+total,size,0);
	
		if(n==-1)
		break;
		
		total+=n;
		size-=n;
	}
	delete[] message;
}

void startClient(char *portAsString)
{
	loginflag=false;
	port=atoi(portAsString);
	memset(&hints,0,sizeof(hints));
	hints.ai_flags=AI_PASSIVE;
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_STREAM;

	if(getaddrinfo(NULL,portAsString,&hints,&myres)==-1)
	{
		perror("Error:Client getaddrinfo() failed");
	}
	
	int tempfd=socket(AF_INET,SOCK_STREAM,0);
	if(tempfd==-1)
	{

		perror("Error: Client socket() failed");
		
	}

	memset(&cli,0,sizeof(cli));
        cli.sin_family=AF_INET;
	cli.sin_port=htons(port);
        cli.sin_addr.s_addr=htonl(INADDR_ANY);
	
	int on=1;

	if(setsockopt(tempfd,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(int))==-1)
        {
                perror("Error: Client sockopt() failed");
        }


        if(bind(tempfd,(struct sockaddr*)&cli,sizeof(cli))==-1)
        {
                perror(" Error: Client bind() failed");
        }

        if(listen(tempfd,40)==-1)
        {
                perror("Error: Client listen() failed");
        }
	
	char hostbuffer[50];
	int hostname = gethostname(hostbuffer, sizeof(hostbuffer));
	struct hostent *host = gethostbyname(hostbuffer);
	char *IP = inet_ntoa(*((struct in_addr*)host->h_addr_list[0]));
	strcpy(IPAddress,IP);
		
	FD_ZERO(&master);
	maxsocketfd=tempfd;
	FD_SET(0,&master);
	FD_SET(tempfd,&master);
	char input[1024];
	int i;
	while(1)
	{
		read_fds=master;
		if(select(maxsocketfd+1,&read_fds,NULL,NULL,NULL)==-1)
		{
			continue;
		}
		
		for(i=0;i<=maxsocketfd;i++)
		{
			if(FD_ISSET(i,&read_fds))
			{
				 if(i==0)
				{
					fgets(input,1023,stdin);
					input[strlen(input)-1]='\0';
					char second[1000],third[1000];
					vector<string> splitWords = splitCommand(input);
					char shellCommand[20];
					strcpy(shellCommand,splitWords[0].c_str());
					if(shellCommand==string("AUTHOR"))
					{
						cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
						cse4589_print_and_log("I, vn35, have read and understood the course academic integrity policy.\n");
						cse4589_print_and_log("[AUTHOR:END]\n");
					}
					else if(shellCommand==string("PORT"))
					{
						cse4589_print_and_log("[PORT:SUCCESS]\n");
						cse4589_print_and_log("PORT:%d\n",port);
						cse4589_print_and_log("[PORT:END]\n");
					}
					else if(shellCommand==string("IP"))
					{
						cse4589_print_and_log("[IP:SUCCESS]\n");
						cse4589_print_and_log("IP:%s\n", IPAddress);
						cse4589_print_and_log("[IP:END]\n");
						
					}
					else if(shellCommand==string("LOGIN"))
					{
						if(splitWords.size()!=3)
						{
							cse4589_print_and_log("[LOGIN:ERROR]\n");
                                                        cse4589_print_and_log("[LOGIN:END]\n");
							continue;
						}
						memset(&newhints,0,sizeof(newhints));
						newhints.ai_family=AF_INET;
						newhints.ai_socktype=SOCK_STREAM;
						strcpy(second,splitWords[1].c_str());
						strcpy(third,splitWords[2].c_str());
					   	if(checkIP(second)==true && checkPort(third)==true)
						{
						   if(loginflag==false)	
					 	   {	if(getaddrinfo(second,third,&newhints,&result)==-1)
							{
								continue;
							}
							
						
							if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1)
							{
								continue;
							}
					
							int on=1;
							if (setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&on,sizeof on) == -1) {
								continue;
							}

								
							if(connect(sockfd,result->ai_addr,result->ai_addrlen)==-1)
							{
								continue;
							}

							FD_SET(sockfd,&master);
							loginflag=true;
							(sockfd>maxsocketfd)?maxsocketfd=sockfd:maxsocketfd;
							send(sockfd,&port,sizeof(port),0);
						    }
						    else
						    {
                                                        cse4589_print_and_log("[LOGIN:ERROR]\n");
                                                        cse4589_print_and_log("[LOGIN:END]\n");
						    }
						}
					   	else
						{
							cse4589_print_and_log("[LOGIN:ERROR]\n");
                                                        cse4589_print_and_log("[LOGIN:END]\n");
						}
					
					}
					else if(shellCommand==string("LIST"))
					{
						if(loginflag==true)
						{
							cse4589_print_and_log("[LIST:SUCCESS]\n");
							
							for(int i=0;i<L.size();i++)
							cse4589_print_and_log("%-5d%-35s%-20s%-8s\n", i+1,L[i].clientName,L[i].IP,L[i].port);
							cse4589_print_and_log("[LIST:END]\n");
						}
						
					}

					else if(shellCommand==string("REFRESH"))
					{	
						if(loginflag==true)
						{
							char request[1024]="0";
							char trailer[1024]=" ";
							sendall(sockfd,request,trailer);
							cse4589_print_and_log("[REFRESH:SUCCESS]\n");
                                                        cse4589_print_and_log("[REFRESH:END]\n");
						}
						else
						{
							cse4589_print_and_log("[REFRESH:ERROR]\n");
                                                        cse4589_print_and_log("[REFRESH:END]\n");

						}

					}
					else if(shellCommand==string("SEND"))
					{
						if(splitWords.size()<3)
						{
							cse4589_print_and_log("[SEND:ERROR]\n");
                                                        cse4589_print_and_log("[SEND:END]\n");
							continue;
						}
						strcpy(second,splitWords[1].c_str());
						if(checkIP(second)==true && checkInClientList(second)==true && loginflag==true)
						{ 
							char request[1024]="1 ";
							strcat(request,second);
							strcat(request," ");
							string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(third,msg.c_str());
							sendall(sockfd,request,third);
							cse4589_print_and_log("[SEND:SUCCESS]\n");
							cse4589_print_and_log("[SEND:END]\n");
						}
						else
						{
							cse4589_print_and_log("[SEND:ERROR]\n");
                                                        cse4589_print_and_log("[SEND:END]\n");   
						}
					}
					else if(shellCommand==string("BROADCAST"))
					{
						if(splitWords.size()<2)
						{
							cse4589_print_and_log("[BROADCAST:ERROR]\n");
                                                        cse4589_print_and_log("[BROADCAST:END]\n");
							continue;
						}
						string msg = "";

							for(int in=1;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(third,msg.c_str());
						char request[1024]="2 ";
						strcat(request,IPAddress);
						strcat(request," ");
						sendall(sockfd,request,third);

						cse4589_print_and_log("[BROADCAST:SUCCESS]\n");
                                                cse4589_print_and_log("[BROADCAST:END]\n");
					}
					else if(shellCommand==string("BLOCK"))
					{	
						if(splitWords.size()!=2)
						{
							cse4589_print_and_log("[BLOCK:ERROR]\n");
                                                        cse4589_print_and_log("[BLOCK:END]\n");
							continue;
						}
						strcpy(second,splitWords[1].c_str());
						if(checkIP(second)==true && checkInClientList(second)==true && checkClientBlocked(second)==false)
						  {	char request[]="3 ";
							struct BlockedIP temp;
							sendall(sockfd,request,second);
							strcpy(temp.IP,second);
							clientBlockList.push_back(temp);
							cse4589_print_and_log("[BLOCK:SUCCESS]\n");
                                                        cse4589_print_and_log("[BLOCK:END]\n");

						  }
						else
						  {
							cse4589_print_and_log("[BLOCK:ERROR]\n");
                                                        cse4589_print_and_log("[BLOCK:END]\n");

						  }
					}
					else if(shellCommand==string("UNBLOCK"))
					{	
						if(splitWords.size()!=2)
						{
							cse4589_print_and_log("[UNBLOCK:ERROR]\n");
                                                        cse4589_print_and_log("[UNBLOCK:END]\n");
							continue;
						}
						strcpy(second,splitWords[1].c_str());
						if(checkIP(second)==true && checkInClientList(second)==true && checkClientBlocked(second)==true)
						{	char request[]="4 ";
							sendall(sockfd,request,second);
							for(int i=0;i<clientBlockList.size();i++){
								if(strcmp(clientBlockList[i].IP,second)==0)
								{
									clientBlockList.erase(clientBlockList.begin()+i);
									break;
								}
							}
							cse4589_print_and_log("[UNBLOCK:SUCCESS]\n");
                                                        cse4589_print_and_log("[UNBLOCK:END]\n");

						}
						else
						{
							cse4589_print_and_log("[UNBLOCK:ERROR]\n");
                                                        cse4589_print_and_log("[UNBLOCK:END]\n");
						}
					}
					else if(shellCommand==string("LOGOUT"))
					{
						char request[]="X";
						char type[]=" ";
						loginflag=false;
						sendall(sockfd,request,type);
						FD_CLR(sockfd,&master);
						close(sockfd);
						cse4589_print_and_log("[LOGOUT:SUCCESS]\n");
                                                cse4589_print_and_log("[LOGOUT:END]\n");
					}	
					else if(shellCommand==string("EXIT"))
					{
						char request[]="9";
						char type[]=" ";
						sendall(sockfd,request,type);
						FD_CLR(sockfd,&master);
						close(sockfd);
						cse4589_print_and_log("[EXIT:SUCCESS]\n");
                                                cse4589_print_and_log("[EXIT:END]\n");
						exit(0);
					}
				}

				else if(i==sockfd)
				{	char r[500];
					char *m=recvClientMessage(sockfd,r);
					vector<string> splitWords = splitCommand(m);	
					char sender[1000],message[1000];			
					if(m[0]=='0')
					{ 
					 splitList(m+2);
					 
					}
					 
					else if(m[0]=='1')
					{  
					   strcpy(sender,splitWords[1].c_str());
					string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());
					    cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
					    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender,message);
                                            cse4589_print_and_log("[RECEIVED:END]\n");


					}
					else if(m[0]=='2')
					{	
						strcpy(sender,splitWords[1].c_str());
					  string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());
                                            cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
                                            cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);
                                            cse4589_print_and_log("[RECEIVED:END]\n");

					}
					else if(m[0]=='L')
					{
						splitList(m+2);
						char type[]="B";
						char req[]=" ";
						sendall(sockfd,type,req);
					}
					else if(m[0]=='B')
					{	
					   string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());
                                                cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
                                                cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);
                                                cse4589_print_and_log("[RECEIVED:END]\n");

						char type[]="B";
						char req[]=" ";
						sendall(sockfd,type,req);
					}
					else if(m[0]=='F')
					{
						strcpy(sender,splitWords[1].c_str());
					   string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());
                                            cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
                                            cse4589_print_and_log("msg from:%s\n[msg]:%s\n",sender ,message);
                                            cse4589_print_and_log("[RECEIVED:END]\n");

                                            cse4589_print_and_log("[LOGIN:SUCCESS]\n");
                                            cse4589_print_and_log("[LOGIN:END]\n");

					}
					else if(m[0]=='N')
					{
                                            cse4589_print_and_log("[LOGIN:SUCCESS]\n");
                                            cse4589_print_and_log("[LOGIN:END]\n");
					}
				}
			}
		}
	}
}


char* myList(char* m)
{	
	char *p=new char[500];
	p[0]='\0';
	
	int i;
	char host[200],service[200];
	struct sockaddr_in s;
	socklen_t slen=sizeof(s);

	sort(remoteList.begin(),remoteList.end(),compare);
	for(i=0;i<remoteList.size();i++)
	{
	 if(remoteList[i].enter==true&&remoteList[i].isLoggedIn==true)
	 {	strcat(p,"-");

		stringstream stream;
		stream<<(i+1); 
		string temp=stream.str();
		char *num=new char[temp.length()+1];
		strcpy(num,temp.c_str());


		strcat(p,num);
		strcat(p," ");
		inet_aton(remoteList[i].IP,&s.sin_addr);
		s.sin_family=AF_INET;
	
		getnameinfo((struct sockaddr*)&s,slen,host,sizeof(host),service,sizeof(service),NI_NAMEREQD);
		strcat(p,host);
		
		
		strcat(p," ");
		inet_ntop(AF_INET,&(s.sin_addr),host,INET_ADDRSTRLEN);

		strcat(p,host);
		strcat(p," ");
		stream.str("");
		stream<<remoteList[i].port;
		temp=stream.str();
		delete[] num;
		num=new char[temp.length()+1];
		strcpy(num,temp.c_str());
		strcat(p,num);
		delete[] num;
	 }
	}	
		

	strcpy(m,p);

	return m;
}

 char* recvmessage(int sockfd,char *buf)
{  
        char *str=new char[1500];
        int size;
        if(recv(sockfd,&size,sizeof(size),0)==0)
	{	
		FD_CLR(sockfd,&master);

		for(int i=0;i<remoteList.size();i++)
		{
			if(remoteList[i].socket==sockfd)
				remoteList.erase(remoteList.begin()+i);

		}

		close(sockfd);

	}	
        int total=0;
        int n;
        while(total<size)
        {
                n=recv(sockfd,str+total,size,0);

                if(n==-1)
                break;

                total+=n;
                size-=n;
        }
        str[total]='\0';
 	return str;
}

int findClient(char *IP)
{
	for(int i=0;i<remoteList.size();i++)
		if(strcmp(remoteList[i].IP,IP)==0)
		{
			return i;
		}
	
	return -1;
}
	

int findClient(int sock)
{

	for(int i=0;i<remoteList.size();i++)
		if(remoteList[i].socket==sock)
			return i;

	return -1;
}

bool isBlocked(int sendsock,int rind)
{
	int index=findClient(sendsock);
	
	for(int i=0;i<remoteList[rind].BlockedClientList.size();i++)
		if(strcmp(remoteList[index].IP,remoteList[rind].BlockedClientList[i].IP)==0)
			return true;
		
	return false;
}

void printBlockList(char *IP)
{
	char hostname[200],service[100];
        sockaddr_in s;
        socklen_t size=sizeof(s);
	int i;
	vector<ClientInfo>tempBlock;
	int index=findClient(IP);
	if(index!=-1 && remoteList[index].enter==true)
	{	cse4589_print_and_log("[BLOCKED:SUCCESS]\n");

		for(i=0;i<remoteList[index].BlockedClientList.size();i++)
		{	 int j=findClient(remoteList[index].BlockedClientList[i].IP);
		   	  tempBlock.push_back(remoteList[j]);
		 	

		}
	
		sort(tempBlock.begin(),tempBlock.end(),compare);
		for(i=0;i<tempBlock.size();i++)
		{
			inet_aton(tempBlock[i].IP,&s.sin_addr);
                	s.sin_family=AF_INET;
                	getnameinfo((struct sockaddr*)&s,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

			cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",i+1,hostname,tempBlock[i].IP,tempBlock[i].port);
		}
		cse4589_print_and_log("[BLOCKED:END]\n");
	}
	else
	{

		cse4589_print_and_log("[BLOCKED:ERROR]\n");
		cse4589_print_and_log("[BLOCKED:END]\n");
	}
	
}

char *prepareBuffer(int rind,char *message)
{
	char mod[1024];
	memset(mod,'\0',1024);
	char third[1500];
	vector<string> splitWords = splitCommand(message);
	string msg = "";

	for(int in=2;in<splitWords.size();in++){
		msg+=splitWords[in];
		msg=msg.substr(0,msg.length()-1);
		msg+=" ";
	}
	msg+='\0';
	strcpy(third,msg.c_str());
	mod[0]=message[0];
	mod[1]=message[1];
	strcat(mod,remoteList[rind].IP);
	strcat(mod," ");
	strcat(mod,third);
	return mod;	 
}

void startServer(char *arg)
{
	char hostbuf[50];
	int hname = gethostname(hostbuf, sizeof(hostbuf));
	struct hostent *host = gethostbyname(hostbuf);
	char *IP = inet_ntoa(*((struct in_addr*)host->h_addr_list[0]));
	strcpy(IPAddress,IP);

	memset(&res,0,sizeof(res));
	res.sin_family=AF_INET;
	port = atoi(arg);
	int on=1;
	res.sin_port=htons(port);
	res.sin_addr.s_addr=htonl(INADDR_ANY);

	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd==-1)
	{
		perror("Error: Server socket() failed ");
		exit(-1);
	}
	

	if(setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(int))==-1)
	{
		perror("Error: Server setsockopt() failed ");
		exit(-1);
	}
	

	if(bind(sockfd,(struct sockaddr*)&res,sizeof(res))==-1)
	{
		perror("Error: Server bind() failed ");
		exit(-1);
	}

	if(listen(sockfd,40)==-1)
	{
		perror("Error: Server listen() failed ");
		exit(-1);
	}




	maxsocketfd=sockfd;
	FD_SET(0,&master);
	FD_SET(sockfd,&master);
	char buf[500],remoteIP[INET6_ADDRSTRLEN];
	int buflen;
	int i;
	int index;
	while(true)
	{
		read_fds=master;
		if(select(maxsocketfd+1,&read_fds,NULL,NULL,NULL)==-1)
		{
			perror("Error: Server select() failed ");
			exit(-1);
		}

		for(i=0;i<=maxsocketfd;i++)
		{
			if(FD_ISSET(i,&read_fds))
			{
				if(i==sockfd)
				{
					addrlen=sizeof(remoteaddr);
					int acceptfd=accept(sockfd,&remoteaddr,&addrlen);
					struct ClientInfo temp;
					 
					if(acceptfd==-1)
					{
						perror("Error: Client accept() failed");
						exit(-1);
					}
					else
					{	
						FD_SET(acceptfd,&master);
						(acceptfd>maxsocketfd)?maxsocketfd=acceptfd:maxsocketfd;
						inet_ntop(AF_INET,&(((struct sockaddr_in*)&remoteaddr)->sin_addr),remoteIP,INET_ADDRSTRLEN);
						recv(acceptfd,&temp.port,sizeof(int),0);
						 
						 if((index=findClient(remoteIP))==-1)
						 {	strcpy(temp.IP,remoteIP);
							temp.socket=acceptfd;
							temp.messages_sent=0;
							temp.messages_received=0;
							temp.enter=true;
							temp.isLoggedIn=true;
						 	remoteList.push_back(temp);
						 }
						else
						{		
							remoteList[index].enter=true;
							remoteList[index].isLoggedIn=true;
							strcpy(remoteList[index].IP,remoteIP);
							remoteList[index].socket=acceptfd;
							remoteList[index].port=temp.port;
						}

						
						char list[500],*l;
						l=myList(list);		

						char type[]="L ";
						sendall(acceptfd,type,list);
						
					}
				}
				else if(i==0)
				{
					char input[500]="";
					
					
						fgets(input,sizeof(input),stdin);
						input[strlen(input)-1]='\0';
						vector<string> splitWords = splitCommand(input);
						char first[20];
						strcpy(first,splitWords[0].c_str());
						if(first==string("AUTHOR"))
						{	
							cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
							cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "vn35");
							cse4589_print_and_log("[AUTHOR:END]\n");
						}
					
						else if(first==string("IP"))
						{	
							cse4589_print_and_log("[IP:SUCCESS]\n");
							cse4589_print_and_log("IP:%s\n", IPAddress);
							cse4589_print_and_log("[IP:END]\n");
							
						}
		
						else if(first==string("PORT"))
						{	
							
							cse4589_print_and_log("[PORT:SUCCESS]\n");
							cse4589_print_and_log("PORT:%d\n",port);
							cse4589_print_and_log("[PORT:END]\n");
							
						}
		
						else if(first==string("LIST"))
						{	char *p,l[500];
							p=myList(l);
							char hostname[200],service[100];
							sockaddr_in si;
							socklen_t size=sizeof(si);
							cse4589_print_and_log("[LIST:SUCCESS]\n");
							for(int i=0;i<remoteList.size();i++)
							{	if(remoteList[i].enter==true && remoteList[i].isLoggedIn==true)
								{	inet_aton(remoteList[i].IP,&si.sin_addr);
									si.sin_family=AF_INET;
									getnameinfo((struct sockaddr*)&si,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);
									cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", i+1, hostname, remoteList[i].IP, remoteList[i].port);
								}

							}	
							cse4589_print_and_log("[LIST:END]\n");
						}
						else if(first==string("STATISTICS"))
						{
							char hostname[200],service[100];
							sockaddr_in si;
							socklen_t size=sizeof(si);
							char log[20];
							cse4589_print_and_log("[STATISTICS:SUCCESS]\n");
							for(int i=0;i<remoteList.size();i++)
							{ 
							     if(remoteList[i].enter==true)
								{
									inet_aton(remoteList[i].IP,&si.sin_addr);
									si.sin_family=AF_INET;
									getnameinfo((struct sockaddr*)&si,size, hostname,sizeof(hostname),service,sizeof service,NI_NAMEREQD);

									if(remoteList[i].isLoggedIn==true)
									{
										 strcpy(log,"logged-in");

									}
									else
									{	
										strcpy(log,"logged-out");
									}

								cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i+1, hostname,remoteList[i].messages_sent, remoteList[i].messages_received,log);
								}
							}
							cse4589_print_and_log("[STATISTICS:END]\n");
													
						}
						else if(first==string("BLOCKED"))
						{	
							char IP[30];
							strcpy(IP,splitWords[1].c_str());
							if(checkIP(IP)==true)
							{	printBlockList(IP);
							
							}
							else
							{
								cse4589_print_and_log("[BLOCKED:ERROR]\n");
								cse4589_print_and_log("[BLOCKED:END]\n");
							}
						}

						else if(input==string("EXIT"))
						{	
							close(sockfd);
							exit(-1);
						}	
					
				 }

					
				else
				{
					char* message;
					char response[1500];
					message=recvmessage(i,response);
					vector<string> splitWords = splitCommand(message);
					if(message[0]=='0')
					{	char list[500];
						char type[1024]="0 ";
						char* p=myList(list);
						sendall(i,type,p);
					}
					else if(message[0]=='1')
					{	char m[1400];
						int send=findClient(i);
						remoteList[send].messages_sent++;
						char IP[30],third[1000];
						strcpy(IP,splitWords[1].c_str());
						string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(third,msg.c_str());
						int j=findClient(IP);
						if(j!=-1)
						{
							
							if(isBlocked(i,j)==false)
							{	char type[]="";
								
								strcpy(m,message);
								if(remoteList[j].isLoggedIn==true)
								{	
									char *prep=prepareBuffer(send,m);
									sendall(remoteList[j].socket,prep,type);
									remoteList[j].messages_received++;
									
									cse4589_print_and_log("[RELAYED:SUCCESS]\n");
                                                        		cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",remoteList[send].IP,remoteList[j].IP,third);
                                                        		cse4589_print_and_log("[RELAYED:END]\n");

									
								}
								else
								{
									struct text mbuf;
									char *prep=prepareBuffer(send,message);
									strcpy(mbuf.data,prep);
									remoteList[j].bufferedMessages.push_back(mbuf);
								}
							}
							
						}
						else
						{
							strcpy(m,message);
							struct ClientInfo temp2;
							strcpy(temp2.IP,IP);
							temp2.enter=false;
							temp2.isLoggedIn=false;
							temp2.messages_sent=0;
							temp2.messages_received=0;
							remoteList.push_back(temp2);
							int ind=findClient(temp2.IP);
							if(ind!=-1)
							{	struct text mbuf;
								char *prep=prepareBuffer(send,message);
								strcpy(mbuf.data,prep);
								remoteList[ind].bufferedMessages.push_back(mbuf);
							}
						}
						
		

					}

					else if(message[0]=='2')
					{		int send=findClient(i);
							remoteList[send].messages_sent++;
							bool flag=false;
							int client;
						for(int j=1;j<=maxsocketfd;j++)
						{	char trailer[]="";
							client=findClient(j);
							if(FD_ISSET(j,&master))
							{	
								if(j!=i && j!=sockfd )
								{	
								
									if(remoteList[client].isLoggedIn==true && isBlocked(i,client) == false)
									{	sendall(j,message,trailer);
							 			flag=true;
										
										remoteList[client].messages_received++;
									}	
								}
							}
							
							else if(client!=-1 && isBlocked(i,client)==false)
							{	 
								struct text m;
								strcpy(m.data,message);
								remoteList[client].bufferedMessages.push_back(m);
							}
						}
						if(flag==true)
						{	
							char third[1000];
					   		string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(third,msg.c_str());
							cse4589_print_and_log("[RELAYED:SUCCESS]\n");
							cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",remoteList[send].IP,third);
							cse4589_print_and_log("[RELAYED:END]\n");
						}

					}
					else if(message[0]=='3')
					{
						struct BlockedIP tempBlock;
						index=findClient(i);
						if(index!=-1)
						{ 
						char second[1000];
						strcpy(second,splitWords[1].c_str());
						  strcpy(tempBlock.IP,second);
						  remoteList[index].BlockedClientList.push_back(tempBlock);
						}
					}

					else if(message[0]=='4')
					{
						index=findClient(i);

						if(index!=-1)
						{
							char IPlocal[100];
							strcpy(IPlocal,splitWords[1].c_str());
							int index;
							int eind;
							index=findClient(i);
							
							for(int remoteInd=0;remoteInd<remoteList[index].BlockedClientList.size();remoteInd++)
							{	
								if(strcmp(remoteList[index].BlockedClientList[remoteInd].IP,IPlocal)==0)
								{	eind=remoteInd;	
									break;
								}
							}
							remoteList[index].BlockedClientList.erase(remoteList[index].BlockedClientList.begin()+eind);

						}
					}
					else if(message[0]=='9')
					{
						int ind=findClient(i);
						remoteList[ind].isLoggedIn=false;
						remoteList[ind].enter=false;
						remoteList[ind].messages_sent=0;
						remoteList[ind].messages_received=0;
						FD_CLR(i,&master);
						close(i);

					}
					else if(message[0]=='X')
					{
						int ind=findClient(i);
						remoteList[ind].isLoggedIn=false;
						FD_CLR(i,&master);
						close(i);		

					}
					else if(message[0]=='B')
					{	int j=findClient(i);
						int c=-1;
						char from[1000],message[1000];
						int size=remoteList[j].bufferedMessages.size();
						if(size>1)
						{	char type[1024]="B";
							sendall(remoteList[j].socket,type,remoteList[j].bufferedMessages[0].data);
							vector<string> splitWords = splitCommand(remoteList[j].bufferedMessages[0].data);
							strcpy(from,splitWords[1].c_str());
							string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());

							remoteList[j].messages_received++;
							remoteList[j].bufferedMessages.erase(remoteList[j].bufferedMessages.begin());
							
							if(remoteList[j].bufferedMessages[0].data[0]=='2')
								c=1;
							else
								c=0;
					
						}
						
						else if(size==1)
						{	char type[1024]="F";
							sendall(remoteList[j].socket,type,remoteList[j].bufferedMessages[0].data);
							remoteList[j].messages_received++;
							vector<string> splitWords = splitCommand(remoteList[j].bufferedMessages[0].data);
							strcpy(from,splitWords[1].c_str());
							string msg = "";

							for(int in=2;in<splitWords.size();in++){
								msg+=splitWords[in];
								msg=msg.substr(0,msg.length()-1);
								msg+=" ";
							}
							msg+='\0';
							strcpy(message,msg.c_str());
							remoteList[j].bufferedMessages.erase(remoteList[j].bufferedMessages.begin());
						
							if(remoteList[j].bufferedMessages[0].data[0]=='2')
                                                                c=1;
                                                        else
                                                                c=0;
						}
						else 
						{
							char type[]="N";
							char resp[]=" ";
							sendall(remoteList[j].socket,type,resp);
						}


						if(c==1)
						{
							cse4589_print_and_log("[RELAYED:SUCCESS]\n");
                                                        cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n",from,message);
                                                        cse4589_print_and_log("[RELAYED:END]\n");
						}
						else if(c==0) 
						{	
							cse4589_print_and_log("[RELAYED:SUCCESS]\n");
                                                        cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",from,remoteList[j].IP,message);
                                                        cse4589_print_and_log("[RELAYED:END]\n");
						}

					} delete[] message;
				}
			}
		}
	}

}




int main(int argc,char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/* Clear LOGFILE*/
    fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
        if(argc!=3)
	{
		cse4589_print_and_log("Please enter in format: \"%s <s/c> <port-number>\"",argv[0]);
		return 0;
	}
	if(argv[1]==string("c"))
	{
		startClient(argv[2]);
	}
	
	else if(argv[1]==string("s"))
	{ 
		startServer(argv[2]);
	}
	else
	{
		cse4589_print_and_log("Please enter in format: \"%s <s/c> <port-number>\"",argv[0]);
	}

	return 0;
}
