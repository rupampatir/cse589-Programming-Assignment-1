/**
 * @mukuljes_assignment1
 * @author  Mukul Jeswani <mukuljes@buffalo.edu>
 * @author Warren Green <wogreen@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <strings.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <string>
#include <vector>
#include<map>
#include<unordered_map>
#include <unistd.h>
#include "../include/logger.h"
#include <cstring>

#define TRUE 1
#define MSG_SIZE 256
#define BUFFER_SIZE 256
#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define CMD_SIZE 100

std::vector<std::string> loggedInUsers;
std::unordered_map<std::string, int> usersPostsReceived;
std::unordered_map<std::string, int> usersPostsSent;
std::map<int, std::string,std::greater<int> > usersPort;
std::unordered_map<std::string, std::string> usersHostname;
std::unordered_map<std::string,int> socketList;
std::unordered_map<std::string, bool> usersLoggedOn;
std::map<std::string, std::vector<std::string>* > usersBlockedList;

bool validIP(std::string ip);
void getIPAddress();
int connect_to_host(const char *server_ip, const char *server_port);
int parseInput(char* buffer);
int parseMessage(char* buffer);
void serverLogout();
void serverExit();
void clientFunction();
void serverFunction();
int parseCommand(char* bufferString);
void refreshList(std::string userIP);
int parseIncoming(char* bufferString, std::string userIP);
int server;
int port;
char* portString;
/**
* main function
*
* @param  argc Number of arguments
* @param  argv The argument list
* @return 0 EXIT_SUCCESS
*/

int main(int argc, char **argv)
{
    if(argc !=3){
        printf("Usage:%s [mode] [port]\n", argv[0]);
        exit(-1);
    }
    port = atoi(argv[2]);
    portString = argv[2];
    cse4589_init_log(argv[2]);
    fclose(fopen(LOGFILE, "w"));
    if(argv[1][0] == 's'){
        serverFunction();
    }
    if(argv[1][0] == 'c'){
        clientFunction();
    }
}

void serverFunction(){
    int server_socket, head_socket, selret, sock_index, fdaccept=0, caddr_len;
    struct sockaddr_in client_addr;
    struct addrinfo hints, *res;
    fd_set master_list, watch_list;

    /* Set up hints structure */
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    /* Fill up address structures */
    if (getaddrinfo(NULL, std::to_string(port).c_str(), &hints, &res) != 0)
        perror("getaddrinfo failed");

    /* Socket */
    server_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if(server_socket < 0)
        perror("Cannot create socket");

    /* Bind */
    if(bind(server_socket, res->ai_addr, res->ai_addrlen) < 0 )
        perror("Bind failed");

    freeaddrinfo(res);

    /* Listen */
    if(listen(server_socket, BACKLOG) < 0)
        perror("Unable to listen on port");

    /* ---------------------------------------------------------------------------- */

    /* Zero select FD sets */
    FD_ZERO(&master_list);
    FD_ZERO(&watch_list);

    /* Register the listening socket */
    FD_SET(server_socket, &master_list);
    /* Register STDIN */
    FD_SET(STDIN, &master_list);

    head_socket = server_socket;

    while(TRUE){
        memcpy(&watch_list, &master_list, sizeof(master_list));

        //printf("\n[PA1-Server@CSE489/589]$ ");
        //fflush(stdout);

        /* select() system call. This will BLOCK */
        selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
        if(selret < 0)
            perror("select failed.");

        /* Check if we have sockets/STDIN to process */
        if(selret > 0){
            char addr[128];
            const char * userIP;
            /* Loop through socket descriptors to check which ones are ready */
            for(sock_index=0; sock_index<=head_socket; sock_index+=1){

                if(FD_ISSET(sock_index, &watch_list)){
                    /* Check if new command on STDIN */
                    if (sock_index == STDIN){
                        char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);

                        memset(cmd, '\0', CMD_SIZE);
                        if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to cmd
                            exit(-1);

                        printf("\nI got: %s\n", cmd);

                        //Process PA1 commands here ...
                        parseCommand(cmd);
                        free(cmd);
                    }

                        /* Check if new client is requesting connection */
                    else if(sock_index == server_socket){
                        caddr_len = sizeof(client_addr);
                        fdaccept = accept(server_socket, (struct sockaddr *)&client_addr, (socklen_t *)&caddr_len);
                        if(fdaccept < 0) {
                            perror("Accept failed.");
                        }
                        userIP = inet_ntop(AF_INET, &client_addr.sin_addr, addr, sizeof(addr));
                        loggedInUsers.push_back(userIP);
                        //save socket
                        socketList[userIP] = fdaccept;
                        struct hostent * host;
                        host = gethostbyaddr(&client_addr.sin_addr,sizeof(client_addr.sin_addr),AF_INET);
                        usersHostname.insert(std::make_pair(userIP,host->h_name));
                        if(usersPostsSent.find(userIP) == usersPostsSent.end()){
                            usersPostsSent.insert(std::make_pair(userIP, 0));
                        }
                        if(usersPostsReceived.find(userIP) == usersPostsReceived.end()){
                            usersPostsReceived.insert(std::make_pair(userIP,0));
                        }
                        if(usersBlockedList.find(userIP) == usersBlockedList.end()){
                            std::vector<std::string>* startingVector = new std::vector<std::string>();
                            usersBlockedList.insert(std::make_pair(userIP,startingVector));
                        }
                        usersPort.insert(std::make_pair(htons(client_addr.sin_port),userIP));
                        usersLoggedOn[userIP] = true;
                        //   printf("\nRemote Host connected!\n");
                        refreshList(userIP);
                        /* Add to watched socket list */
                        FD_SET(fdaccept, &master_list);
                        if(fdaccept > head_socket) head_socket = fdaccept;
                    }
                        /* Read from existing clients */
                    else{
                        /* Initialize buffer to receieve response */
                        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
                        memset(buffer, '\0', BUFFER_SIZE);
                        userIP = inet_ntop(AF_INET, &client_addr.sin_addr, addr, sizeof(addr));
                        if(recv(sock_index, buffer, BUFFER_SIZE, 0) <= 0){
                            close(sock_index);
                            //  printf("Remote Host terminated connection!\n");
                            auto loggedInIterator = std::find(loggedInUsers.begin(),loggedInUsers.end(),userIP);
                            if(loggedInIterator != loggedInUsers.end()){
                                loggedInUsers.erase(loggedInIterator);
                                usersLoggedOn[userIP] = false;
                            }
                            auto socketIterator = socketList.find(userIP);
                            if(socketIterator != socketList.end()){
                                socketList.erase(socketIterator);
                            }
                            /* Remove from watched list */
                            FD_CLR(sock_index, &master_list);
                        }
                        else {
                            //Process incoming data from existing clients here ...
                            parseIncoming(buffer,userIP);
                            //    printf("\nClient sent me: %s\n", buffer);
                            //      printf("ECHOing it back to the remote host ... [%s]",userIP);
                            //	if(send(fdaccept, buffer, strlen(buffer), 0) == strlen(buffer))
                            //		printf("Done!\n");
                            //	fflush(stdout);
                        }

                        free(buffer);
                    }
                }
            }
        }
    }
}

void clientFunction(){

    while(TRUE){
        printf("\n[PA1-Client@CSE489/589]$ ");
        //fflush(stdout);

        char *msg = (char*) malloc(sizeof(char)*MSG_SIZE);
        memset(msg, '\0', MSG_SIZE);
        if(fgets(msg, MSG_SIZE-1, stdin) == NULL) //Mind the newline character that will be written to msg
            exit(-1);

        //printf("I got: %s(size:%d chars)", msg, strlen(msg));
        parseMessage(msg);
        free(msg);
        // fflush(stdout);
        //printf("\nSENDing it to the remote server ... ");
        //if(send(server, msg, strlen(msg), 0) == strlen(msg))
        //	printf("Done!\n");

        /* Initialize buffer to receieve response */
        char *buffer = (char*) malloc(sizeof(char)*BUFFER_SIZE);
        memset(buffer, '\0', BUFFER_SIZE);

        if(recv(server, buffer, BUFFER_SIZE, 0) >= 0){
            parseInput(buffer);
            fflush(stdout);
            //		printf("Server responded: %s", buffer);
        }
        free(buffer);
    }
}
struct printClientList {
    int count = 1;

    void operator()(std::pair<int, std::string> users) {
        {
            std::string user = users.second;
            cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", count, usersHostname.at(user).c_str(), user.c_str(), users.first);
            count++;
        }
    }
};
void printBlocked(std::string ip, int port){
    cse4589_print_and_log("%-35s%-20s%-8d\n", usersHostname.at(ip).c_str(), ip.c_str(), port);
}
void relayMessage(std::string buffer,std::string userIP){
    for(auto iterator = socketList.begin();iterator != socketList.end(); iterator++) {
        std::string messageBuffer = "msg from:" + userIP + "\n[msg]:" + buffer + "\n";
        int socket = iterator->second;
        usersPostsSent[userIP] = usersPostsSent[userIP]+1;
        if(socket != socketList.at(userIP) && std::find(usersBlockedList.at(iterator->first)->begin(), usersBlockedList.at(iterator->first)->end(), userIP) == usersBlockedList.at(iterator->first)->end()) {
            usersPostsReceived[iterator->first] = usersPostsReceived[iterator->first]+1;
            if (send(socket, messageBuffer.c_str(), strlen(messageBuffer.c_str()), 0) == strlen(messageBuffer.c_str()))

                fflush(stdout);
        }
    }
}
void sendMessage(std::string userIP, std::string sendIP, std::string buffer) {
    std::string messageBuffer = "msg from:" + userIP +  "\n[msg]:" + buffer + "\n";
    //increment posts
    usersPostsSent[userIP] = usersPostsSent[userIP]+1;
    if(socketList.find(sendIP) != socketList.end() && std::find(usersBlockedList.at(sendIP)->begin(), usersBlockedList.at(sendIP)->end(), userIP) == usersBlockedList.at(sendIP)->end()) {
        //increment posts
        usersPostsReceived[sendIP] = usersPostsReceived[sendIP]+1;
        if (send(socketList.at(sendIP), messageBuffer.c_str(), strlen(messageBuffer.c_str()), 0) == strlen(messageBuffer.c_str())) {
            fflush(stdout);
        }
    }
}
void refreshList(std::string userIP){
    std::string list = "ADDLIST|";
    for(auto it = usersPort.begin(); it != usersPort.end(); it++) {
        if (usersLoggedOn.at(it->second)) {
            std::string ip = it->second;
            list += usersHostname.at(ip) + '|' + ip + '|' + std::to_string(it->first) + '|';
        }
    }
    if(socketList.find(userIP) != socketList.end()) {
        if (send(socketList.at(userIP), list.c_str(), strlen(list.c_str()), 0) == strlen(list.c_str()))
            //    printf("Done!\n");
            fflush(stdout);
    }
}
struct printList{
    int count = 1;
    void operator()(std::pair<int, std::string> users){
        {
            std::string user = users.second;
            if(usersLoggedOn.at(user)) {
                std::string user = users.second;
                cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", count, usersHostname.at(user).c_str(), user.c_str(), users.first);
                count++;
            }
        }
    }
};
struct printStats{
    int count = 1;
    void operator()(std::pair<int, std::string> users){
        {
            std::string user = users.second;
            char* status;
            if(usersLoggedOn.at(user)){
                status = "logged-in";
            }
            else{
                status = "logged-out";
            }
            cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", count, usersHostname.at(user).c_str(), usersPostsSent.at(user), usersPostsReceived.at(user), status);
            count++;
        }
    }
};

int parseMessage(char *message) {
    std::string buffer = std::string(message);
    if (buffer.find("AUTHOR") != std::string::npos && buffer.find("AUTHOR") < buffer.find(" ")) {
        //Mukul add UBIT
        char *ubit = "wogreen&mukuljes";
        cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
        cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", ubit);
        cse4589_print_and_log("[%s:END]\n", "AUTHOR");
    }
    if (buffer.find("LIST") != std::string::npos && buffer.find("LIST") < buffer.find(" ")) {
        cse4589_print_and_log("[%s:SUCCESS]\n", "LIST");
        std::for_each(usersPort.begin(), usersPort.end(), printClientList());
        cse4589_print_and_log("[%s:END]\n", "LIST");
    }
    if (buffer.find("LOGIN") != std::string::npos && buffer.find("LOGIN") < buffer.find(" ")) {
        if (buffer.find_first_of(" ") != std::string::npos) {
            if (buffer.find_last_of(" ") != buffer.find_first_of(" ")) {
                std::string ipWithPort = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                std::string port = ipWithPort.substr(ipWithPort.find_first_of(" ") + 1, ipWithPort.size()-1);
                //remove newline
                port.pop_back();
                std::string ip = ipWithPort.substr(0,ipWithPort.find(" "));
                server = connect_to_host(ip.c_str(),port.c_str());
                return 1;
            }
            cse4589_print_and_log("[%s:ERROR]\n", "LOGIN");
            cse4589_print_and_log("[%s:END]\n", "LOGIN");
            return -1;
        }
    }
    if(buffer.find("REFRESH") != std::string::npos && buffer.find("REFRESH") < buffer.find(" ")){
        if(send(server, buffer.c_str(), strlen(buffer.c_str()), 0) == strlen(buffer.c_str())){
            cse4589_print_and_log("[%s:SUCCESS]\n", "REFRESH");
            cse4589_print_and_log("[%s:END]\n", "REFRESH");
            return 1;
        }
        else{
            cse4589_print_and_log("[%s:ERROR]\n", "REFRESH");
            cse4589_print_and_log("[%s:END]\n", "REFRESH");
        }
    }
    if(buffer.find("SEND") != std::string::npos && buffer.find("SEND") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") != buffer.find_first_of(" ")) {
                std::string ipWithBuffer = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                std::string ip = ipWithBuffer.substr(0,ipWithBuffer.find(" "));
                if(buffer.size() > 256){
                    cse4589_print_and_log("[%s:ERROR]\n", "SEND");
                    cse4589_print_and_log("[%s:END]\n", "SEND");
                    return -1;
                }
                //check if ip is valid

                if(std::find(loggedInUsers.begin(), loggedInUsers.end(), ip) != loggedInUsers.end()){
                    if(send(server, buffer.c_str(), strlen(buffer.c_str()), 0) == strlen(buffer.c_str())) {
                        fflush(stdout);
                        cse4589_print_and_log("[%s:SUCCESS]\n", "SEND");
                        cse4589_print_and_log("[%s:END]\n", "SEND");
                    }
                    else {
                        cse4589_print_and_log("[%s:ERROR]\n", "SEND");
                        cse4589_print_and_log("[%s:END]\n", "SEND");
                        return -1;
                    }
                }
                else{
                    cse4589_print_and_log("[%s:ERROR]\n", "SEND");
                    cse4589_print_and_log("[%s:END]\n", "SEND");
                    return -1;
                }
            }
        }
    }
    if(buffer.find("BROADCAST") != std::string::npos && buffer.find("BROADCAST") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string sentBuffer = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                if(sentBuffer.size() > 256){
                    cse4589_print_and_log("[%s:ERROR]\n", "BROADCAST");
                    cse4589_print_and_log("[%s:END]\n", "BROADCAST");
                    return -1;
                }
                if(send(server, buffer.c_str(), strlen(buffer.c_str()), 0) == strlen(buffer.c_str())){
                    fflush(stdout);
                    cse4589_print_and_log("[%s:SUCCESS]\n", "BROADCAST");
                    cse4589_print_and_log("[%s:END]\n", "BROADCAST");
                }
                else{
                    cse4589_print_and_log("[%s:ERROR]\n", "BROADCAST");
                    cse4589_print_and_log("[%s:END]\n", "BROADCAST");
                    return -1;
                }
            }
        }
        cse4589_print_and_log("[%s:ERROR]\n", "BROADCAST");
        cse4589_print_and_log("[%s:END]\n", "BROADCAST");
        return -1;
    }
    if(buffer.find("EXIT") != std::string::npos && buffer.find("EXIT") < buffer.find(" ")){
        serverExit();
        return 1;
    }
    if(buffer.find("LOGOUT") != std::string::npos && buffer.find("LOGOUT") < buffer.find(" ")){
        serverLogout();
        return 1;
    }
    if(buffer.find("UNBLOCK") != std::string::npos && buffer.find("UNBLOCK") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string ip = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                //delete newline character
                ip.pop_back();
                //if ip valid
                if(!validIP(ip)){
                    cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
                    cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
                    return -1;
                }
                if(send(server, buffer.c_str(), strlen(buffer.c_str()), 0) == strlen(buffer.c_str())){
                    fflush(stdout);
                    cse4589_print_and_log("[%s:SUCCESS]\n", "UNBLOCK");
                    cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
                }
                else{
                    cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
                    cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
                    return -1;
                }
            }
        }
        cse4589_print_and_log("[%s:ERROR]\n", "UNBLOCK");
        cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
        return -1;
    }
    if(buffer.find("BLOCK") != std::string::npos && buffer.find("BLOCK") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string ip = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                //delete newline character
                ip.pop_back();
                //check if valid ip
                if(!validIP(ip)){
                    cse4589_print_and_log("[%s:ERROR]\n", "BLOCK");
                    cse4589_print_and_log("[%s:END]\n", "BLOCK");
                    return -1;
                }
                if(send(server, buffer.c_str(), strlen(buffer.c_str()), 0) == strlen(buffer.c_str())){
                    fflush(stdout);
                    cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCK");
                    cse4589_print_and_log("[%s:END]\n", "BLOCK");
                    return 1;
                }
                else{
                    cse4589_print_and_log("[%s:ERROR]\n", "BLOCK");
                    cse4589_print_and_log("[%s:END]\n", "BLOCK");
                    return -1;
                }
            }
        }
        cse4589_print_and_log("[%s:ERROR]\n", "BLOCK");
        cse4589_print_and_log("[%s:END]\n", "BLOCK");
        return -1;
    }

    if(buffer.find("IP") != std::string::npos && buffer.find("IP") < buffer.find(" ")){
        getIPAddress();
        return 1;
    }
    if(buffer.find("PORT") != std::string::npos && buffer.find("PORT") < buffer.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n","PORT");
        cse4589_print_and_log("[%PORT:]\n", portString);
        cse4589_print_and_log("[%s:END]\n", "PORT");
        return 1;
    }
    return 1;
}
int parseCommand(char* bufferString){
    std::string buffer = std::string(bufferString);
    if(buffer.find("AUTHOR") != std::string::npos && buffer.find("AUTHOR") < buffer.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
        char* ubit = "wogreen&mukuljes";
        cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", ubit);
        cse4589_print_and_log("[%s:END]\n", "AUTHOR");
    }
    if(buffer.find("LIST") != std::string::npos && buffer.find("LIST") < buffer.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n", "LIST");
        std::for_each(usersPort.begin(),usersPort.end(), printList());
        cse4589_print_and_log("[%s:END]\n", "LIST");
    }
    if(buffer.find("STATISTICS") != std::string::npos && buffer.find("STATISTICS") < buffer.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n", "STATISTICS");
        std::for_each(usersPort.begin(),usersPort.end(), printStats());
        cse4589_print_and_log("[%s:END]\n", "STATISTICS");
    }
    if(buffer.find("BLOCKED") != std::string::npos && buffer.find("BLOCKED") < buffer.find(" ")){
        const char* blockedIP;
        if(buffer.find_first_of(" ") != std::string::npos){
            //if equal, means that we substr to end of buffer.
            if(buffer.find_last_of(" ") == buffer.find_first_of(" ")){
                std::string ip  =buffer.substr(buffer.find_first_of(" ")+1,buffer.size()-1);
                //delete newline character
                ip.pop_back();
                blockedIP = ip.c_str();
                std::vector<std::string> *users;
                try {
                    users = usersBlockedList.at(blockedIP);
                }
                catch(const std::out_of_range& oor){
                    cse4589_print_and_log("[%s:ERROR]\n", "BLOCKED");
                    cse4589_print_and_log("[%s:END]\n", "BLOCKED");
                    return -1;
                }
                for(auto it = usersPort.begin(); it != usersPort.end(); it++){
                    cse4589_print_and_log("[%s:SUCCESS]\n", "BLOCKED");
                    auto location = std::find(users->begin(),users->end(),it->second);
                    if(location != users->end()){
                        std::string ip = *location;
                        printBlocked(ip,it->first);
                    }
                }
                cse4589_print_and_log("[%s:END]\n", "BLOCKED");
                return 1;
            }
        }
        cse4589_print_and_log("[%s:ERROR]\n", "BLOCKED");
        cse4589_print_and_log("[%s:END]\n", "BLOCKED");
        return -1;
    }
    if(buffer.find("IP") != std::string::npos && buffer.find("IP") < buffer.find(" ")){
        getIPAddress();
        return 1;
    }
    if(buffer.find("PORT") != std::string::npos && buffer.find("PORT") < buffer.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n","PORT");
        cse4589_print_and_log("[PORT:%s]\n", portString);
        cse4589_print_and_log("[%s:END]\n", "PORT");
        return 1;
    }
}

int parseIncoming(char* bufferString,std::string userIP){
    std::string buffer = std::string(bufferString);
    if(buffer.find("BLOCK") != std::string::npos && buffer.find("BLOCK") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string ip = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                //delete newline character
                ip.pop_back();
                auto position = std::find(loggedInUsers.begin(),loggedInUsers.end(),ip);
                if(position == loggedInUsers.end()){
                    return -1;
                }else{
                    std::vector<std::string> *blockedUsers = usersBlockedList.at(userIP);
                    //TODO: CHECK IF blockedUsers contains IP
                    if(std::find(blockedUsers->begin(), blockedUsers->end(), ip) == blockedUsers->end()) {
                        blockedUsers->push_back(ip);
                        usersBlockedList[userIP] = blockedUsers;
                        return 1;
                    }
                }
            }
        }
    }
    if(buffer.find("BROADCAST") != std::string::npos && buffer.find("BROADCAST") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string sentBuffer = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                if(sentBuffer.size() > 256){
                    return -1;
                }
                relayMessage(sentBuffer, userIP);
                cse4589_print_and_log("[%s:SUCCESS]\n","RELAYED");
                cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",userIP.c_str(),"255.255.255.255",sentBuffer.c_str());
                cse4589_print_and_log("[%s:END]\n","RELAYED");
                return 1;
            }
        }
        return -1;
    }
    if(buffer.find("REFRESH") != std::string::npos && buffer.find("REFRESH") < buffer.find(" ")){
        refreshList(userIP);
    }
    if(buffer.find("SEND") != std::string::npos && buffer.find("SEND") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") != buffer.find_first_of(" ")) {
                std::string ipWithBuffer = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                std::string sendBuffer = ipWithBuffer.substr(ipWithBuffer.find_first_of(" ") + 1, ipWithBuffer.size()-1);
                std::string ip = ipWithBuffer.substr(0,ipWithBuffer.find(" "));
                if(sendBuffer.size() > 256){
                    return -1;
                }
                sendMessage(userIP,ip, sendBuffer);
                cse4589_print_and_log("[%s:SUCCESS]\n","RELAYED");
                cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",userIP.c_str(),ip.c_str(),sendBuffer.c_str());
                cse4589_print_and_log("[%s:END]\n","RELAYED");
                return 1;
            }
        }
        return -1;
    }
    if(buffer.find("UNBLOCK") != std::string::npos && buffer.find("UNBLOCK") < buffer.find(" ")){
        if(buffer.find_first_of(" ") != std::string::npos) {
            //if equal, means that we substr to end of buffer.
            if (buffer.find_last_of(" ") == buffer.find_first_of(" ")) {
                std::string ip = buffer.substr(buffer.find_first_of(" ") + 1, buffer.size() - 1);
                //delete newline character
                ip.pop_back();
                auto position = std::find(loggedInUsers.begin(),loggedInUsers.end(),ip);
                if(position == loggedInUsers.end()){
                    return -1;
                }else{
                    std::vector<std::string> *blockedUsers = usersBlockedList.at(userIP);
                    if(std::find(blockedUsers->begin(), blockedUsers->end(), ip) != blockedUsers->end()){
                        std::remove(blockedUsers->begin(), blockedUsers->end(), ip);
                        cse4589_print_and_log("[%s:SUCCESS]\n","UNBLOCK");
                        cse4589_print_and_log("[%s:END]\n", "UNBLOCK");
                        return 1;
                    }else {
                        return -1;
                    }
                }
            }
        }
        return -1;
    }
}
void serverExit() {
    close(server);
    cse4589_print_and_log("[%s:SUCCESS]\n","EXIT");
    cse4589_print_and_log("[%s:END]\n", "EXIT");
    exit(0);
}
void serverLogout() {
    shutdown(server,SHUT_RD);
    cse4589_print_and_log("[%s:SUCCESS]\n","LOGOUT");
    cse4589_print_and_log("[%s:END]\n", "LOGOUT");
}
void getIPAddress() {
    // const char google[] = "8.8.8.8";
    const char *google = "8.8.8.8";
    char addr[128];
    struct sockaddr_in sock_address;
    int sockfd;
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    sock_address.sin_family = AF_INET;
    sock_address.sin_port = htons(53);
    sock_address.sin_addr.s_addr = inet_addr(google);
    int error = connect(sockfd, (struct sockaddr *) &sock_address, sizeof(sock_address));
    if (error < 0) {
        cse4589_print_and_log("[%s:ERROR]\n","IP");
        cse4589_print_and_log("[%s:END]\n", "IP");
        return;
    }
    socklen_t length = sizeof(sock_address);
    getsockname(sockfd, (struct sockaddr *) &sock_address, &length);
    const char *ip = inet_ntop(AF_INET, &sock_address.sin_addr, addr, sizeof(addr));
    close(sockfd);
    struct in_addr myIp;
    if (!inet_aton(ip, &myIp)) {
        cse4589_print_and_log("[%s:ERROR]\n","IP");
        cse4589_print_and_log("[%s:END]\n", "IP");
        return;
    }
    cse4589_print_and_log("[%s:SUCCESS]\n", "IP");
    cse4589_print_and_log("IP:%s\n", ip);
    cse4589_print_and_log("[%s:END]\n", "IP");
    return;
}

int parseInput(char *buffer) {
    std::string bufferString = std::string(buffer);
    if (bufferString.find("msg") != std::string::npos && bufferString.find("msg") < bufferString.find(" ")){
        cse4589_print_and_log("[%s:SUCCESS]\n","RECEIVED");
        cse4589_print_and_log(bufferString.c_str());
        cse4589_print_and_log("[%s:END]\n","RECEIVED");
    }
    if (bufferString.find("ADDLIST") != std::string::npos &&
        bufferString.find("ADDLIST") < bufferString.find(" ")) {
        loggedInUsers.erase(loggedInUsers.begin(), loggedInUsers.end());
        std::string list = bufferString.substr(bufferString.find_first_of("|") + 1, bufferString.size() - 1);
        int count = 3;
        std::string hostname;
        std::string port;
        std::string ip;
        while (list.find('|') != std::string::npos) {
            std::string listData = list.substr(0, list.find('|'));
            if (count == 0) {
                //completed one iteration.
                usersPort[std::stoi(port)] = ip;
                loggedInUsers.push_back(ip);
                usersHostname[ip] = hostname;
                count = 3;
            }
            if (count == 3) {
                //listData is hostname
                hostname = listData;


            }
            if (count == 2) {
                //listData is ip
                ip = listData;

            }
            if (count == 1) {
                //listData is port
                port = listData;
            }
            list = list.substr(list.find_first_of('|') + 1, list.size() - 1);
            count -= 1;
        }
        //last iteration
        usersPort[std::stoi(port)] = ip;
        loggedInUsers.push_back(ip);
        usersHostname[ip] = hostname;
    }
}

int connect_to_host(const char *server_ip, const char *server_port) {
    int fdsocket;
    struct addrinfo hints, *res;
    struct sockaddr_in desiredAddress;

    /* Set up hints structure */
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    /* Fill up address structures */
    if (getaddrinfo(server_ip, server_port, &hints, &res) != 0) {
        perror("getaddrinfo failed");
        cse4589_print_and_log("[%s:ERROR]\n","LOGIN");
        cse4589_print_and_log("[%s:END]\n", "LOGIN");
        return -1;
    }

    /* Socket */
    fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    desiredAddress.sin_family = AF_INET;
    desiredAddress.sin_addr.s_addr = INADDR_ANY;
    desiredAddress.sin_port = htons(port);
    if (fdsocket < 0){
        perror("Failed to create socket");
        cse4589_print_and_log("[%s:ERROR]\n","LOGIN");
        cse4589_print_and_log("[%s:END]\n", "LOGIN");
        return -1;
    }

    if (bind(fdsocket, (struct sockaddr*) &desiredAddress, sizeof(struct sockaddr_in)) == 0) {

    }
    else{
        cse4589_print_and_log("[%s:ERROR]\n","LOGIN");
        cse4589_print_and_log("[%s:END]\n", "LOGIN");
        return -1;
    }
    /* Connect */
    if (connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0) {
        perror("Connect failed");
        cse4589_print_and_log("[%s:ERROR]\n","LOGIN");
        cse4589_print_and_log("[%s:END]\n", "LOGIN");
        return -1;
    }
    freeaddrinfo(res);
    cse4589_print_and_log("[%s:SUCCESS]\n","LOGIN");
    cse4589_print_and_log("[%s:END]\n", "LOGIN");
    return fdsocket;
}

bool validIP(std::string ip) {
    struct sockaddr_in sock_address;
    int check = inet_pton(AF_INET, ip.c_str(), &(sock_address.sin_addr));
    if(check != 0) {
        return true;
    }
    else {
        return false;
    }
}