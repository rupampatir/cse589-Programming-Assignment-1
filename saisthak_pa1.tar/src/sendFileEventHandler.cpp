#include "../include/base.h"

using namespace std;

SendFileEventHandler::SendFileEventHandler() {

}

void
SendFileEventHandler::handleClientSideEvent(int clientListeningFd, HostInfo* hostinfo) {
    int addrlen, newfd;
    struct sockaddr_in remoteaddr;
    addrlen = sizeof(remoteaddr);
    newfd = accept(clientListeningFd, (struct sockaddr*)&remoteaddr, (socklen_t*)&addrlen);
    if(newfd < 0) {
        cerr<<"Error while accepting new connection";
        exit(1);
    } 

    char fileNameCommand[1024];
    bzero(&fileNameCommand,sizeof(fileNameCommand));
    recv(newfd, fileNameCommand, sizeof(fileNameCommand),0); 
    char* commandName = strtok(fileNameCommand," ");
    char* fileName = strtok(NULL,"");
    
    char buf[500000];
    bzero(&buf,sizeof(buf));
    recv(newfd, buf, sizeof(buf),0); 

    int fileFlags = O_RDWR | O_TRUNC | O_DIRECT | O_CREAT;
    mode_t mode = 0755;
    int fdID = open(fileName, fileFlags, mode);
    close(fdID);

    ofstream file(fileName, ios::out | ios::binary | ios::trunc);
    while(strlen(buf)>0) {
        if((strlen(buf) + 1) < sizeof(buf)) 
            file.write(buf, strlen(buf));
        else 
            file.write(buf, sizeof(buf));

        bzero(&buf,sizeof(buf));
        recv(newfd, buf, sizeof(buf),0); 
    }

    file.close();
    close(newfd);
}