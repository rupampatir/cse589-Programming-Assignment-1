#include "../include/base.h"
using namespace std;

Server::Server(char* port) {
    char* hostName = getHostName();
	char* ipAddr = getIPAddr();
    strcpy(info.portNum, port);
    strcpy(info.hostName, hostName);
    strcpy(info.ipAddr, ipAddr);
    info.isClient = false;
    info.isServer = true;
    initializeServerListeningSocket(&info, &serverMetaData);

    CommandProcessor* commandProcessor = new CommandProcessor();
    loginRequestEventHandler = new LoginRequestEventHandler();
    eventProcessor = new EventProcessor();
    int fdmax = serverMetaData.listenerFd;
    int nbytes, newfd;
    char buf[1024];
    char msg[1024];
    struct sockaddr_in remoteaddr;
    while(true) {
        serverMetaData.read_fds = serverMetaData.master;
        int selectStatus = select(fdmax+1, &serverMetaData.read_fds, NULL, NULL, NULL);
        if(selectStatus < 0) {
            cerr<<"Error while performing select\n";
            exit(1);
        }
        
        for(int i = 0; i<= fdmax; i++) {
            if (FD_ISSET(i, &serverMetaData.read_fds)) {
                if(i == STD_IN) { 
                    memset((void *)&buf,'\0',sizeof(buf));
                    read(STD_IN,buf,1024);
                    buf[strlen(buf)-1]='\0';
                    commandProcessor->handleServerCommands(buf, &info, &serverMetaData);
                } else if (i == serverMetaData.listenerFd) { 
                    newfd = loginRequestEventHandler->handleServerSideEvent(&info, &serverMetaData);
                    FD_SET(newfd, &serverMetaData.master);
                    if(newfd > fdmax) 
                        fdmax = newfd;
                } else {
                    bzero(&msg,sizeof(msg));
                    if ((nbytes = recv(i, msg, sizeof(msg), 0)) <= 0) {
                        if (nbytes == 0) {
                            for(vector<ClientSocketInfo>::iterator itr = serverMetaData.clientInfos.begin();itr != serverMetaData.clientInfos.end();++itr){
                                if(itr->fd == i){                                
                                    strcpy(itr->status,"logged-out");
                                    close(i); 
                                    FD_CLR(i, &serverMetaData.master);
                                }
                            }
                        } 
                    } else {
                        eventProcessor->handleServerEvents(i, msg, &info, &serverMetaData);
                    }
                }
            }
        }

    }
}
