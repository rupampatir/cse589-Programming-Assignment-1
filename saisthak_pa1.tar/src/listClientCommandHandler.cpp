#include "../include/base.h"

using namespace std;

ListClientCommandHandler::ListClientCommandHandler() {

}

bool comparatorPIByPortNum(PeerInfo pi1,PeerInfo pi2){
  return pi1.portNum < pi2.portNum;
}

void 
ListClientCommandHandler::handle(HostInfo* hostinfo){
    sort(hostinfo->peerinfos.begin(), hostinfo->peerinfos.end(), comparatorPIByPortNum);
    cse4589_print_and_log("[LIST:SUCCESS]\n");
    int i = 0;
    for(vector<PeerInfo>::iterator itr = hostinfo->peerinfos.begin();itr != hostinfo->peerinfos.end();++itr){
      cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", 
                              ++i, 
                              itr->hostName, 
                              itr->ipAddr, 
                              itr->portNum);
    }
    cse4589_print_and_log("[LIST:END]\n");
}

void 
ListClientCommandHandler::handle(HostInfo* hostinfo, ServerMetaData* serverMetaData){
    vector<ClientSocketInfo> clientInfos = serverMetaData->clientInfos;
    sort(clientInfos.begin(), clientInfos.end(), comparatorCSByPortNum);
    cse4589_print_and_log("[LIST:SUCCESS]\n");
    int i = 0;
    for(vector<ClientSocketInfo>::iterator itr = clientInfos.begin();itr != clientInfos.end();++itr){
      if(strcmp(itr->status, "logged-in") == 0) {
        cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", 
                                  ++i,
                                  itr->hostName,
                                  itr->ipAddr,
                                  itr->portNum);
      }
    }
    cse4589_print_and_log("[LIST:END]\n");
}

