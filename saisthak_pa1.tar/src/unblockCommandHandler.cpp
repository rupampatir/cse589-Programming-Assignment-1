#include "../include/base.h"

using namespace std;

UnblockCommandHandler::UnblockCommandHandler() {

}

void 
UnblockCommandHandler::handle(char* command, HostInfo* hostinfo, int serverFd){
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    char *commandName = strtok(command," "); 
    char *receiverIpAddr = strtok(NULL," "); 

    if(!isValidIPAddressWithPort(receiverIpAddr,80)){
        printError();
        return;
    }


    if(!hostinfo->isValidPeer(receiverIpAddr)) {
        printError();
        return; 
    }

    if(!hostinfo->isBlocked(receiverIpAddr)) {
      printError();
      return;
    }

    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf,"UNBLOCK ");
    strcat(buf, receiverIpAddr);

    if(send(serverFd,buf,strlen(buf),0)<0) {
        printError();
        return;
    }
    
    hostinfo->markUnblocked(receiverIpAddr);
    printSuccess();
}

void
UnblockCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","UNBLOCK");
  cse4589_print_and_log("[%s:END]\n","UNBLOCK");
}

void 
UnblockCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","UNBLOCK");
  cse4589_print_and_log("[%s:END]\n","UNBLOCK");
}