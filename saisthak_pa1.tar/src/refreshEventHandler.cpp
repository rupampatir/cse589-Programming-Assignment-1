#include "../include/base.h"

using namespace std;

RefreshEventHandler::RefreshEventHandler() {

}

void
RefreshEventHandler::handleServerSideEvent(int senderFd, HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    char refreshResponse[4096];
    bzero(&refreshResponse,sizeof(refreshResponse));
    strcat(refreshResponse,"LOGIN ");
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin(); itr != serverMetaData->clientInfos.end(); ++itr) {
        if(strcmp(itr->status,"logged-in") == 0){
            strcat(refreshResponse,itr->hostName);
            strcat(refreshResponse," ");
            strcat(refreshResponse,itr->ipAddr);
            strcat(refreshResponse," ");

            char pn[8];
            bzero(&pn,sizeof(pn));
            snprintf(pn, sizeof(pn), "%d", itr->portNum);
            strcat(refreshResponse,pn);
            strcat(refreshResponse," ");
        }
    }
    send(senderFd,refreshResponse,strlen(refreshResponse),0);
}