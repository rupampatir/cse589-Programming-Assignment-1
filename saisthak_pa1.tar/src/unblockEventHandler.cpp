#include "../include/base.h"

using namespace std;

UnBlockEventHandler::UnBlockEventHandler() {

}

void 
UnBlockEventHandler::handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    ClientSocketInfo* senderSocketInfo;
    for(int i = 0; i<= serverMetaData->clientInfos.size(); i++) {
        if(serverMetaData->clientInfos[i].fd == senderFd) {
            senderSocketInfo = &(serverMetaData->clientInfos[i]);
            break;
        }
    }

    char *eventName = strtok(eventData," "); 
    char *toBeUnblockedIpAddr = strtok(NULL," "); // To be unblocked ip address
    vector<BlockedHostInfo>::iterator itr = senderSocketInfo->blockedInfos.begin();
    while(itr!=senderSocketInfo->blockedInfos.end()) {
        if(strcmp(itr->ipAddr, toBeUnblockedIpAddr) == 0) {
            itr = senderSocketInfo->blockedInfos.erase(itr);
            break;
        } else {
            ++itr;
        }
    }
}


