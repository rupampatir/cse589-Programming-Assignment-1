#include "../include/base.h"

using namespace std;

LogoutCommandHandler::LogoutCommandHandler() {

}

void 
LogoutCommandHandler::handle(HostInfo* hostinfo, int serverFd) {
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    close(serverFd);
    hostinfo->isLoggedIn=false;
    printSuccess();
}

void
LogoutCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","LOGOUT");
  cse4589_print_and_log("[%s:END]\n","LOGOUT");
}

void 
LogoutCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","LOGOUT");
  cse4589_print_and_log("[%s:END]\n","LOGOUT");
}