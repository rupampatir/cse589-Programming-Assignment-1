#include "../include/base.h"

using namespace std;

StatisticsCommandHandler::StatisticsCommandHandler() {

}

bool comparatorCSByPortNum(ClientSocketInfo csi1,ClientSocketInfo csi2){
  return csi1.portNum < csi2.portNum;
}

void 
StatisticsCommandHandler::handle(ServerMetaData* serverMetaData){
    vector<ClientSocketInfo> clientInfos = serverMetaData->clientInfos;
    sort(clientInfos.begin(), clientInfos.end(), comparatorCSByPortNum);
    cse4589_print_and_log("[STATISTICS:SUCCESS]\n");
    int i = 0;
    for(vector<ClientSocketInfo>::iterator itr = clientInfos.begin();itr != clientInfos.end();++itr){
      cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",
                                ++i,
                                itr->hostName,
                                itr->sentMsgCount,
                                itr->receivedMsgCount,
                                itr->status);
    }
    cse4589_print_and_log("[STATISTICS:END]\n");
}

