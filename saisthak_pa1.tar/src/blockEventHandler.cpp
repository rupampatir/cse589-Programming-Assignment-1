#include "../include/base.h"

using namespace std;

BlockEventHandler::BlockEventHandler() {

}

void 
BlockEventHandler::handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    ClientSocketInfo* senderSocketInfo;
    for(int i = 0; i<= serverMetaData->clientInfos.size(); i++) {
        if(serverMetaData->clientInfos[i].fd == senderFd) {
            senderSocketInfo = &(serverMetaData->clientInfos[i]);
            break;
        }
    }

    char *eventName = strtok(eventData," "); 
    char *toBeBlockedIpAddr = strtok(NULL," "); // To be blocked ip address
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin();itr != serverMetaData->clientInfos.end();++itr){
        if(strcmp(itr->ipAddr,toBeBlockedIpAddr) == 0) {
            BlockedHostInfo blockedHostInfo;
            bzero(&blockedHostInfo.ipAddr,sizeof(blockedHostInfo.ipAddr));
            bzero(&blockedHostInfo.hostName,sizeof(blockedHostInfo.hostName));

            strcpy(blockedHostInfo.ipAddr, itr->ipAddr);
            strcpy(blockedHostInfo.hostName, itr->hostName);
            blockedHostInfo.portNum = itr->portNum;
            
            senderSocketInfo->blockedInfos.push_back(blockedHostInfo);
        }
    }
}


