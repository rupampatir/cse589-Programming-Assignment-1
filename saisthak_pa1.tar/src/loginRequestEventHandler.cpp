#include "../include/base.h"

using namespace std;

LoginRequestEventHandler::LoginRequestEventHandler() {
    sendMessageEventHandler = new SendMessageEventHandler();
}
void
LoginRequestEventHandler::handleClientSideEvent(char* eventData, HostInfo* hostinfo) {
    char* splittedData = strtok(eventData, " ");
    char* nextData = strtok(NULL, " ");
    hostinfo->peerinfos.clear();
    while(nextData != NULL) {
        char* peerHostname = nextData;
        char* peerIp = strtok(NULL, " ");
        char* peerPort = strtok(NULL, " ");
        PeerInfo peerInfo; 
        strcpy(peerInfo.hostName, peerHostname);
        strcpy(peerInfo.ipAddr, peerIp);
        peerInfo.portNum = atoi(peerPort);
        hostinfo->peerinfos.push_back(peerInfo);
        nextData = strtok(NULL, " ");
    }

    if(!hostinfo->isLoggedIn) {
        cse4589_print_and_log("[%s:SUCCESS]\n","LOGIN");
        cse4589_print_and_log("[%s:END]\n","LOGIN");
        hostinfo->isLoggedIn = true; 
    }
}

int
LoginRequestEventHandler::handleServerSideEvent(HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    int addrlen, newfd;
    struct sockaddr_in remoteaddr;
    addrlen = sizeof(remoteaddr);
    newfd = accept(serverMetaData->listenerFd, (struct sockaddr*)&remoteaddr, (socklen_t*)&addrlen);

    if(newfd < 0) {
        cerr<<"Error while accepting new connection";
        exit(1);
    } 

    ClientSocketInfo newClientSocketInfo = getSocketInfo(newfd, (struct sockaddr_in*)&remoteaddr);
    bool isNewClient = true;
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin(); itr != serverMetaData->clientInfos.end(); ++itr) {
        if((strcmp(newClientSocketInfo.ipAddr, itr->ipAddr) == 0) && (newClientSocketInfo.portNum == itr->portNum)){
            strcpy(itr->status, "logged-in");
            itr->fd = newfd;
            isNewClient = false;
        }
    }

    if(isNewClient) { 
        serverMetaData->clientInfos.push_back(newClientSocketInfo);
    }

    char loginResponse[4096];
    bzero(&loginResponse,sizeof(loginResponse));
    strcat(loginResponse,"LOGIN ");
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin(); itr != serverMetaData->clientInfos.end(); ++itr) {
        if(strcmp(itr->status,"logged-in") == 0){
            strcat(loginResponse,itr->hostName);
            strcat(loginResponse," ");
            strcat(loginResponse,itr->ipAddr);
            strcat(loginResponse," ");

            char pn[8];
            bzero(&pn,sizeof(pn));
            snprintf(pn, sizeof(pn), "%d", itr->portNum);
            strcat(loginResponse,pn);
            strcat(loginResponse," "); 
        }
    }

    sendMessageEventHandler->sendBufferedMessage(newfd, serverMetaData);
    send(newfd,loginResponse,strlen(loginResponse),0);
    return newfd;
}