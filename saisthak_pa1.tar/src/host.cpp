#include "../include/base.h"

using namespace std;

Host::Host() {
  // No initialization required
}

