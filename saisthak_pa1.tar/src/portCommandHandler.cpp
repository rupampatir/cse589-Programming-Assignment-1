#include "../include/base.h"

using namespace std;

PortCommandHandler::PortCommandHandler() {

}

void 
PortCommandHandler::handle(HostInfo* hostinfo) {
    cse4589_print_and_log("[PORT:SUCCESS]\n");
    cse4589_print_and_log("PORT:%s\n",hostinfo->portNum);
    cse4589_print_and_log("[PORT:END]\n");
}