#include "../include/base.h"

using namespace std;

SendMessageEventHandler::SendMessageEventHandler() {

}

void 
SendMessageEventHandler::handleClientSideEvent(char* eventData, HostInfo* hostinfo) {
    cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
    char *eventName = strtok(eventData," "); 
    char *senderIpAddr = strtok(NULL," "); 
    char *receiverIpAddr = strtok(NULL," "); 
    char *message = strtok(NULL,"");
    cse4589_print_and_log("msg from:%s\n[msg]:%s\n",senderIpAddr,message);
    cse4589_print_and_log("[%s:END]\n", "RECEIVED");
}

void 
SendMessageEventHandler::handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData, bool printRelayLogs) {
    char *eventName = strtok(eventData," "); 
    char *receiverIpAddr = strtok(NULL," "); 
    char *message = strtok(NULL,"");

    ClientSocketInfo *senderSocketInfo;
    ClientSocketInfo *receiverSocketInfo;


    for(int i = 0; i<= serverMetaData->clientInfos.size(); i++) {
        if(serverMetaData->clientInfos[i].fd == senderFd) {
            senderSocketInfo = &(serverMetaData->clientInfos[i]);
            continue;
        }

        if(strcmp(serverMetaData->clientInfos[i].ipAddr, receiverIpAddr) == 0) {
            receiverSocketInfo = &(serverMetaData->clientInfos[i]);
            continue;
        }

    }

    senderSocketInfo->sentMsgCount++;
    char relayMessage[1024];
    bzero(&relayMessage,sizeof(relayMessage));
    strcat(relayMessage,"SEND ");
    strcat(relayMessage, senderSocketInfo->ipAddr);
    strcat(relayMessage," ");
    strcat(relayMessage, receiverSocketInfo->ipAddr);
    strcat(relayMessage," ");
    strcat(relayMessage,message);



    bool isBlocked = isSenderBlocked(senderSocketInfo->ipAddr, receiverSocketInfo);
    bool isReceiverLoggedIn = (strcmp(receiverSocketInfo->status, "logged-in") == 0);

    if(isBlocked){ 
        return;
    }

    if(isReceiverLoggedIn) {
        send(receiverSocketInfo->fd,relayMessage,strlen(relayMessage),0);
        receiverSocketInfo->receivedMsgCount++;
        if(printRelayLogs){
            printSuccess(relayMessage);
        }
        return;
    }

    BufferedMessageInfo bufferedMessageInfo;
    bzero(&bufferedMessageInfo.message,sizeof(bufferedMessageInfo.message));
    strcpy(bufferedMessageInfo.message, relayMessage);
    receiverSocketInfo->bufferedMessages.push(bufferedMessageInfo);

}

bool
SendMessageEventHandler::isSenderBlocked(char* senderIpAddr, ClientSocketInfo* receiverSocketInfo) {
    for(vector<BlockedHostInfo>::iterator itr = receiverSocketInfo->blockedInfos.begin(); itr != receiverSocketInfo->blockedInfos.end(); ++itr) {
        if(strcmp(itr->ipAddr, senderIpAddr) == 0) {
            return true;
        }
    }

    return false;
}

void 
SendMessageEventHandler::sendBufferedMessage(int receiverFd, ServerMetaData* serverMetaData) {
    ClientSocketInfo* receiverSocketInfo;
    for(int i = 0; i<= serverMetaData->clientInfos.size(); i++) {
        if(serverMetaData->clientInfos[i].fd == receiverFd) {
            receiverSocketInfo = &(serverMetaData->clientInfos[i]);
            break;
        }
    }

    char relayMessage[1024];
    bzero(&relayMessage,sizeof(relayMessage));
    while(!receiverSocketInfo->bufferedMessages.empty()) {
        strcat(relayMessage, receiverSocketInfo->bufferedMessages.front().message);
        send(receiverFd,relayMessage,strlen(relayMessage),0);
        printSuccess(relayMessage);
        receiverSocketInfo->receivedMsgCount++;
        receiverSocketInfo->bufferedMessages.pop();
    }
}

void
SendMessageEventHandler::printSuccess(char* relayMessage) {
  char *commandName = strtok(relayMessage," "); 
  char *senderIpAddr = strtok(NULL," "); // sender ip address
  char *receiverIpAddr = strtok(NULL," "); // receiver ip address
  char *message = strtok(NULL,""); // message

  cse4589_print_and_log("[%s:SUCCESS]\n","RELAYED");
  cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",senderIpAddr,receiverIpAddr,message);
  cse4589_print_and_log("[%s:END]\n","RELAYED");
}

void 
SendMessageEventHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","RELAYED");
  cse4589_print_and_log("[%s:END]\n","RELAYED");
}

