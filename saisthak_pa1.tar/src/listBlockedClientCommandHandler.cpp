#include "../include/base.h"

using namespace std;

ListBlockedClientCommandHandler::ListBlockedClientCommandHandler() {

}

bool comparator(BlockedHostInfo bhi1,BlockedHostInfo bhi2){
  return bhi1.portNum < bhi2.portNum;
}

void 
ListBlockedClientCommandHandler::handle(char* command, HostInfo* hostinfo, ServerMetaData* serverMetaData){
    char *arg[2];
    arg[0] = strtok(command," ");
    arg[1] = strtok(NULL," "); // ip for which we need to display blocked ips 

    if(!isValidIPAddressWithPort(arg[1], 80)) {
        printError();
        return;
    }

    bool foundIp =false;
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin();itr != serverMetaData->clientInfos.end();++itr){
        if(strcmp(arg[1], itr->ipAddr) == 0) {
          cse4589_print_and_log("[BLOCKED:SUCCESS]\n");
          foundIp = true;
          int i = 0;
          vector<BlockedHostInfo> blockHostInfos = itr->blockedInfos;
          sort(blockHostInfos.begin(), blockHostInfos.end(), comparator);
          for(vector<BlockedHostInfo>::iterator itr2 = blockHostInfos.begin(); itr2 != blockHostInfos.end(); ++itr2) {
              cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",
                                      ++i,
                                      itr2->hostName,
                                      itr2->ipAddr,
                                      itr2->portNum);
          }
        }
    }

    if(!foundIp){
        printError();
        return;
    }

    cse4589_print_and_log("[BLOCKED:END]\n");
}

void
ListBlockedClientCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","BLOCKED");
  cse4589_print_and_log("[%s:END]\n","BLOCKED");
}




