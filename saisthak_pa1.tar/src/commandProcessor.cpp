#include "../include/base.h"

using namespace std;

CommandProcessor::CommandProcessor() {
    authorCommandHandler = new AuthorCommandHandler();
    ipCommandHandler = new IpCommandHandler();
    portCommandHandler = new PortCommandHandler();
    loginCommandHandler = new LoginCommandHandler();
    refreshCommandHandler = new RefreshCommandHandler();
    sendCommandHandler = new SendCommandHandler();
    broadcastCommandHandler = new BroadcastCommandHandler();
    blockCommandHandler = new BlockCommandHandler();
    unblockCommandHandler = new UnblockCommandHandler();
    logoutCommandHandler = new LogoutCommandHandler();
    exitCommandHandler = new ExitCommandHandler();
    statisticsCommandHandler = new StatisticsCommandHandler();
    listBlockedClientCommandHandler = new ListBlockedClientCommandHandler();
    listClientCommandHandler = new ListClientCommandHandler();
    sendFileCommandHandler = new SendFileCommandHandler();
}

void
CommandProcessor::handleClientCommands(char* command, HostInfo* hostInfo, int serverFd) {
    if(strcmp(command, "AUTHOR") == 0) {
        authorCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "PORT") == 0) {
        portCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "IP") == 0) {
        ipCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "LIST") == 0) {
        listClientCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "REFRESH") == 0) {
        refreshCommandHandler->handle(hostInfo, serverFd);
        return;
    }
    
    if(strncmp(command, "SENDFILE", 8) == 0) {
        sendFileCommandHandler->handle(command, hostInfo);
        return;
    }


    if(strncmp(command, "SEND", 4) == 0) {
        sendCommandHandler->handle(command, hostInfo, serverFd);
        return;
    }

    if(strncmp(command, "LOGIN", 5) == 0) {
        loginCommandHandler->handle(command, hostInfo, serverFd);
        return;
    }

    if(strncmp(command, "BROADCAST", 9) == 0) {
        broadcastCommandHandler->handle(command, hostInfo, serverFd);
        return;
    }

    if(strncmp(command, "BLOCK", 5) == 0) {
        blockCommandHandler->handle(command, hostInfo, serverFd);
        return;
    }

    if(strncmp(command, "UNBLOCK", 7) == 0) {
        unblockCommandHandler->handle(command, hostInfo, serverFd);
        return;
    }

    if(strcmp(command, "LOGOUT") == 0) {
        logoutCommandHandler->handle(hostInfo, serverFd);
        return;
    }

    if(strcmp(command, "EXIT") == 0) {
        exitCommandHandler->handle(hostInfo, serverFd);
        return;
    }
}

void 
CommandProcessor::handleServerCommands(char* command, HostInfo* hostInfo, ServerMetaData* serverMetaData) {
    if(strcmp(command, "AUTHOR") == 0) {
        authorCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "PORT") == 0) {
        portCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "IP") == 0) {
        ipCommandHandler->handle(hostInfo);
        return;
    }

    if(strcmp(command, "LIST") == 0) {
        listClientCommandHandler->handle(hostInfo, serverMetaData);
        return;
    }

    if(strcmp(command, "STATISTICS") == 0) {
        statisticsCommandHandler->handle(serverMetaData);
        return;
    }

    if(strncmp(command, "BLOCKED", 7) == 0) {
        listBlockedClientCommandHandler->handle(command, hostInfo, serverMetaData);
        return;
    }
}
