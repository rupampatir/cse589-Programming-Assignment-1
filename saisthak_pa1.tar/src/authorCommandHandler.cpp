#include "../include/base.h"

using namespace std;

AuthorCommandHandler::AuthorCommandHandler() {

}

void 
AuthorCommandHandler::handle(HostInfo* hostinfo) {
    cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
    cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "saisthak");
    cse4589_print_and_log("[AUTHOR:END]\n");
}