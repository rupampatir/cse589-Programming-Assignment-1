#include "../include/base.h"

using namespace std;

LoginCommandHandler::LoginCommandHandler() {

}

void 
LoginCommandHandler::handle(char* command, HostInfo* hostinfo, int serverFd) {
    if(hostinfo->isLoggedIn){
        printError();
        return;
    }

    char *serverIp;
    char *serverPort;
    strtok(command," ");
    serverIp = strtok(NULL," ");
    serverPort = strtok(NULL," ");

    struct sockaddr_in dest; 
    bzero(&dest,sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_port = htons(atoi(serverPort));
    dest.sin_addr.s_addr = inet_addr(serverIp);

    if ((connect(serverFd, (struct sockaddr *)&dest, sizeof(struct sockaddr))) < 0){
      printError();
      return;
    }
    
    char clientHostNameAndPort[1024];
    bzero(&clientHostNameAndPort,sizeof(clientHostNameAndPort));
    strcat(clientHostNameAndPort,hostinfo->portNum);
    strcat(clientHostNameAndPort, " ");
    strcat(clientHostNameAndPort, hostinfo->hostName);
    send(serverFd,clientHostNameAndPort,strlen(clientHostNameAndPort),0);    
}

bool
LoginCommandHandler::validate(char* command) {
    char commandCopy[1024];
    bzero(&commandCopy,sizeof(commandCopy));
    strcat(commandCopy, command);

    char *serverIp;
    char *serverPort;
    strtok(commandCopy," ");
    serverIp = strtok(NULL," ");
    serverPort = strtok(NULL," ");
    bool isValidPortNum = isValidPortNumber(serverPort);
    if(!isValidPortNum) {
        printError();
        return false;
    }

    bool isValidIPAddress = isValidIPAddressWithPort(serverIp, atoi(serverPort));
    if(!isValidIPAddress) {
        printError();
        return false;
    }

    return true;
}

void 
LoginCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","LOGIN");
  cse4589_print_and_log("[%s:END]\n","LOGIN");
}