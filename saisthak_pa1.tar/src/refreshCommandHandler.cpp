#include "../include/base.h"

using namespace std;

RefreshCommandHandler::RefreshCommandHandler() {

}

void 
RefreshCommandHandler::handle(HostInfo* hostinfo, int serverFd) {
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf,"REFRESH");
    if(send(serverFd,buf,strlen(buf),0)<0) {
      printError();
      return;
    }

    printSuccess();
}

void
RefreshCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","REFRESH");
  cse4589_print_and_log("[%s:END]\n","REFRESH");
}

void 
RefreshCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","REFRESH");
  cse4589_print_and_log("[%s:END]\n","REFRESH");
}