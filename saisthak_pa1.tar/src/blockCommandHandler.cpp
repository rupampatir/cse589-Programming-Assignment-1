#include "../include/base.h"

using namespace std;

BlockCommandHandler::BlockCommandHandler() {

}

void 
BlockCommandHandler::handle(char* command, HostInfo* hostinfo, int serverFd){
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    char *commandName = strtok(command," "); 
    char *receiverIpAddr = strtok(NULL," "); 

    if(!isValidIPAddressWithPort(receiverIpAddr,80)){
        printError();
        return;
    }

    if(!hostinfo->isValidPeer(receiverIpAddr)) {
        printError();
        return;
    }

    if(hostinfo->isBlocked(receiverIpAddr)) {
      printError();
      return;
    }

    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf,"BLOCK ");
    strcat(buf, receiverIpAddr);
    
    if(send(serverFd,buf,strlen(buf),0)<0) {
        printError();
        return;
    }

    printSuccess();

    PeerInfo peerInfo;
    bzero(&peerInfo.ipAddr,sizeof(peerInfo.ipAddr));
    bzero(&peerInfo.hostName,sizeof(peerInfo.hostName));
    peerInfo.portNum = 0;
    strcpy(peerInfo.ipAddr, receiverIpAddr);
    hostinfo->blockedIpAddr.push_back(peerInfo);
}

void
BlockCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","BLOCK");
  cse4589_print_and_log("[%s:END]\n","BLOCK");
}

void 
BlockCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","BLOCK");
  cse4589_print_and_log("[%s:END]\n","BLOCK");
}