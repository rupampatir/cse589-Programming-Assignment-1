#include "../include/base.h"

using namespace std;

Client::Client(char* port) {
    char* hostName = getHostName();
	char* ipAddr = getIPAddr();
    strcpy(info.portNum, port);
    strcpy(info.hostName, hostName);
    strcpy(info.ipAddr, ipAddr);   
    info.isLoggedIn = false;   
    info.isClient = true;                                                      
        
    CommandProcessor* commandProcessor = new CommandProcessor();
    EventProcessor* eventProcessor = new EventProcessor();
    LoginCommandHandler* loginCommandHandler = new LoginCommandHandler();
    SendFileEventHandler* sendFileEventHandler = new SendFileEventHandler();
    int connectionListeningSocketFd = initializeClientSocket(port, &info);

    char buf[1024];
    int recvbytes;
    int serverFd;
    while(true) {
        bzero(&buf,sizeof(buf));
        read(STD_IN,buf,1024);
        buf[strlen(buf)-1]='\0';
        if (strncmp(buf, "LOGIN", 5) == 0){
            bool isValid = loginCommandHandler->validate(buf);
            if(!isValid)
                continue;
                
            serverFd = socket(AF_INET, SOCK_STREAM, 0);
            loginCommandHandler->handle(buf, &info, serverFd);
            while(true) {
                bzero(&buf,sizeof(buf));
                fd_set read_fds;
                FD_ZERO(&read_fds);
                FD_SET(STD_IN,&read_fds);
                FD_SET(connectionListeningSocketFd, &read_fds);
                FD_SET(serverFd,&read_fds);
 
                int fd_max = serverFd;
                select(fd_max+1, &read_fds, NULL, NULL, NULL);
                if (FD_ISSET(STD_IN, &read_fds)){
                    read(STD_IN,buf,1024);
                    buf[strlen(buf)-1]='\0';
                    commandProcessor->handleClientCommands(buf, &info, serverFd);
                    if(strncmp(buf, "LOGOUT", 6) == 0) 
                        break;
                } else if (FD_ISSET(connectionListeningSocketFd, &read_fds)) {
                    sendFileEventHandler->handleClientSideEvent(connectionListeningSocketFd, &info);
                }
                else {
                    char msg[1024];
                    bzero(&msg,sizeof(msg));
                    int recvbytes;
                    if((recvbytes = recv(serverFd,msg,sizeof(msg),0)) <= 0){
                        close(serverFd);
                        info.isLoggedIn = false;
                        break;
                    }

                    if(FD_ISSET(serverFd,&read_fds)){
                        eventProcessor->handleClientEvents(msg, &info);
                    }
                }
            }
        } else {
            commandProcessor->handleClientCommands(buf, &info, 0);
        }
    }
}
