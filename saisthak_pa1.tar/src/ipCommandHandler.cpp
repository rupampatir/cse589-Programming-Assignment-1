#include "../include/base.h"

using namespace std;

IpCommandHandler::IpCommandHandler() {

}

void 
IpCommandHandler::handle(HostInfo* hostinfo) {
    cse4589_print_and_log("[IP:SUCCESS]\n");
    cse4589_print_and_log("IP:%s\n",hostinfo->ipAddr);
    cse4589_print_and_log("[IP:END]\n");
}