#include "../include/base.h"

using namespace std;

char* 
getHostName() {
  char* hostname = (char*) malloc(1024);
  int status = gethostname(hostname, (size_t) 1024);
  if(status == -1) {
    cerr<<"Error while retrieving host name \n";
    exit(1);
  }
  return hostname;
}

char* 
getHostName(char* ipAddr) {
  struct sockaddr_in s;
  struct hostent *h;
  if(!inet_aton(ipAddr,&s.sin_addr)){
    cerr<<"Error while trying to convert ip address to network binary"<<endl;
    exit(1);
  }

  if((h = gethostbyaddr((const void *)&s.sin_addr, (socklen_t) 100, AF_INET)) == NULL){
    cerr<<"Error while trying to fetch hostname by ipAddress"<<endl;
    exit(1);
  }

  return h->h_name;
}

char*
getIPAddr() {
  struct ifaddrs *ifaddrs, *addr;
  struct sockaddr_in *sockaddr;
  struct in_addr inAddr;
  int status = getifaddrs(&ifaddrs);
  if(status == -1) {
    cerr<<"Error while retriving local host details \n";
    exit(1);
  }

  for (addr = ifaddrs; addr; addr = addr->ifa_next) {
        if (addr->ifa_addr && addr->ifa_addr->sa_family==AF_INET) {
            sockaddr = (struct sockaddr_in *) addr->ifa_addr;
            inAddr = sockaddr->sin_addr;
            if((strncmp(inet_ntoa(inAddr), "127", 3) != 0) && (strncmp(inet_ntoa(inAddr), "192", 3) != 0))
              break;
        }
  }
  free(ifaddrs);
  return inet_ntoa(inAddr);
}

void 
initializeServerListeningSocket(HostInfo* hostInfo, ServerMetaData* serverMetaData) {
    int socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if(socketfd < 0) {
        cerr<<"Error while trying to create socket file descriptor \n";
        exit(1);
    }

    serverMetaData->listenerFd = socketfd;
    struct sockaddr_in hostAddr;
    hostAddr.sin_family = AF_INET;
    hostAddr.sin_port = htons(atoi(hostInfo->portNum));
    hostAddr.sin_addr.s_addr = inet_addr(hostInfo->ipAddr);
    memset(hostAddr.sin_zero, '\0', sizeof hostAddr.sin_zero);

    // bind socket
    int bindStatus = bind(serverMetaData->listenerFd, (struct sockaddr *)&hostAddr, sizeof(hostAddr));
    if(bindStatus < 0) {
        cerr<<"Error while trying to bind socket \n";
        exit(1);
    }

    int listenStatus = listen(serverMetaData->listenerFd, 8);
    if (listenStatus < 0) {
      cerr<<"Error while trying to listen for new connections";
      exit(1);
    }

    FD_ZERO(&serverMetaData->master); 
    FD_ZERO(&serverMetaData->read_fds);
    FD_SET(serverMetaData->listenerFd, &serverMetaData->master);
    FD_SET(STD_IN,&serverMetaData->master);
}

int 
initializeClientSocket(char* port, HostInfo* hostInfo) {
    int socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if(socketfd < 0) {
        cerr<<"Error while trying to create socket file descriptor \n";
        exit(1);
    }

    struct sockaddr_in hostAddr;
    hostAddr.sin_family = AF_INET;
    hostAddr.sin_port = htons(atoi(hostInfo->portNum));
    hostAddr.sin_addr.s_addr = inet_addr(hostInfo->ipAddr);
    memset(hostAddr.sin_zero, '\0', sizeof hostAddr.sin_zero);

    // bind socket
    int bindStatus = bind(socketfd, (struct sockaddr *)&hostAddr, sizeof(hostAddr));
    if(bindStatus < 0) {
        cerr<<"Error while trying to bind socket \n";
        exit(1);
    }

    int listenStatus = listen(socketfd, 8);
    if (listenStatus < 0) {
      cerr<<"Error while trying to listen for new connections";
      exit(1);
    }

    return socketfd;
}

ClientSocketInfo 
getSocketInfo(int clientFd, struct sockaddr_in *sin) {
    ClientSocketInfo clientSocketInfo;
    bzero(&clientSocketInfo.hostName,sizeof(clientSocketInfo.hostName));
    bzero(&clientSocketInfo.ipAddr,sizeof(clientSocketInfo.ipAddr));
    bzero(&clientSocketInfo.status,sizeof(clientSocketInfo.status));

    strcpy(clientSocketInfo.ipAddr,inet_ntoa(sin->sin_addr));
    strcpy(clientSocketInfo.status, "logged-in");
    clientSocketInfo.sentMsgCount = 0;
    clientSocketInfo.receivedMsgCount = 0;
    clientSocketInfo.fd = clientFd;

    
    char portAndHostname[1024];
    bzero(&portAndHostname,sizeof(portAndHostname));
    if(recv(clientFd, portAndHostname, sizeof(portAndHostname),0) <= 0) {
      cerr<<"Error while fetching port and hostname"<<endl;
      return clientSocketInfo;
    }

    char *arg_zero = strtok(portAndHostname," ");
    char *arg[2];
    arg[1] = strtok(NULL," ");

    clientSocketInfo.portNum = atoi(arg_zero);
    strcpy(clientSocketInfo.hostName,arg[1]);
    return clientSocketInfo;
}

bool 
isValidPortNumber(char* port) {
    if(port == NULL){
     return false;
    }   

    for(int i = 0;i != strlen(port); ++i){
      if(!(port[i] >= '0' && port[i] <= '9'))
       return false;
    }

    int portNum = atoi(port);
    if(portNum < 0 || portNum > 65535){
      return false;
    }

    return true;
}

bool 
isValidIPAddressWithPort(char* ipAddr, int portNum) {
  struct sockaddr_in ipAddrStruct;
  ipAddrStruct.sin_family = AF_INET;
  ipAddrStruct.sin_port = htons(portNum);
  if(inet_pton(AF_INET,ipAddr,&ipAddrStruct.sin_addr) != 1)
    return false;

  return true;
}
