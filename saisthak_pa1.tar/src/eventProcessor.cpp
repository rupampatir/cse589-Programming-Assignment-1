#include "../include/base.h"

using namespace std;

EventProcessor::EventProcessor() {
    sendMessageEventHandler = new SendMessageEventHandler();
    blockEventHandler = new BlockEventHandler();
    unBlockEventHandler = new UnBlockEventHandler();
    loginRequestEventHandler = new LoginRequestEventHandler();
    refreshEventHandler = new RefreshEventHandler();
    exitEventHandler = new ExitEventHandler();
    broadcastEventHandler = new BroadcastEventHandler();
}

void 
EventProcessor::handleClientEvents(char* eventData, HostInfo* hostInfo) {
    if(strncmp(eventData, "LOGIN", 5) == 0) {
        loginRequestEventHandler->handleClientSideEvent(eventData, hostInfo);
        return;
    }

    if(strncmp(eventData, "SEND", 4) == 0) {
        sendMessageEventHandler->handleClientSideEvent(eventData, hostInfo);
    }
    
}

void
EventProcessor::handleServerEvents(int senderFd, char* eventData, HostInfo* hostInfo, ServerMetaData* serverMetaData) {

    if(strncmp(eventData, "SEND", 4) == 0) {
        sendMessageEventHandler->handleServerSideEvent(senderFd, eventData, hostInfo, serverMetaData, true);
        return;
    }

    if(strncmp(eventData, "BLOCK", 5) == 0) {
        blockEventHandler->handleServerSideEvent(senderFd, eventData, hostInfo, serverMetaData);
        return;
    }

    if(strncmp(eventData, "UNBLOCK", 7) == 0) {
        unBlockEventHandler->handleServerSideEvent(senderFd, eventData, hostInfo, serverMetaData);
        return;
    }

    if(strncmp(eventData, "REFRESH", 7) == 0) {
        refreshEventHandler->handleServerSideEvent(senderFd, hostInfo, serverMetaData);
        return;
    }

    if(strncmp(eventData, "EXIT", 4) == 0) {
        exitEventHandler->handleServerSideEvent(senderFd, eventData, hostInfo, serverMetaData);
        return;
    }

    if(strncmp(eventData, "BROADCAST", 9) == 0) {
        broadcastEventHandler->handleServerSideEvent(senderFd, eventData, hostInfo, serverMetaData);
        return;
    }
}

