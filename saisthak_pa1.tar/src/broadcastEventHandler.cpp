#include "../include/base.h"

using namespace std;

BroadcastEventHandler::BroadcastEventHandler() {
    sendMessageEventHandler = new SendMessageEventHandler();
}

void 
BroadcastEventHandler::handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    ClientSocketInfo* senderSocketInfo;
    for(int i = 0; i<= serverMetaData->clientInfos.size(); i++) {
        if(serverMetaData->clientInfos[i].fd == senderFd) {
            senderSocketInfo = &(serverMetaData->clientInfos[i]);
            break;
        }
    }
    
    char *eventName = strtok(eventData," "); 
    char *message = strtok(NULL,"");

    
    char broadcastMessage[1024];
    for(vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin(); itr!=serverMetaData->clientInfos.end(); ++itr) {
        if(itr->fd != senderFd) {
            bzero(&broadcastMessage,sizeof(broadcastMessage));
            strcat(broadcastMessage,"SEND ");
            strcat(broadcastMessage, itr->ipAddr);
            strcat(broadcastMessage," ");
            strcat(broadcastMessage,message);
            sendMessageEventHandler->handleServerSideEvent(senderFd, broadcastMessage, hostinfo, serverMetaData, false);
        }
    }

    printSuccess(senderSocketInfo->ipAddr, message);
}

void 
BroadcastEventHandler::printSuccess(char* fromIpAddr, char* message) {
    cse4589_print_and_log("[%s:SUCCESS]\n","RELAYED");
    cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n",fromIpAddr,"255.255.255.255",message);
    cse4589_print_and_log("[%s:END]\n","RELAYED");
}



