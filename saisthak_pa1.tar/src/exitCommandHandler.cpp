#include "../include/base.h"

using namespace std;

ExitCommandHandler::ExitCommandHandler() {

}

void 
ExitCommandHandler::handle(HostInfo* hostinfo, int serverFd) {
    if(!hostinfo->isLoggedIn) {
        printSuccess();
        exit(0);
    }

    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf,"EXIT");
    if(send(serverFd,buf,strlen(buf),0)<0) {
        printError();
        return;
    }

    printSuccess();
    close(serverFd);
    exit(0);

}

void
ExitCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","EXIT");
  cse4589_print_and_log("[%s:END]\n","EXIT");
}

void 
ExitCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","EXIT");
  cse4589_print_and_log("[%s:END]\n","EXIT");
}