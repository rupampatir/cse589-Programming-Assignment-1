#include "../include/base.h"

using namespace std;

BroadcastCommandHandler::BroadcastCommandHandler() {

}

void 
BroadcastCommandHandler::handle(char* command, HostInfo* hostinfo, int serverFd){
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf,command);
    if(send(serverFd,buf,strlen(buf),0)<0) {
        printError();
        return;
    }

    printSuccess();
}

void
BroadcastCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","BROADCAST");
  cse4589_print_and_log("[%s:END]\n","BROADCAST");
}

void 
BroadcastCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","BROADCAST");
  cse4589_print_and_log("[%s:END]\n","BROADCAST");
}