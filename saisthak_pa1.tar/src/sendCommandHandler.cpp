#include "../include/base.h"

using namespace std;

SendCommandHandler::SendCommandHandler() {

}

void 
SendCommandHandler::handle(char* command, HostInfo* hostinfo, int serverFd) {
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }
    
    char buf[1048];
    bzero(&buf,sizeof(buf));
    strcat(buf, command);

    char *commandName = strtok(command," "); 
    char *receiverIpAddr = strtok(NULL," "); 
    char *message = strtok(NULL," ");

    if(!isValidIPAddressWithPort(receiverIpAddr,80)){
        printError();
        return;
    }

    if(!hostinfo->isValidPeer(receiverIpAddr)) {
        printError();
        return;
    }

    if(send(serverFd,buf,strlen(buf),0)<0) {
        printError();
        return;
    }

    printSuccess();
}

void
SendCommandHandler::printSuccess() {
  cse4589_print_and_log("[%s:SUCCESS]\n","SEND");
  cse4589_print_and_log("[%s:END]\n","SEND");
}

void 
SendCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","SEND");
  cse4589_print_and_log("[%s:END]\n","SEND");
}