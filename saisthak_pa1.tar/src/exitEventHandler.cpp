#include "../include/base.h"

using namespace std;

ExitEventHandler::ExitEventHandler() {

}

void 
ExitEventHandler::handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData) {
    vector<ClientSocketInfo>::iterator itr = serverMetaData->clientInfos.begin();
    while(itr != serverMetaData->clientInfos.end()) {
        if(itr->fd == senderFd) {
            itr = serverMetaData->clientInfos.erase(itr);
            break;
        } else {
            ++itr;
        }
    }

    close(senderFd); 
    FD_CLR(senderFd, &serverMetaData->master);
}


