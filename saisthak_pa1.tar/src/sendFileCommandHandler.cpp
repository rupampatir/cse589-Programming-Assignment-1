#include "../include/base.h"

using namespace std;

SendFileCommandHandler::SendFileCommandHandler() {

}

void 
SendFileCommandHandler::handle(char* command, HostInfo* hostinfo) {
    if(!hostinfo->isLoggedIn) {
        printError();
        return;
    }

    char *commandName = strtok(command," "); 
    char *destIpAddr = strtok(NULL," ");
    char *fileName = strtok(NULL,"");

    if(fileName == NULL){
        printError();
        return;
    }   
   
    if(!isValidIPAddressWithPort(destIpAddr, 80)) {
        printError();
        return;
    }

    if(!hostinfo->isValidPeer(destIpAddr)) {
        printError();
        return;
    }

    ifstream file(fileName, ios::in | ios::binary);

    if(!file) {
        printError();
        return;
    }


    PeerInfo peerInfo = hostinfo->getPeerInfoByIpAddr(destIpAddr);
    int peerFd = socket(AF_INET, SOCK_STREAM, 0);
    if(peerFd<0) {
        printError();
        return;
    }

    struct sockaddr_in dest; 
    bzero(&dest,sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_port = htons(peerInfo.portNum);
    dest.sin_addr.s_addr = inet_addr(peerInfo.ipAddr);

    if ((connect(peerFd, (struct sockaddr *)&dest, sizeof(struct sockaddr))) < 0){
        printError();
        return;
    }


    char fileNameMsg[1024];
    bzero(&fileNameMsg,sizeof(fileNameMsg));
    strcat(fileNameMsg, "FILENAME");
    strcat(fileNameMsg, " ");
    strcat(fileNameMsg, fileName);

    send(peerFd,fileNameMsg,strlen(fileNameMsg),0);   

    char buf[500000];
    bzero(&buf,sizeof(buf));

    while(!file.eof()){
        file.read(buf, sizeof(buf));
        send(peerFd,buf,sizeof(buf),0);
        bzero(&buf,sizeof(buf));
    }

    close(peerFd);
    file.close();
    printSuccess();
}

void 
SendFileCommandHandler::printSuccess(){
  cse4589_print_and_log("[%s:SUCCESS]\n","SENDFILE");
  cse4589_print_and_log("[%s:END]\n","SENDFILE");
}

void 
SendFileCommandHandler::printError(){
  cse4589_print_and_log("[%s:ERROR]\n","SENDFILE");
  cse4589_print_and_log("[%s:END]\n","SENDFILE");
}