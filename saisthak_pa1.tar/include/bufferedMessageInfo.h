#ifndef BUFFERED_MESSAGE_INFO_H
#define BUFFERED_MESSAGE_INFO_H

#include "base.h"

struct BufferedMessageInfo {
    char message[1024];
};

#endif