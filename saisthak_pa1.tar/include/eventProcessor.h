#ifndef EVENT_PROCESSOR_H
#define EVENT_PROCESSOR_H

#include "base.h"

using namespace std;

class SendMessageEventHandler;
class BlockEventHandler;
class UnBlockEventHandler;
class LoginRequestEventHandler;
class RefreshEventHandler;
class ExitEventHandler;
class BroadcastEventHandler;

class EventProcessor {
public:
  EventProcessor();
  void handleClientEvents(char* event, HostInfo* hostInfo);
  void handleServerEvents(int senderFd, char* event, HostInfo* hostInfo, ServerMetaData* ServerMetaData);
  
private:
    SendMessageEventHandler* sendMessageEventHandler;
    BlockEventHandler* blockEventHandler;
    UnBlockEventHandler* unBlockEventHandler;
    LoginRequestEventHandler* loginRequestEventHandler;
    RefreshEventHandler* refreshEventHandler;
    ExitEventHandler* exitEventHandler;
    BroadcastEventHandler* broadcastEventHandler;
};

#endif
