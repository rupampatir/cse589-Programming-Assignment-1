#ifndef SERVER_META_DATA_H
#define SERVER_META_DATA_H

#include "base.h"

#define STD_IN 0

using namespace std;
struct ServerMetaData {
    fd_set master; 
    fd_set read_fds; 
    int listenerFd;
    vector<ClientSocketInfo> clientInfos;
};

#endif