#ifndef CLIENT_H
#define CLIENT_H

#include "base.h"

class Client: public Host {
public:
  Client(char *port);
};

#endif
