#ifndef BLOCKED_HOST_INFO_H
#define BLOCKED_HOST_INFO_H

#include "base.h"

struct BlockedHostInfo {
    char ipAddr[1024];
    int portNum;
    char hostName[1024];
};

#endif