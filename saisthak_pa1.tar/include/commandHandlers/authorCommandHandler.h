#ifndef AUTHOR_COMMAND_HANDLER_H
#define AUTHOR_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class AuthorCommandHandler {
public:
  AuthorCommandHandler();
  void handle(HostInfo* hostinfo);
};

#endif
