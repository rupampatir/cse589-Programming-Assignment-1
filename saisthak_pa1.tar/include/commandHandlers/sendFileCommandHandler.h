#ifndef SEND_FILE_COMMAND_HANDLER_H
#define SEND_FILE_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class SendFileCommandHandler {
public:
  SendFileCommandHandler();
  void handle(char* command, HostInfo* hostinfo);
private: 
  void printSuccess();
  void printError();
};

#endif
