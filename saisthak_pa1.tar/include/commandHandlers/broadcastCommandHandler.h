#ifndef BRAODCAST_COMMAND_HANDLER_H
#define BRAODCAST_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class BroadcastCommandHandler {
public:
  BroadcastCommandHandler();
  void handle(char* command, HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
