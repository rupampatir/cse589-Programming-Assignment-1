#ifndef SEND_COMMAND_HANDLER_H
#define SEND_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class SendCommandHandler {
public:
  SendCommandHandler();
  void handle(char* command, HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
