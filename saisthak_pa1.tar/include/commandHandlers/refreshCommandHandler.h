#ifndef REFRESH_COMMAND_HANDLER_H
#define REFRESH_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class RefreshCommandHandler {
public:
  RefreshCommandHandler();
  void handle(HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
