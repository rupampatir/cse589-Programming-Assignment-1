#ifndef LOGIN_COMMAND_HANDLER_H
#define LOGIN_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class LoginCommandHandler {
public:
  LoginCommandHandler();
  void handle(char* command, HostInfo* hostinfo, int serverFd);
  bool validate(char* command);

private:
  void printError();
};

#endif
