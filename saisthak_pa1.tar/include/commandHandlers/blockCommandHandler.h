#ifndef BLOCK_COMMAND_HANDLER_H
#define BLOCK_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class BlockCommandHandler {
public:
  BlockCommandHandler();
  void handle(char* command, HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
