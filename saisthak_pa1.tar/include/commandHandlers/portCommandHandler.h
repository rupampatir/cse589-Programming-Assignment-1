#ifndef PORT_COMMAND_HANDLER_H
#define PORT_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class PortCommandHandler {
public:
  PortCommandHandler();
  void handle(HostInfo* hostinfo);
};

#endif
