#ifndef LOGOUT_COMMAND_HANDLER_H
#define LOGOUT_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class LogoutCommandHandler {
public:
  LogoutCommandHandler();
  void handle(HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
