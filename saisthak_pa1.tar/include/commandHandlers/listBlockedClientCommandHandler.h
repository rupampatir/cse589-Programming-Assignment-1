#ifndef LIST_BLOCKED_CLIENT_COMMAND_HANDLER_H
#define LIST_BLOCKED_CLIENT_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

bool comparator(BlockedHostInfo bhi1,BlockedHostInfo bhi2);
class ListBlockedClientCommandHandler {
public:
  ListBlockedClientCommandHandler();
  void handle(char* command, HostInfo* hostinfo, ServerMetaData* serverMetaData);
private:
  void printError();
};

#endif
