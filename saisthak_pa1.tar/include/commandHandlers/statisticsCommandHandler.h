#ifndef STATISTICS_COMMAND_HANDLER_H
#define STATISTICS_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

bool comparatorCSByPortNum(ClientSocketInfo csi1,ClientSocketInfo csi2);
class StatisticsCommandHandler {
public:
  StatisticsCommandHandler();
  void handle(ServerMetaData* serverMetaData);
};

#endif
