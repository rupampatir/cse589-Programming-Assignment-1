#ifndef EXIT_COMMAND_HANDLER_H
#define EXIT_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class ExitCommandHandler {
public:
  ExitCommandHandler();
  void handle(HostInfo* hostinfo, int serverFd);
private:
  void printSuccess();
  void printError();
};

#endif
