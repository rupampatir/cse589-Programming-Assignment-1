#ifndef IP_COMMAND_HANDLER_H
#define IP_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

class IpCommandHandler {
public:
  IpCommandHandler();
  void handle(HostInfo* hostinfo);
};

#endif
