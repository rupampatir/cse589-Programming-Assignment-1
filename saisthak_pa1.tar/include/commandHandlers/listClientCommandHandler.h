#ifndef LIST_CLIENT_COMMAND_HANDLER_H
#define LIST_CLIENT_COMMAND_HANDLER_H

#include "base.h"
using namespace std;

bool comparatorPIByPortNum(PeerInfo pi1,PeerInfo pi2);
class ListClientCommandHandler {
public:
  ListClientCommandHandler();
  void handle(HostInfo* hostinfo);
  void handle(HostInfo* hostinfo, ServerMetaData* serverMetaData);

private:

};

#endif
