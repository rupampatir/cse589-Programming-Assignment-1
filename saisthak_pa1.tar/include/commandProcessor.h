#ifndef COMMAND_PROCESSOR_H
#define COMMAND_PROCESSOR_H

#include "base.h"

using namespace std;

class AuthorCommandHandler;
class BlockCommandHandler;
class BroadcastCommandHandler;
class ExitCommandHandler;
class LogoutCommandHandler;
class RefreshCommandHandler;
class SendCommandHandler;
class UnblockCommandHandler;
class IpCommandHandler;
class PortCommandHandler;
class LoginCommandHandler;
class StatisticsCommandHandler;
class ListBlockedClientCommandHandler;
class ListClientCommandHandler;
class SendFileCommandHandler;

class CommandProcessor {
public:
  CommandProcessor();
  void handleClientCommands(char* command, HostInfo* hostInfo, int serverFd);
  void handleServerCommands(char* command, HostInfo* hostInfo, ServerMetaData* ServerMetaData);
  
private:
    AuthorCommandHandler* authorCommandHandler;
    BlockCommandHandler* blockCommandHandler;
    BroadcastCommandHandler* broadcastCommandHandler;
    ExitCommandHandler* exitCommandHandler;
    LogoutCommandHandler* logoutCommandHandler;
    RefreshCommandHandler* refreshCommandHandler;
    SendCommandHandler* sendCommandHandler;
    UnblockCommandHandler* unblockCommandHandler;
    IpCommandHandler* ipCommandHandler;
    PortCommandHandler* portCommandHandler;
    LoginCommandHandler* loginCommandHandler;
    StatisticsCommandHandler* statisticsCommandHandler;
    ListBlockedClientCommandHandler* listBlockedClientCommandHandler;
    ListClientCommandHandler* listClientCommandHandler;
    SendFileCommandHandler* sendFileCommandHandler;
};

#endif
