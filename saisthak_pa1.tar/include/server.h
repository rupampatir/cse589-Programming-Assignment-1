#ifndef SERVER_H
#define SERVER_H
#include "base.h"


class LoginRequestEventHandler;
class EventProcessor;

class Server: public Host {
public:
  Server(char *port);
  
private:
  ServerMetaData serverMetaData;
  LoginRequestEventHandler* loginRequestEventHandler;
  EventProcessor* eventProcessor;
};

#endif
