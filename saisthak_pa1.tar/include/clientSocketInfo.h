#ifndef CLIENT_SOCKET_INFO_H
#define CLIENT_SOCKET_INFO_H

#include "base.h"

using namespace std;

struct ClientSocketInfo{
  int fd;
  char hostName[100];
  char ipAddr[100];
  int portNum;
  int sentMsgCount;
  int receivedMsgCount;
  char status[20];
  queue<BufferedMessageInfo> bufferedMessages;
  vector<BlockedHostInfo> blockedInfos;
};

#endif
