#ifndef BLOCK_EVENT_HANDLER_H
#define BLOCK_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class BlockEventHandler {
public:
  BlockEventHandler();
  void handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData);

private:
  void printSuccess();
  void printError();
};

#endif
