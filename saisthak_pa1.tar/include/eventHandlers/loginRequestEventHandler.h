#ifndef LOGIN_REQUEST_EVENT_HANDLER_H
#define LOGIN_REQUEST_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class SendMessageEventHandler;

class LoginRequestEventHandler {
public:
  LoginRequestEventHandler();
  void handleClientSideEvent(char* eventData, HostInfo* hostinfo);
  int handleServerSideEvent(HostInfo* hostinfo, ServerMetaData* serverMetaData);
private:
  SendMessageEventHandler* sendMessageEventHandler;
};

#endif
