#ifndef EXIT_EVENT_HANDLER_H
#define EXIT_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class ExitEventHandler {
public:
  ExitEventHandler();
  void handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData);
};

#endif
