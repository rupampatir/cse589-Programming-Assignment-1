#ifndef REFRESH_EVENT_HANDLER_H
#define REFRESH_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class RefreshEventHandler {
public:
  RefreshEventHandler();
  void handleServerSideEvent(int senderFd, HostInfo* hostinfo, ServerMetaData* serverMetaData);
};

#endif
