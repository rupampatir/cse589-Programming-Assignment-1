#ifndef SEND_MESSAGE_EVENT_HANDLER_H
#define SEND_MESSAGE_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class SendMessageEventHandler {
public:
  SendMessageEventHandler();
  void handleClientSideEvent(char* eventData, HostInfo* hostinfo);
  void handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData, bool printRelayLogs);
  void sendBufferedMessage(int receiverFd, ServerMetaData* serverMetaData);
  
private:
  void printSuccess(char* relayMessage);
  void printError();
  bool isSenderBlocked(char* senderIpAddr, ClientSocketInfo* receiverSocketInfo);
};

#endif
