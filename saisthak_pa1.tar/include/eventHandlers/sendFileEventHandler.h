#ifndef SEND_FILE_HANDLER_H
#define SEND_FILE_HANDLER_H

#include "base.h"
using namespace std;

class SendFileEventHandler {
public:
  SendFileEventHandler();
  void handleClientSideEvent(int clientListeningFd, HostInfo* hostinfo);
};

#endif
