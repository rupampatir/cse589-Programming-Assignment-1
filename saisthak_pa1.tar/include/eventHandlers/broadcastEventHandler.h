#ifndef BROADCAST_EVENT_HANDLER_H
#define BROADCAST_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class SendMessageEventHandler;

class BroadcastEventHandler {
public:
  BroadcastEventHandler();
  void handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData);
private:
  SendMessageEventHandler* sendMessageEventHandler;
  void printSuccess(char* receiverIpAddr, char* message);
};

#endif
