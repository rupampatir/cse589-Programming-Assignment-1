#ifndef UNBLOCK_EVENT_HANDLER_H
#define UNBLOCK_EVENT_HANDLER_H

#include "base.h"
using namespace std;

class UnBlockEventHandler {
public:
  UnBlockEventHandler();
  void handleServerSideEvent(int senderFd, char* eventData, HostInfo* hostinfo, ServerMetaData* serverMetaData);

private:
  void printSuccess();
  void printError();
};

#endif
