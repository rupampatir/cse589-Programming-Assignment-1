#ifndef NETWORK_ACTIONS_H
#define NETWORK_ACTIONS_H

#include "base.h"

char* getHostName();
char* getHostName(char* ipAddr);
// char* getIPAddr(char* port);
char* getIPAddr();

void initializeServerListeningSocket(HostInfo* hostInfo, ServerMetaData* serverMetaData);
int initializeClientSocket(char* port, HostInfo* hostInfo);
ClientSocketInfo getSocketInfo(int clientFd, struct sockaddr_in *sin);
bool isValidPortNumber(char* port);
bool isValidIPAddressWithPort(char* ipAddr, int portNum);

#endif
