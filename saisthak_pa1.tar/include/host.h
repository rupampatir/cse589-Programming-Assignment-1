#ifndef HOST_H
#define HOST_H

#include "base.h"

class Host {
public:
  Host();

protected:
  HostInfo info;
  
};

#endif
