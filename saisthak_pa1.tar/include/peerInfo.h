#ifndef PEER_INFO_H
#define PEER_INFO_H

#include "base.h"

using namespace std;

struct PeerInfo{
  char hostName[100];
  char ipAddr[100];
  int portNum;
};

#endif
