#ifndef HOSTINFO_H_
#define HOSTINFO_H_

#include "base.h"

using namespace std;
struct HostInfo {
    char ipAddr[1024];
    char portNum[1024];
    char hostName[1024];
    bool isServer;
    bool isClient;
    bool isLoggedIn;
    vector<PeerInfo> peerinfos;
    vector<PeerInfo> blockedIpAddr;

    PeerInfo getPeerInfoByIpAddr(char* ipAddr) {
        PeerInfo garbageInfo;
        for(int i = 0; i<peerinfos.size(); i++) {
            if(strcmp(peerinfos[i].ipAddr, ipAddr) == 0) {
                return peerinfos[i];
            }
        }
        
        return garbageInfo;
    }

    bool isValidPeer(char* ipAddr) {
        bool isValidPeer = false;
        for(vector<PeerInfo>::iterator itr = peerinfos.begin();itr != peerinfos.end();++itr){
            if(strcmp(itr->ipAddr, ipAddr) == 0){
                isValidPeer = true;
                break;
            }
        }

        return isValidPeer;
    }

    bool isBlocked(char* toBeBlockedIpAddr) {
        bool isBlocked = false;
        for(vector<PeerInfo>::iterator itr = blockedIpAddr.begin(); itr != blockedIpAddr.end(); ++itr) {
            if(strcmp(itr->ipAddr, toBeBlockedIpAddr) == 0) {
                isBlocked = true;
                break;
            }
        }
        return isBlocked;
    }

    void markUnblocked(char* toBeUnBlockedIpAddr) {
        vector<PeerInfo>::iterator itr = blockedIpAddr.begin();
        while(itr != blockedIpAddr.end()) {
             if(strcmp(itr->ipAddr, toBeUnBlockedIpAddr) == 0) {
                 itr = blockedIpAddr.erase(itr);  
                 break;
             }else {
                 ++itr; 
             }  
        }
    }
};

#endif