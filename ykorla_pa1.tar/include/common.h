#include <stdbool.h>

#define MAXDATASIZE 1024

struct host
{
    int id;
    char *hostname;
    char *ip_addr;
    int port_num;
    int num_msg_sent;
    int num_msg_rcv;
    char *status;
    int fd;
    // struct ips *blocked_list;
    struct host *blocked_clients;
    struct host *next_host;
    bool is_logged_in;
    bool is_server;
    struct message *queued_messages;
};

// struct ips
// {
//     char *ip;
//     char *hostname;
//     char *port_no;
//     int fd;
//     struct ips *next;
// };

struct message
{
    char *text;
    char *from_client;
    struct message *next_message;
    bool is_broadcast;
};

void client(int port, struct host **client_list);
void server(char **argv, struct host *client_list);
char *findIp(char *cmd, bool logs);
int checkIfValidIP(char *ip);
int checkIfValidPort(char *port);
void add_new_client_to_the_List(int fd, struct sockaddr_in c_addr, struct host **client_list);
void print_list(struct host *c_list, char *cmd);
void sortByPort(struct host *client_list);
int extractFD(struct host *c_list, char *ip);
int checkIfIPExists(struct host *c_list, char *ip);
int checkIfLoggedIn(struct host *c_list, char *ip);
void increaseMessageCountForClients(char *sender, char *receiver, struct host *client_list);
void storeBufferMessages(char *sender, char *receiver, char *message, int isBroadCast, struct host *c_list);
char *convertIntergerToString(int a);
struct host *SortedMerge(struct host *a, struct host *b);
void FrontBackSplit(struct host *source, struct host **frontRef, struct host **backRef);
int getNumberLength(int a);
void MergeSort(struct host **headRef);
void sendToClient(char *receiver_ip, char *sender_ip, char *message, int fdaccept, struct host *c_list, char *buffer, int showMultipleSends);
int checkValidIPForLC(char *ip, struct host *c_list);
int checkIfIpIsBlocked(char *receiver_ip, char *sender_ip, struct host *c_list);
int checkIfIpIsNotBlocked(char *receiver_ip, char *sender_ip, struct host *c_list);