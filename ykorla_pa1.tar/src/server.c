#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <common.h>
#include <logger.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

#define BACKLOG 5
#define STDIN 0
#define TRUE 1
#define FALSE 0
#define CMD_SIZE 1024
#define BUFFER_SIZE 1024

int client_count = 1;

/**
 * Server function
 *
 * @param  port  Port number
 * @return none
 */
void server(char **argv, struct host *client_list)
{
	int server_socket, head_socket, selret, sock_index, fdaccept = 0, caddr_len;
	struct sockaddr_in client_addr;
	struct addrinfo hints, *res;
	fd_set master_list, watch_list;

	/* Set up hints structure */
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	/* Fill up address structures */
	if (getaddrinfo(NULL, argv[2], &hints, &res) != 0)
		perror("getaddrinfo failed");

	/* Socket */
	server_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if (server_socket < 0)
		perror("Cannot create socket");

	/* Bind */
	if (bind(server_socket, res->ai_addr, res->ai_addrlen) < 0)
		perror("Bind failed");

	freeaddrinfo(res);

	/* Listen */
	if (listen(server_socket, BACKLOG) < 0)
		perror("Unable to listen on port");

	/* ---------------------------------------------------------------------------- */

	/* Zero select FD sets */
	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);

	/* Register the listening socket */
	FD_SET(server_socket, &master_list);
	/* Register STDIN */
	FD_SET(STDIN, &master_list);

	head_socket = server_socket;

	while (TRUE)
	{
		memcpy(&watch_list, &master_list, sizeof(master_list));

		fflush(stdout);

		/* select() system call. This will BLOCK */
		selret = select(head_socket + 1, &watch_list, NULL, NULL, NULL);
		if (selret < 0)
			perror("select failed.");

		/* Check if we have sockets/STDIN to process */
		if (selret > 0)
		{
			/* Loop through socket descriptors to check which ones are ready */
			for (sock_index = 0; sock_index <= head_socket; sock_index += 1)
			{

				if (FD_ISSET(sock_index, &watch_list))
				{

					/* Check if new command on STDIN */
					if (sock_index == STDIN)
					{
						char *cmd = (char *)malloc(sizeof(char) * CMD_SIZE);

						memset(cmd, '\0', CMD_SIZE);
						if (fgets(cmd, CMD_SIZE - 1, stdin) == NULL) // Mind the newline character that will be written to cmd
							exit(-1);

						/*to get rid of '\n' added by fgets*/
						int len = strlen(cmd);
						cmd[len - 1] = '\0';

						// Process PA1 commands here ...

						if (strcmp(cmd, "AUTHOR") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
							cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "ykorla");
							cse4589_print_and_log("[%s:END]\n", "AUTHOR");
						}
						else if (strcmp(cmd, "IP") == 0)
						{
							findIp("IP", 1);
						}
						else if (strcmp(cmd, "PORT") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", "PORT");
							cse4589_print_and_log("PORT:%d\n", atoi(argv[2]));
							cse4589_print_and_log("[%s:END]\n", "PORT");
						}
						else if (strcmp(cmd, "LIST") == 0)
						{
							print_list(client_list, "LIST");
						}
						else if (strncmp(cmd, "BLOCKED", 7) == 0)
						{
							char *command = strtok(cmd, " ");
							char *ip = strtok(NULL, "");

							int fd = extractFD(client_list, ip);

							// printf("%s %s", command, ip);

							if (checkIfValidIP(ip) == 0 || checkIfIPExists(client_list, ip) == 0)
							{
								cse4589_print_and_log("[%s:ERROR]\n", command);
								cse4589_print_and_log("[%s:END]\n", command);
							}
							else
							{
								struct host *temp = client_list;

								while (temp != NULL)
								{
									if (strcmp(temp->ip_addr, ip) == 0)
									{
										struct host *temp2 = temp->blocked_clients;
										print_list(temp2, "BLOCKED");
									}

									temp = temp->next_host;
								}
								// cse4589_print_and_log("[%s:SUCCESS]\n", command);
								// cse4589_print_and_log("[%s:END]\n", command);
							}
						}
						else if (strcmp(cmd, "STATISTICS") == 0)
						{
							cse4589_print_and_log("[%s:SUCCESS]\n", "STATISTICS");
							struct host *temp = client_list;

							if (temp != NULL)
							{
								MergeSort(&temp);
								int list_id = 1;
								while (temp != NULL)
								{
									char *status;
									if (temp->is_logged_in == 1)
									{
										status = "logged-in";
									}
									else
									{
										status = "logged-out";
									}
									cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n", list_id, temp->hostname, temp->num_msg_sent, temp->num_msg_rcv, status);
									list_id = list_id + 1;

									temp = temp->next_host;
								}
							}
							cse4589_print_and_log("[%s:END]\n", "STATISTICS");
						}

						free(cmd);
					}
					/* Check if new client is requesting connection */
					else if (sock_index == server_socket)
					{
						caddr_len = sizeof(client_addr);
						fdaccept = accept(server_socket, (struct sockaddr *)&client_addr, &caddr_len);
						if (fdaccept < 0)
							perror("Accept failed.");
						// Getting client ip
						char clientIP[INET_ADDRSTRLEN];
						inet_ntop(AF_INET, &client_addr.sin_addr.s_addr, clientIP, INET_ADDRSTRLEN);
						printf("\nRemote Host connected %s!\n", clientIP);

						/* Add to watched socket list */
						FD_SET(fdaccept, &master_list);
						if (fdaccept > head_socket)
						{
							head_socket = fdaccept;
						}

						add_new_client_to_the_List(fdaccept, client_addr, &client_list);
					}
					/* Read from existing clients */
					else
					{
						/* Initialize buffer to receieve response */
						char *buffer = (char *)malloc(sizeof(char) * BUFFER_SIZE);
						memset(buffer, '\0', BUFFER_SIZE);

						if (recv(sock_index, buffer, BUFFER_SIZE, 0) <= 0)
						{
							close(sock_index);
							printf("Remote Host terminated connection!\n");

							/* Remove from watched list */
							FD_CLR(sock_index, &master_list);
						}
						else
						{
							// Process incoming data from existing clients here ...
							char temp1[1024];
							// memset(temp1, '\0', BUFFER_SIZE);
							memcpy(temp1, buffer, sizeof(temp1));

							char *token = strtok(temp1, " ");
							// printf("value %s\n", token);
							if (strcmp(token, "<ykTag>") == 0)
							{
								int overall = 3;
								int k = 3;
								char *a[3];
								while (k > 0)
								{
									// printf("%d %s\n", overall - k, token);
									a[overall - k] = token;
									token = strtok(NULL, " ");
									k -= 1;
								}

								struct host *temp = client_list;
								while (temp != NULL)
								{
									if (strcmp(a[1], temp->ip_addr) == 0)
									{
										temp->port_num = atoi(a[2]);
										// printf("port number %d\n", temp->port_num);
										break;
									}
									else
									{
										temp = temp->next_host;
									}
								}

								int cfd = extractFD(client_list, a[1]);
								struct host *temp2 = client_list;

								while (temp2 != NULL)
								{
									char new_text[1024] = {0};
									strcat(new_text, "RECEIVE_LIST");
									strcat(new_text, " ");
									strcat(new_text, temp2->hostname);
									strcat(new_text, " ");
									strcat(new_text, temp2->ip_addr);
									strcat(new_text, " ");
									strcat(new_text, convertIntergerToString(temp2->port_num));
									strcat(new_text, " ");
									strcat(new_text, convertIntergerToString(temp2->is_logged_in));
									send(cfd, new_text, strlen(new_text), 0);
									recv(cfd, buffer, BUFFER_SIZE, 0);
									// printf("value at index %d  is %s\n", i, listArray[i]);

									temp2 = temp2->next_host;
								}

								struct host *temp3 = client_list;

								while (temp3 != NULL)
								{
									if (strcmp(temp3->ip_addr, a[1]) == 0)
									{
										while (temp3->queued_messages != NULL)
										{
											char new_text[1024] = {0};
											strcat(new_text, "UNREAD");
											strcat(new_text, " ");
											strcat(new_text, temp3->queued_messages->from_client);
											strcat(new_text, " ");
											strcat(new_text, temp3->queued_messages->text);
											send(cfd, new_text, strlen(new_text), 0);
											recv(cfd, buffer, BUFFER_SIZE, 0);

											// Printing on server
											cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
											cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", temp3->queued_messages->from_client, a[1], temp3->queued_messages->text);
											cse4589_print_and_log("[%s:END]\n", "RELAYED");
											fflush(stdout);
											temp3->queued_messages = temp3->queued_messages->next_message;
										}
									}
									temp3 = temp3->next_host;
								}

								send(cfd, "SUCCESS_MSG LOGIN", 1024, 0);
								recv(cfd, buffer, BUFFER_SIZE, 0);

								fflush(stdout);
							}
							else if (strcmp(token, "LOGOUT") == 0)
							{
								char *ip = strtok(NULL, " ");
								int fd = extractFD(client_list, ip);

								if (fd == 0)
								{
									fd = fdaccept;
								}
								struct host *temp = client_list;

								while (temp != NULL)
								{
									if (strcmp(temp->ip_addr, ip) == 0)
									{
										temp->is_logged_in = FALSE;
										close(temp->fd);
										FD_CLR(temp->fd, &master_list);
										break;
									}
									temp = temp->next_host;
								}

								fflush(stdout);
							}
							else if (strcmp(token, "SEND") == 0)
							{
								char *receiver_ip = strtok(NULL, " ");
								char *sender_ip = strtok(NULL, " ");
								char *message = strtok(NULL, "");

								// printf("%s %s", message, sender_ip);

								sendToClient(receiver_ip, sender_ip, message, fdaccept, client_list, buffer, 1);

								fflush(stdout);
							}
							else if (strcmp(token, "GET_ULIST") == 0)
							{
								char *ip = strtok(NULL, " ");
								int cfd = extractFD(client_list, ip);
								struct host *temp2 = client_list;

								while (temp2 != NULL)
								{
									char new_text[256] = {0};
									strcat(new_text, "RECEIVE_LIST");
									strcat(new_text, " ");
									strcat(new_text, temp2->hostname);
									strcat(new_text, " ");
									strcat(new_text, temp2->ip_addr);
									strcat(new_text, " ");
									strcat(new_text, convertIntergerToString(temp2->port_num));
									strcat(new_text, " ");
									strcat(new_text, convertIntergerToString(temp2->is_logged_in));
									send(cfd, new_text, strlen(new_text), 0);
									recv(cfd, buffer, BUFFER_SIZE, 0);
									temp2 = temp2->next_host;
								}
							}
							else if (strcmp(token, "BROADCAST") == 0)
							{
								char *ip = strtok(NULL, " ");
								char *message = strtok(NULL, "");

								int fd = extractFD(client_list, ip);

								struct host *temp = client_list;

								while (temp != NULL)
								{
									if (strcmp(temp->ip_addr, ip) != 0)
									{
										sendToClient(temp->ip_addr, ip, message, fdaccept, client_list, buffer, 0);
									}
									temp = temp->next_host;
								}
								char cmd[256] = "SUCCESSFULLY_SENT";
								send(fd, cmd, strlen(cmd), 0);
								recv(fd, buffer, BUFFER_SIZE, 0);
							}
							else if (strcmp(token, "BLOCK") == 0)
							{
								char *ocip = strtok(NULL, " ");
								char *mip = strtok(NULL, " ");

								int fd = extractFD(client_list, mip);

								// printf("other ip %s\n", ocip);
								// printf("mip ip %s\n", mip);
								// printf("fd %d\n", fd);

								struct host *temp = client_list;
								// OCIP needs to be added to blocked array.
								int foundIP = 0;
								while (temp != NULL)
								{
									if (strcmp(temp->ip_addr, ocip) == 0)
									{
										foundIP = 1;
										break;
									}
									temp = temp->next_host;
								}

								if (foundIP == 0 || checkIfIpIsBlocked(ocip, mip, client_list) == 1)
								{
									// ERROR code.
									send(fd, "ERROR_MSG BLOCK", 256, 0);
									recv(fd, buffer, BUFFER_SIZE, 0);
								}
								else
								{
									struct host *temp1 = client_list;

									while (temp1 != NULL)
									{
										if (strcmp(temp1->ip_addr, mip) == 0)
										{

											struct host *temp2 = client_list;

											while (temp2 != NULL)
											{
												if (strcmp(temp2->ip_addr, ocip) == 0)
												{

													if (temp1->blocked_clients == NULL)
													{
														temp1->blocked_clients = temp2;
														// printf("Inside if. IP is %s\n", temp1->blocked_list->ip);
													}
													else
													{
														struct host *current = temp1->blocked_clients;
														while (true)
														{
															if (current->next_host == NULL)
															{
																current->next_host = temp2;
																break;
															}
															current = current->next_host;
														};

														// printf("IP is %s\n", current->ip);
													}
												}

												temp2 = temp2->next_host;
											}
											// Can also use ips member, but will be difficult while displaying broadcast.
											// struct ips *t = (struct ips *)malloc(sizeof(struct ips));
											// char *_ip = malloc(46);
											// memset(_ip, '\0', 46);
											// strcpy(_ip, ocip);
											// t->ip = _ip;
											// // printf("Blocked ip is %s\n", t->ip);
											// t->next = NULL;

											// if (temp1->blocked_list == NULL)
											// {
											// 	temp1->blocked_list = t;
											// 	// printf("Inside if. IP is %s\n", temp1->blocked_list->ip);
											// }
											// else
											// {
											// 	struct ips *current = temp1->blocked_list;
											// 	while (true)
											// 	{
											// 		if (current->next == NULL)
											// 		{
											// 			current->next = t;
											// 			break;
											// 		}
											// 		current = current->next;
											// 	};

											// 	// printf("IP is %s\n", current->ip);
											// }
											break;
										}
										temp1 = temp1->next_host;
									}

									send(fd, "SUCCESS_MSG BLOCK", 256, 0);
									recv(fd, buffer, BUFFER_SIZE, 0);
								}
							}
							else if (strcmp(token, "UNBLOCK") == 0)
							{
								char *r = strtok(NULL, " ");
								char *s = strtok(NULL, " ");
								int fd = extractFD(client_list, s);
								if (checkIfIpIsNotBlocked(r, s, client_list) == 1)
								{
									send(fd, "ERROR_MSG UNBLOCK", 256, 0);
									recv(fd, buffer, BUFFER_SIZE, 0);
								}
								else
								{
									// Unblock the client from the list.
									struct host *temp = client_list, *prev;

									while (temp != NULL)
									{
										if (strcmp(temp->ip_addr, s) == 0)
										{
											struct host *t = temp->blocked_clients, *prev;

											if (t != NULL && strcmp(t->ip_addr, r) == 0)
											{
												temp->blocked_clients = t->next_host;
												// free(t);
												break;
											}

											while (t != NULL && strcmp(t->ip_addr, r) != 0)
											{
												prev = t;
												t = t->next_host;
											}

											if (t == NULL)
												break;

											prev->next_host = t->next_host;
										}
										temp = temp->next_host;
									}
									send(fd, "SUCCESS_MSG UNBLOCK", 256, 0);
									recv(fd, buffer, BUFFER_SIZE, 0);
								}
							}
							else if (strcmp(token, "EXIT_COMMAND") == 0)
							{
								char *ip = strtok(NULL, " ");
								int fd = extractFD(client_list, ip);
								struct host *temp = client_list, *prev;

								// If head node itself holds the key to be deleted
								if (temp != NULL && strcmp(temp->ip_addr, ip) == 0)
								{
									client_list = temp->next_host;
								}

								while (temp != NULL && strcmp(temp->ip_addr, ip) != 0)
								{
									prev = temp;
									temp = temp->next_host;
								}
							}
							fflush(stdout);
						}

						free(buffer);
					}
				}
			}
		}
	}
}

void add_new_client_to_the_List(int fd, struct sockaddr_in c_addr, struct host **client_list)
{
	// Getting client ip
	char cip[INET_ADDRSTRLEN];
	inet_ntop(AF_INET, &c_addr.sin_addr.s_addr, cip, INET_ADDRSTRLEN);
	char hostname[NI_MAXHOST];
	// https: // man7.org/linux/man-pages/man3/getnameinfo.3.html
	getnameinfo((struct sockaddr *)&c_addr, sizeof(c_addr), hostname, sizeof(hostname), 0, 0, 0);
	// printf("hostname %s\n", hostname);

	// // https://linux.die.net/man/3/ntohs
	unsigned short pn = ntohs(c_addr.sin_port);

	// // Convert unsigned short to string.
	// // https://stackoverflow.com/a/63666964
	// char *port_number = malloc(5);
	// snprintf(port_number, 5, "%u", pn);

	// creating a new node
	struct host *node = (struct host *)malloc(sizeof(struct host));
	node->id = client_count;
	// node->hostname = (char *)malloc(sizeof((int)strlen(hostname->h_name)));
	// strcpy(node->hostname, hostname->h_name);

	node->hostname = malloc(strlen(hostname) + 1);
	// printf("hostname %s\n", hostname);
	strcpy(node->hostname, hostname);
	node->fd = fd;
	// node->port_num = (char *)malloc(5);
	// strcpy(node->port_num, port_number);
	node->port_num = pn;
	node->ip_addr = (char *)malloc(46);
	strcpy(node->ip_addr, cip);
	node->num_msg_sent = 0;
	node->num_msg_rcv = 0;
	node->blocked_clients = NULL;
	node->next_host = NULL;
	node->is_logged_in = TRUE;
	node->is_server = TRUE;

	if (*client_list == NULL)
	{

		*client_list = node;
		node->next_host = NULL;
	}
	else
	{
		node->next_host = *client_list;
		*client_list = node;
	}

	client_count++;
}

void print_list(struct host *c_list, char *cmd)
{
	cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
	struct host *temp = c_list;

	if (temp != NULL)
	{
		MergeSort(&temp);
		int list_id = 1;
		while (temp != NULL)
		{
			if (temp->is_logged_in == 1)
			{
				cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", list_id, temp->hostname, temp->ip_addr, temp->port_num);
				list_id = list_id + 1;
			}
			temp = temp->next_host;
		}
	}

	cse4589_print_and_log("[%s:END]\n", cmd);
}

// Taken from https://www.geeksforgeeks.org/c-program-for-merge-sort-for-linked-lists/
void MergeSort(struct host **headRef)
{
	struct host *head = *headRef;
	struct host *a;
	struct host *b;

	if ((head == NULL) ||
		(head->next_host == NULL))
	{
		return;
	}

	FrontBackSplit(head, &a, &b);

	MergeSort(&a);
	MergeSort(&b);

	*headRef = SortedMerge(a, b);
}

/* See https:// www.geeksforgeeks.org/?p=3622
   for details of this function */
struct host *SortedMerge(struct host *a,
						 struct host *b)
{
	struct host *result = NULL;

	// Base cases
	if (a == NULL)
		return (b);
	else if (b == NULL)
		return (a);

	// Pick either a or b, and recur
	if (a->port_num <= b->port_num)
	{
		result = a;
		result->next_host =
			SortedMerge(a->next_host, b);
	}
	else
	{
		result = b;
		result->next_host = SortedMerge(a, b->next_host);
	}
	return (result);
}

void FrontBackSplit(struct host *source,
					struct host **frontRef,
					struct host **backRef)
{
	struct host *fast;
	struct host *slow;
	slow = source;
	fast = source->next_host;

	/* Advance 'fast' two nodes, and
	   advance 'slow' one node */
	while (fast != NULL)
	{
		fast = fast->next_host;
		if (fast != NULL)
		{
			slow = slow->next_host;
			fast = fast->next_host;
		}
	}

	/* 'slow' is before the midpoint in the
		list, so split it in two at that point. */
	*frontRef = source;
	*backRef = slow->next_host;
	slow->next_host = NULL;
}

int extractFD(struct host *c_list, char *ip)
{
	struct host *temp = c_list;
	while (temp != NULL)
	{
		if (strcmp(temp->ip_addr, ip) == 0)
		{
			return temp->fd;
		}
		temp = temp->next_host;
	}
	return 0;
}

int checkIfIPExists(struct host *c_list, char *ip)
{

	struct host *temp = c_list;

	while (temp != NULL)
	{
		if (strcmp(ip, temp->ip_addr) == 0)
		{
			return 1;
		}
		temp = temp->next_host;
	}

	return 0;
}

int checkIfLoggedIn(struct host *c_list, char *ip)
{

	struct host *temp = c_list;

	while (temp != NULL)
	{
		if (strcmp(ip, temp->ip_addr) == 0)
		{
			if (temp->is_logged_in == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		temp = temp->next_host;
	}

	return 0;
}

void increaseMessageCountForClients(char *sender, char *receive, struct host *client_list)
{
	struct host *temp = client_list;
	while (temp != NULL)
	{
		if (strcmp(sender, temp->ip_addr) == 0)
		{
			temp->num_msg_sent = temp->num_msg_sent + 1;
			break;
		}
		temp = temp->next_host;
	}

	// free(temp);

	struct host *temp1 = client_list;
	while (temp1 != NULL)
	{
		if (strcmp(receive, temp1->ip_addr) == 0)
		{
			temp1->num_msg_rcv = temp1->num_msg_rcv + 1;
			break;
		}
		temp1 = temp1->next_host;
	}

	// free(temp1);
}

void storeBufferMessages(char *sender, char *receiver, char *message, int isBroadCast, struct host *c_list)
{
	struct host *temp = c_list;
	while (temp != NULL)
	{
		if (strcmp(receiver, temp->ip_addr) == 0)
		{
			struct message *t = (struct message *)malloc(sizeof(struct host));
			char *_sender = malloc(strlen(sender) + 1);
			memset(_sender, '\0', strlen(sender) + 1);
			strcpy(_sender, sender);
			char *_text = malloc(strlen(message) + 1);
			memset(_text, '\0', strlen(message) + 1);
			strcpy(_text, message);
			t->text = _text;
			t->from_client = _sender;
			t->next_message = NULL;
			t->is_broadcast = isBroadCast;

			if (temp->queued_messages == NULL)
			{
				temp->queued_messages = t;
			}
			else
			{
				// else loop through the list and find the last
				// node, insert next to it
				struct message *current = temp->queued_messages;
				while (true)
				{
					if (current->next_message == NULL)
					{
						current->next_message = t;
						break;
					}
					current = current->next_message;
				};
			}

			break;
		}
		temp = temp->next_host;
	}
}

char *convertIntergerToString(int a)
{
	char *port_number = malloc(10);
	snprintf(port_number, 10, "%u", a);
	return port_number;
}

void sendToClient(char *receiver_ip, char *sender_ip, char *message, int fdaccept, struct host *c_list, char *buffer, int showMultipleSends)
{
	struct host *temp = c_list;
	// printf("ip %s message %s\n", ip, message);
	int sender_fd = extractFD(temp, sender_ip);

	if (sender_fd == 0)
	{
		sender_fd = fdaccept;
	}
	if (checkIfIPExists(temp, receiver_ip) == 0)
	{
		printf("Failed");
		char cmd[256] = "SEND_FAILED";
		send(sender_fd, cmd, strlen(cmd), 0);
	}
	else if (checkIfIpIsBlocked(sender_ip, receiver_ip, temp) == 1)
	{
		if (showMultipleSends != 0)
		{
			char cmd[256] = "SUCCESSFULLY_SENT";
			send(sender_fd, cmd, strlen(cmd), 0);
			recv(sender_fd, buffer, BUFFER_SIZE, 0);
		};
	}
	else
	{
		if (checkIfLoggedIn(temp, receiver_ip) == 0)
		{
			int cfd = extractFD(temp, sender_ip);
			// printf("came to store message section\n");
			storeBufferMessages(sender_ip, receiver_ip, message, 0, temp);
			// recv(sender_fd, buffer, BUFFER_SIZE, 0);
			if (showMultipleSends != 0)
			{
				send(cfd, "SUCCESS_MSG SEND", 1024, 0);
				recv(cfd, buffer, BUFFER_SIZE, 0);
			}
		}
		else
		{
			int receiver_fd = extractFD(temp, receiver_ip);
			char new_msg[1024] = {0};
			strcat(new_msg, "SEND_TO_OTHER_CLIENT");
			strcat(new_msg, " ");
			strcat(new_msg, sender_ip);
			strcat(new_msg, " ");
			strcat(new_msg, message);
			if (send(receiver_fd, new_msg, strlen(new_msg), 0) == -1)
			{
				char cmd[256] = "SEND_FAILED";
				send(sender_fd, cmd, strlen(cmd), 0);
				recv(sender_fd, buffer, BUFFER_SIZE, 0);
				perror("Failed sending message to the other client");
			}
			else
			{
				// printf("Send the message to %s\n", receiver_ip);
				increaseMessageCountForClients(sender_ip, receiver_ip, temp);
				if (showMultipleSends == 1)
				{
					char cmd[256] = "SUCCESSFULLY_SENT";
					send(sender_fd, cmd, strlen(cmd), 0);
					recv(sender_fd, buffer, BUFFER_SIZE, 0);
				}
				cse4589_print_and_log("[%s:SUCCESS]\n", "RELAYED");
				cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sender_ip, receiver_ip, message);
				cse4589_print_and_log("[%s:END]\n", "RELAYED");
				fflush(stdout);
			}
		}
	}
}

int checkIfIpIsBlocked(char *receiver_ip, char *sender_ip, struct host *c_list)
{

	struct host *temp = c_list;

	while (temp != NULL)
	{
		if (strcmp(temp->ip_addr, sender_ip) == 0)
		{

			struct host *t = temp->blocked_clients;

			while (t != NULL)
			{
				if (strcmp(t->ip_addr, receiver_ip) == 0)
				{
					// printf("blokced ip %s\n", t->ip);

					return 1;
				}
				// printf("blokced ip %s\n", t->ip);
				t = t->next_host;
			}

			return 0;
		}

		temp = temp->next_host;
	}

	return 0;
}

int checkIfIpIsNotBlocked(char *receiver_ip, char *sender_ip, struct host *c_list)
{
	struct host *temp = c_list;

	while (temp != NULL)
	{
		if (strcmp(temp->ip_addr, sender_ip) == 0)
		{

			struct host *t = temp->blocked_clients;

			while (t != NULL)
			{
				if (strcmp(t->ip_addr, receiver_ip) == 0)
				{
					// printf("blokced ip %s\n", t->ip);

					return 0;
				}
				// printf("blokced ip %s\n", t->ip);
				t = t->next_host;
			}

			return 1;
		}

		temp = temp->next_host;
	}

	return 1;
}