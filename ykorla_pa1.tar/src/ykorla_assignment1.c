/**
 * @ykorla_assignment1
 * @authors  Yashwanth korla <ykorla@buffalo.edu> Vaishnav Tammadwar <vtammadw@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/global.h"
#include "../include/logger.h"

#include <netinet/in.h> // For handling internet addresses.
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <common.h>
#include <stdbool.h>

#define CMD_SIZE 200
#define GDS "8.8.8.8"
#define GDS_PORT 53

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */
int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/*Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	struct host *client_list = NULL;
	if (argc != 3)
	{
		exit(-1);
	}

	if (checkIfValidPort(argv[2]) == 0){
		perror("Invalid port number");
		exit(-1);
	}

	char type = *argv[1];
	int port = atoi(argv[2]);

	int sd = 0;

	sd = socket(AF_INET, SOCK_STREAM, 0);

	if (sd == 0)
	{
		exit(EXIT_FAILURE);
	}

	if (type == 's')
	{
		// Server code
		server(argv, client_list);
	}
	else
	{
		// client code
		client(port, &client_list);
	}

	return 0;
}

/**
 * @param cmd - Command name
 * @return none
 */
char *findIp(char *cmd, bool logs)
{
	struct sockaddr_in udp_socket;

	int new_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	if (new_socket < 0)
	{
		perror("Error: Socket");
	}

	memset(&udp_socket, 0, sizeof(udp_socket));
	udp_socket.sin_family = AF_INET;
	udp_socket.sin_addr.s_addr = inet_addr(GDS);
	udp_socket.sin_port = htons(GDS_PORT);

	int connectUDP = connect(new_socket, (const struct sockaddr *)&udp_socket, sizeof(udp_socket));

	// https://man7.org/linux/man-pages/man2/getsockname.2.html
	struct sockaddr_in temp_name;
	int sock_address_len = sizeof(temp_name);
	int gotSocketname = getsockname(new_socket, (struct sockaddr *)&temp_name, (unsigned int *)&sock_address_len);

	char *ipAddressInText = malloc(INET_ADDRSTRLEN);
	// https://man7.org/linux/man-pages/man3/inet_ntop.3.html
	const char *output = inet_ntop(AF_INET, &temp_name.sin_addr, ipAddressInText, sock_address_len);

	if (connectUDP != 0 && gotSocketname != 0 && output == NULL)
	{
		cse4589_print_and_log("[%s:ERROR]\n", cmd);
		cse4589_print_and_log("[%s:END]\n", cmd);
	}
	else
	{
		if (logs == 1)
		{
			cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
			cse4589_print_and_log("IP:%s\n", ipAddressInText);
			cse4589_print_and_log("[%s:END]\n", cmd);
		}
	}

	close(new_socket);
	return ipAddressInText;
}
