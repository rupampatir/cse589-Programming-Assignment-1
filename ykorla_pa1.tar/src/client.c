#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <common.h>
#include <logger.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/select.h>
#include <unistd.h>

#define TRUE 1
#define MSG_SIZE 1024
#define BUFFER_SIZE 1024
#define STDIN 0
#define CHAR_MAX_LENGTH 1024

int connect_to_host(char *server_ip, char *server_port, int cport);

int sd;

char currentClientIp[INET_ADDRSTRLEN];

void client(int cport, struct host **client_list)
{
    fd_set masterList, watchList;
    bool loggedin;
    int server = 0;
    int noOfFileDescriptors;

    FD_ZERO(&masterList);
    FD_ZERO(&watchList);
    FD_SET(STDIN, &masterList);
    int headSocket = server;

    while (TRUE)
    {
        // printf("\n[PA1-Client@CSE489/589]$ ");
        memcpy(&watchList, &masterList, sizeof(masterList));

        // https://man7.org/linux/man-pages/man2/select.2.html
        noOfFileDescriptors = select(headSocket + 1, &watchList, NULL, NULL, NULL);
        if (noOfFileDescriptors < 0)
        {
            perror("No File Descriptors. Selection Failed.");
            exit(-1);
        }

        if (noOfFileDescriptors > 0)
        {
            /* Loop through socket descriptors to check which ones are ready */
            for (int i = 0; i <= headSocket; i += 1)
            {
                if (FD_ISSET(i, &watchList))
                {
                    if (i == STDIN)
                    {
                        char *msg = (char *)malloc(sizeof(char) * MSG_SIZE); // MSG_SIZE=256
                        memset(msg, '\0', MSG_SIZE);
                        if (fgets(msg, MSG_SIZE - 1, stdin) == NULL) // Mind the newline character that will be written to msg
                            exit(-1);
                        /*to get rid of '\n' added by fgets*/
                        int len = strlen(msg);
                        msg[len - 1] = '\0';
                        if (strncmp(msg, "BLOCKED", 7) == 0)
                        {
                            printf("Command entered is wrong. Please use HELP to find the commands for the you\n");
                            fflush(stdout);
                        }
                        else if ((strncmp(msg, "LOGIN", 5)) == 0)
                        {
                            char ip[INET_ADDRSTRLEN];
                            char loginPort[32];

                            // loop through the string to extract all other tokens
                            char *token = strtok(msg, " ");
                            int overall = 3;
                            int k = 3;
                            char *a[3];
                            while (k > 0)
                            {
                                // printf("%d %s\n", overall - k, token);
                                a[overall - k] = token;
                                token = strtok(NULL, " ");
                                k -= 1;
                            }

                            // printf("It came here \n");
                            // printf("IP %s\n", a[1]);
                            if (a[1] == NULL || a[2] == NULL)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", a[0]);
                                cse4589_print_and_log("[%s:END]\n", a[0]);
                                continue;
                            }

                            strcpy(ip, a[1]);
                            strcpy(loginPort, a[2]);

                            if (checkIfValidIP(ip) != 0 && checkIfValidPort(loginPort) != 0)
                            {

                                server = connect_to_host(ip, loginPort, cport);
                                if (server < 0)
                                {
                                    cse4589_print_and_log("[%s:ERROR]\n", a[0]);
                                    cse4589_print_and_log("[%s:END]\n", a[0]);
                                    continue;
                                }
                                // printf("server connection %d\n", server);
                                FD_SET(server, &masterList);
                                headSocket = server;
                                loggedin = TRUE;

                                char custom[70] = {0};
                                strcat(custom, "<ykTag>");
                                strcat(custom, " ");
                                strcpy(currentClientIp, findIp("IP", 0));
                                // printf("Current ip %s\n", currentClientIp);
                                strcat(custom, findIp("IP", 0));
                                strcat(custom, " ");
                                int portLen = getNumberLength(cport);
                                char *port_number = malloc(portLen);
                                snprintf(port_number, portLen, "%u", cport);
                                strcat(custom, port_number);
                                strcat(custom, "\n");
                                if (send(server, custom, strlen(custom), 0) == -1)
                                {
                                    perror("Send Failed.");
                                }
                                // cse4589_print_and_log("[%s:SUCCESS]\n", a[0]);
                                // cse4589_print_and_log("[%s:END]\n", a[0]);
                                fflush(stdout);
                            }
                            else
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", a[0]);
                                cse4589_print_and_log("[%s:END]\n", a[0]);
                            }

                            fflush(stdout);
                        }
                        else if (strcmp(msg, "AUTHOR") == 0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n", "AUTHOR");
                            cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n", "ykorla");
                            cse4589_print_and_log("[%s:END]\n", "AUTHOR");
                            fflush(stdout);
                        }
                        else if (strcmp(msg, "IP") == 0)
                        {
                            findIp("IP", 1);
                            fflush(stdout);
                        }
                        else if (strcmp(msg, "PORT") == 0)
                        {
                            cse4589_print_and_log("[%s:SUCCESS]\n", "PORT");
                            cse4589_print_and_log("PORT:%d\n", cport);
                            cse4589_print_and_log("[%s:END]\n", "PORT");
                            fflush(stdout);
                        }
                        else if (strcmp(msg, "LIST") == 0 && loggedin)
                        {
                            print_list(*client_list, "LIST");
                        }
                        else if (strcmp(msg, "LOGOUT") == 0 && loggedin)
                        {
                            if (loggedin)
                            {
                                *client_list = NULL;
                                char cmd[CHAR_MAX_LENGTH] = {0};
                                strcat(cmd, "LOGOUT");
                                strcat(cmd, " ");
                                strcat(cmd, findIp("IP", 0));
                                send(server, cmd, CHAR_MAX_LENGTH, 0);
                                loggedin = 0;
                                close(server);
                                FD_CLR(server, &masterList);
                                cse4589_print_and_log("[%s:SUCCESS]\n", "LOGOUT");
                                cse4589_print_and_log("[%s:END]\n", "LOGOUT");
                                fflush(stdout);
                            }
                            else
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", "LOGOUT");
                                cse4589_print_and_log("[%s:END]\n", "LOGOUT");
                                fflush(stdout);
                            }
                        }
                        else if (strcmp(msg, "REFRESH") == 0)
                        {
                            if (loggedin)
                            {
                                *client_list = NULL;
                                char tempChar[BUFFER_SIZE] = {0};
                                strcat(tempChar, "GET_ULIST");
                                strcat(tempChar, " ");
                                strcat(tempChar, currentClientIp);
                                if (send(server, tempChar, strlen(tempChar), 0) == -1)
                                {
                                    cse4589_print_and_log("[%s:ERROR]\n", "REFRESH");
                                    cse4589_print_and_log("[%s:END]\n", "REFRESH");
                                }
                                else
                                {
                                    cse4589_print_and_log("[REFRESH:SUCCESS]\n");
                                    cse4589_print_and_log("[REFRESH:END]\n");
                                }
                            }
                            else
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", "REFRESH");
                                cse4589_print_and_log("[%s:END]\n", "REFRESH");
                            }
                            fflush(stdout);
                        }
                        else if (strncmp(msg, "SEND", 4) == 0)
                        {
                            fflush(stdout);
                            char *ip;
                            char *message;

                            // loop through the string to extract all other tokens
                            char *x = strtok(msg, " ");
                            ip = strtok(NULL, " ");
                            message = strtok(NULL, "");
                            // printf("It came here \n");
                            // printf("IP %s\n", a[1]);
                            if (ip == NULL || message == NULL || checkIfValidIP(ip) == 0 || checkIfIPExists(*client_list, ip) == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", x);
                                cse4589_print_and_log("[%s:END]\n", x);
                                continue;
                            }

                            char msg[CHAR_MAX_LENGTH] = {0};
                            strcat(msg, "SEND");
                            strcat(msg, " ");
                            strcat(msg, ip);
                            strcat(msg, " ");
                            strcat(msg, findIp("IP", 0));
                            strcat(msg, " ");
                            strcat(msg, message);
                            // printf("message %s\n and msg %s\n", message, msg);
                            if (send(server, msg, strlen(msg), 0) == -1)
                            {
                                perror("send failed");
                            }
                        }
                        else if (strncmp(msg, "BROADCAST", 9) == 0 && loggedin)
                        {
                            char *cmd = strtok(msg, " ");
                            char *message = strtok(NULL, "");

                            if (strlen(message) == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", cmd);
                                cse4589_print_and_log("[%s:END]\n", cmd);
                                continue;
                            }

                            char msg[CHAR_MAX_LENGTH] = {0};
                            strcat(msg, cmd);
                            strcat(msg, " ");
                            strcat(msg, findIp("IP", 0));
                            strcat(msg, " ");
                            strcat(msg, message);
                            send(server, msg, strlen(msg), 0);
                        }
                        else if (strncmp(msg, "BLOCK", 5) == 0)
                        {
                            // printf("It came here");
                            fflush(stdout);
                            char *ip;
                            char *x = strtok(msg, " ");
                            ip = strtok(NULL, " ");
                            if (ip == NULL || checkIfValidIP(ip) == 0 || checkValidIPForLC(ip, *client_list) == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", x);
                                cse4589_print_and_log("[%s:END]\n", x);
                                continue;
                            }

                            char msg[CHAR_MAX_LENGTH] = {0};
                            strcat(msg, "BLOCK");
                            strcat(msg, " ");
                            strcat(msg, ip);
                            strcat(msg, " ");
                            strcat(msg, findIp("IP", 0));
                            // printf("message %s\n and msg %s\n", message, msg);
                            if (send(server, msg, strlen(msg), 0) == -1)
                            {
                                perror("send failed");
                            }
                        }
                        else if (strncmp(msg, "UNBLOCK", 7) == 0)
                        {
                            fflush(stdout);
                            char *ip;
                            char *x = strtok(msg, " ");
                            ip = strtok(NULL, " ");
                            if (ip == NULL || checkIfValidIP(ip) == 0 || checkValidIPForLC(ip, *client_list) == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", x);
                                cse4589_print_and_log("[%s:END]\n", x);
                                continue;
                            }

                            char msg[CHAR_MAX_LENGTH] = {0};
                            strcat(msg, "UNBLOCK");
                            strcat(msg, " ");
                            strcat(msg, ip);
                            strcat(msg, " ");
                            strcat(msg, findIp("IP", 0));
                            // printf("message %s\n and msg %s\n", message, msg);
                            if (send(server, msg, strlen(msg), 0) == -1)
                            {
                                perror("send failed");
                            }
                        }
                        else if (strcmp(msg, "EXIT") == 0 && loggedin)
                        {
                            char cmd[CHAR_MAX_LENGTH] = {0};
                            strcat(cmd, "EXIT_COMMAND");
                            strcat(cmd, " ");
                            strcat(cmd, findIp("IP", 0));
                            if (send(server, cmd, CHAR_MAX_LENGTH, 0) == -1)
                            {
                                perror("FAILED TO REMOVE CLIENT ON SERVER SIDE");
                            }
                            loggedin = 0;
                            close(server);
                            FD_CLR(server, &masterList);
                            cse4589_print_and_log("[%s:SUCCESS]\n", "EXIT");
                            cse4589_print_and_log("[%s:END]\n", "EXIT");
                            exit(0);
                        }
                        else if (strcmp(msg, "HELP") == 0)
                        {
                            printf("AUTHOR, IP, PORT, LOGIN, LIST, BLOCK, SEND, REFRESH, BROADCAST, UNBLOCK, LOGOUT, EXIT\n");
                            fflush(stdout);
                        }
                        else
                        {
                            printf("Command entered is wrong. Please use HELP to find the commands for the you\n");
                            fflush(stdout);
                        }
                    }
                    else
                    {
                        // printf("\nSENDing it to the remote server ... ");
                        // if (send(server, msg, strlen(msg), 0) == strlen(msg))
                        //     printf("Done!\n");

                        // /* Initialize buffer to receieve response */
                        char *buffer = (char *)malloc(sizeof(char) * BUFFER_SIZE);
                        memset(buffer, '\0', BUFFER_SIZE);

                        if (recv(server, buffer, BUFFER_SIZE, 0) >= 0)
                        {

                            // Process incoming data from existing clients here ...
                            char temp1[1024];
                            // memset(temp1, '\0', BUFFER_SIZE);
                            memcpy(temp1, buffer, sizeof(temp1));

                            char *token = strtok(temp1, " ");
                            // printf("value %s\n", token);
                            if (strcmp(token, "SEND_TO_OTHER_CLIENT") == 0)
                            {
                                char *sender_ip = strtok(NULL, " ");
                                char *message = strtok(NULL, "");
                                cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
                                cse4589_print_and_log("msg from:%s\n[msg]:%s\n", sender_ip, message);
                                cse4589_print_and_log("[%s:END]\n", "RECEIVED");
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            else if (strcmp(token, "SUCCESSFULLY_SENT") == 0)
                            {
                                cse4589_print_and_log("[%s:SUCCESS]\n", "SEND");
                                fflush(stdout);
                                cse4589_print_and_log("[%s:END]\n", "SEND");
                                fflush(stdout);
                                send(server, "ACK", 10, 0);
                            }
                            else if (strcmp(token, "SEND_FAILED") == 0)
                            {
                                cse4589_print_and_log("[%s:ERROR]\n", "SEND");
                                fflush(stdout);
                                cse4589_print_and_log("[%s:END]\n", "SEND");
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            else if (strcmp(token, "RECEIVE_LIST") == 0)
                            {
                                fflush(stdout);
                                char *hostname = strtok(NULL, " ");
                                char *ip = strtok(NULL, " ");
                                char *port = strtok(NULL, " ");
                                char *loggedInStatus = strtok(NULL, " ");
                                char *_hostname = malloc(strlen(hostname) + 1);
                                char *_ip = malloc(strlen(hostname) + 1);
                                char *_port = malloc(strlen(port) + 1);
                                char *_loggedInStatus = malloc(strlen(loggedInStatus) + 1);
                                memset(_hostname, '\0', strlen(hostname) + 1);
                                memset(_ip, '\0', strlen(ip) + 1);
                                memset(_port, '\0', strlen(port) + 1);
                                memset(_loggedInStatus, '\0', strlen(loggedInStatus) + 1);
                                strcpy(_hostname, hostname);
                                strcpy(_ip, ip);
                                strcpy(_port, port);
                                strcpy(_loggedInStatus, loggedInStatus);

                                // printf("%s %s %s %s\n", hostname, ip, port, loggedInStatus);

                                struct host *node = (struct host *)malloc(sizeof(struct host));
                                node->hostname = _hostname;
                                node->port_num = atoi(_port);
                                node->ip_addr = _ip;
                                node->num_msg_sent = 0;
                                node->num_msg_rcv = 0;
                                node->blocked_clients = NULL;
                                node->next_host = NULL;
                                node->is_logged_in = atoi(_loggedInStatus);
                                node->is_server = 0;

                                if (*client_list == NULL)
                                {
                                    *client_list = node;
                                }
                                else
                                {
                                    if ((*client_list)->next_host == NULL)
                                    {
                                        // printf("Its null\n");
                                    }
                                    node->next_host = *client_list;
                                    *client_list = node;
                                }
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            else if (strcmp(token, "UNREAD") == 0)
                            {
                                fflush(stdout);
                                char *sender_ip = strtok(NULL, " ");
                                char *message = strtok(NULL, "");
                                cse4589_print_and_log("[%s:SUCCESS]\n", "RECEIVED");
                                fflush(stdout);
                                cse4589_print_and_log("msg from:%s\n[msg]:%s\n", sender_ip, message);
                                fflush(stdout);
                                cse4589_print_and_log("[%s:END]\n", "RECEIVED");
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            else if (strcmp(token, "ERROR_MSG") == 0)
                            {
                                char *cmd = strtok(NULL, " ");
                                cse4589_print_and_log("[%s:ERROR]\n", cmd);
                                fflush(stdout);
                                cse4589_print_and_log("[%s:END]\n", cmd);
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            else if (strcmp(token, "SUCCESS_MSG") == 0)
                            {
                                char *cmd = strtok(NULL, " ");
                                cse4589_print_and_log("[%s:SUCCESS]\n", cmd);
                                cse4589_print_and_log("[%s:END]\n", cmd);
                                send(server, "ACK", 10, 0);
                                fflush(stdout);
                            }
                            // printf("Server responded: %s", buffer);
                            // printf("%s", buffer);
                            fflush(stdout);
                        }
                    }
                }
            }
        }
    }
}

int connect_to_host(char *server_ip, char *server_port, int cport)
{
    int fdsocket;
    struct addrinfo hints, *res;
    struct sockaddr_in serverDetails;

    /* Set up hints structure */
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    /* Fill up address structures */
    if (getaddrinfo(server_ip, server_port, &hints, &res) != 0)
        perror("getaddrinfo failed");

    /* Socket */
    fdsocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fdsocket < 0)
        perror("Failed to create socket");

    /* Connect */
    if (connect(fdsocket, res->ai_addr, res->ai_addrlen) < 0)
    {
        perror("Connect failed");
        return -1;
    }

    freeaddrinfo(res);

    return fdsocket;
}

int checkIfValidIP(char *ip)
{
    struct sockaddr_in addr;
    int result = inet_pton(AF_INET, ip, &addr.sin_addr);
    if (result == 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int checkIfValidPort(char *port)
{
    for (int i = 0; i < strlen(port); i++)
    {
        if (!isdigit(port[i]))
        {
            printf("Invalid number\n");
            return 0;
        }
    }

    int int_port = atoi(port);

    if (1 <= int_port && int_port <= 65555)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int getNumberLength(int a)
{
    return 50;
}

int checkValidIPForLC(char *ip, struct host *c_list)
{

    struct host *temp = c_list;

    while (temp != NULL)
    {
        if (strcmp(temp->ip_addr, ip) == 0 && (temp->is_logged_in == 1))
        {
            return 1;
        }
        temp = temp->next_host;
    }

    return 0;
}