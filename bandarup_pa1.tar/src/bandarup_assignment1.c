/**
 * @bandarup_assignment1
 * @author  Naveen Kumar Bandarupally <bandarup@buffalo.edu>
 * @version 1.0
 *
 * @section LICENSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 *
 * @section DESCRIPTION
 *
 * This contains the main function. Add further description here....
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
# include <unistd.h>
# include <ctype.h>


#include "../include/global.h"
#include "../include/logger.h"

#define STDIN 0
#define TRUE 1
#define CMD_SIZE 350
#define BUFFER_SIZE 350
#define MAX_BUFFER_SIZE 350
#define BUFF_MSG_SIZE 30000

/**
 * main function
 *
 * @param  argc Number of arguments
 * @param  argv The argument list
 * @return 0 EXIT_SUCCESS
 */

void createClient();
void createServer();
void insertClient();
void deleteClient();
void author();
void ip();
void getPort();
void list();
void sort();
void updateCientPort();
void sendToAllClients();
int sendAllData();
int receiveAllData();
void sendListToClient();
void checkAndForward();
void sendMessage();
int checkIP();
int checkLogin();
void logout();
void getIP();
void login();
void block();
void unblock();
int check_block();
void getIPAddr();
void saveMessageToBuffer();
void sendBufferedMessages();
void deleteBufferedMessages();
void blockIP();
void block();
void unBlock();
void unBlockIP();
void broadcast();
void displayStatistics();
void updateMessageCount();
int validate_number();
int validate_ip();
void displayBlocked();

int port;
int sd, cd;
char *cport;
int isLoggedIn = 0;
char myip[64];

//Structure to store socket address
struct socket_address {
	short int sin_family;
	unsigned short int sin_port;
	struct in_addr sin_addr;
	unsigned char sin_zero[8];
};

//structure to store client details
struct clients {
	int port;
	int socket;
	int msg_sent;
	int msg_received;
	int status;
	char host[100];
	char ip[64];
	struct clients *next;
} *head;

//structure to store messages in buffer
struct message_buffer {
	int from;
	int to;
	char message[256];
	struct message_buffer *next;
} *buff_head;

// structure to store blocked list
struct block_list {
	int sender_soc;
	char sender_ip[64];
	char receiver_ip[64];
	int receiver_soc;
	struct block_list *next;
} *bl_head;

int main(int argc, char **argv)
{
	/*Init. Logger*/
	cse4589_init_log(argv[2]);

	/*Clear LOGFILE*/
	fclose(fopen(LOGFILE, "w"));

	/*Start Here*/
	head = NULL;
	// cse4589_print_and_log("hello");
	if(argc == 3) {
		port = atoi(argv[2]);
		if(strcmp(argv[1], "s") == 0){
			createServer(port);
		} else if(strcmp(argv[1], "c") == 0) {
			// cse4589_print_and_log("client called");
			cport = argv[2];
			// printf("port: %s\n",cport);
			createClient(port);
		}
		// cse4589_print_and_log("closed");
	} else if(argc > 3) {
		cse4589_print_and_log("3 arguments needed but greater tahn 3 passed\n");
	} else {
		cse4589_print_and_log("3 arguments needed but less tahn 3 passed\n");
	}


	return 0;
}

//Function to create and manage server/client calls
void createServer(int port) {
	sd = socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in serv_addr, cli_addr;
	struct hostent *host;
	fd_set master_list, watch_list;
	int ld, head_soc, selret, soc_ind;
	if(sd == -1) {
		cse4589_print_and_log("Failed to create socket\n");
	} else {
		// cse4589_print_and_log("Server socket created successfully\n");
		bzero(&serv_addr,sizeof(serv_addr));
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
		serv_addr.sin_port = htons(port);
		if(bind(sd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) {
			cse4589_print_and_log("Binding failed\n");
		} else {
			// cse4589_print_and_log("Binding successful\n");
			if(listen(sd,5) < 0) {
				cse4589_print_and_log("Listening failed\n");
			} else {
				FD_ZERO(&master_list);
				FD_ZERO(&watch_list);
				FD_SET(sd, &master_list);
				FD_SET(STDIN, &master_list);
				head_soc = sd;
				while(TRUE) {
					// cse4589_print_and_log("attempting to connect\n");
					// exit(0);
					memcpy(&watch_list, &master_list, sizeof(master_list));
					selret = select(head_soc + 1, &watch_list, NULL, NULL, NULL);
					if(selret < 0) {
						cse4589_print_and_log("Select failed\n");
					} else {
						// cse4589_print_and_log("select successfull\n");
						for(soc_ind=0; soc_ind<=head_soc; soc_ind+=1){
							if(FD_ISSET(soc_ind, &watch_list)){
								// It it is a new command
								if (soc_ind == STDIN){
									char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
									memset(cmd, '\0', CMD_SIZE);
									if(fgets(cmd, CMD_SIZE-1, stdin) == NULL) {
										exit(-1);
									} else {
										char *command = strtok(cmd, "\n");
										int inc = 0;
										char *arg = strtok(command, " ");
										char *cmds[3];
										while(arg) {
											cmds[inc] = arg;
											inc++;
											arg = strtok(NULL, " ");
										}
										if(strcmp(cmds[0],"AUTHOR") == 0) {
											author(cmds);
										} else if (strcmp(cmds[0],"IP") == 0) {
											ip(cmds);
										} else if (strcmp(cmds[0],"PORT") == 0) {
											getPort(cmds);
										} else if (strcmp(cmds[0],"LIST") == 0) {
											list(cmds);
										} else if(strcmp(cmds[0],"STATISTICS") == 0) {
											displayStatistics(cmds[0]);
										} else if(strcmp(cmds[0],"BLOCKED") == 0) {
											displayBlocked(cmds[0],cmds[1]);
										}
									}
									// free(cmd);
								// If it is a new connection
								} else if(soc_ind == sd) {
									// cse4589_print_and_log("New connection\n");
									int caddr_len =  sizeof(cli_addr);
									ld = accept(sd, (struct sockaddr *)&cli_addr, &caddr_len);
									if(ld < 0) {
										cse4589_print_and_log("Accept failed\n");
									} else {
										// cse4589_print_and_log("Accepted\n");
										char ip[64];
										char host_name[100];
										inet_ntop(AF_INET,&cli_addr.sin_addr,ip,sizeof(ip));
										unsigned int c_port = ntohs(cli_addr.sin_port);
										host = gethostbyaddr((const char *)&cli_addr.sin_addr,sizeof(cli_addr.sin_addr),AF_INET);
										strcpy(host_name,host->h_name);
										// printf("Socket: %d\n",ld);
										insertClient(&head,c_port,ld,host_name,ip);
										FD_SET(ld, &master_list);
										if(ld > head_soc) {
											head_soc = ld;
										}
									}
								// If it is an existing connection
								} else {
									// cse4589_print_and_log("Existing client called\n");
									char *len = (char*) malloc(sizeof(char)*BUFFER_SIZE);
									memset(len, '\0', BUFFER_SIZE);
									if(recv(soc_ind, len,3, 0) <= 0){
										// cse4589_print_and_log("Receive failed\n");
										close(soc_ind);
										// deleteClient(soc_ind);
										FD_CLR(soc_ind, &master_list);
									}
									else {
										int l = atoi(len);
										// cse4589_print_and_log("Receiving data\n");
										char *buffer = (char *) malloc(sizeof(char) * BUFFER_SIZE);
										memset(buffer, '\0', BUFFER_SIZE);
										int rec = recv(soc_ind,buffer,l,0);
										char *data = strtok(buffer, " ");
										int i = 0;
										char *msg[2];
										while(data != NULL) {
											msg[i] = data;
											i++;
											data = strtok(NULL, "");
										}
										// cse4589_print_and_log("%s \n",msg[0]);
										if(strcmp(msg[0],"updateport") == 0) {
											// cse4589_print_and_log("Update port called\n");
											updateCientPort(&head,msg[1],soc_ind);
											sendListToClient(soc_ind);
											// sendMessage(soc_ind);
										} else if(strcmp(msg[0],"refreshlist") == 0) {
											// printf("Refresh list called\n");
											sendListToClient(soc_ind);
										} else if(strcmp(msg[0],"message") == 0) {
											checkAndForward(soc_ind,msg[0],msg[1]);
										} else if(strcmp(msg[0],"logout") == 0) {
											// printf("Logout called\n");
											logout(soc_ind);
										} else if(strcmp(msg[0],"login") == 0) {
											login(soc_ind);
										} else if(strcmp(msg[0],"block") == 0) {
											blockIP(soc_ind,msg[1]);
										} else if(strcmp(msg[0],"unblock") == 0) {
											unBlockIP(soc_ind,msg[1]);
										} else if(strcmp(msg[0],"broadcast") == 0) {
											broadcast(soc_ind,msg[0],msg[1]);
										}
									}
									free(len);
								}
							}
						}

					}
				}
			}
		}
	}
}

//Function to create client and manage client commands
void createClient(int port) {
	int head_soc,s_idx, cd, firstLogin = 1;
	fd_set master_list, watch_list;
	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);
	FD_SET(STDIN,&master_list);
	head_soc = STDIN;
	// cse4589_print_and_log("connecting client\n");
	while(TRUE) {
		// cse4589_print_and_log("Trying to select\n\n");
		memcpy(&watch_list,&master_list,sizeof(master_list));
		if(select(head_soc+1,&watch_list,NULL,NULL,NULL) < 0) {
			cse4589_print_and_log("Select failed\n");
		} else {
			// cse4589_print_and_log("Select Success\n");
			for(s_idx = 0;s_idx <= head_soc;s_idx++) {
				if(FD_ISSET(s_idx,&watch_list)) {
					if(s_idx == STDIN) {
						char *cmd = (char*) malloc(sizeof(char)*CMD_SIZE);
						memset(cmd, '\0', CMD_SIZE);
						char *ccmd = (char*) malloc(sizeof(char)*CMD_SIZE);
						fgets(cmd,CMD_SIZE-1,stdin);
						char *command = strtok(cmd, "\n");
						strcpy(ccmd,command);
						int inc = 0;
						char *arg = strtok(command, " ");
						char *cmds[2];
						while(arg) {
							cmds[inc] = arg;
							inc++;
							arg = strtok(NULL, "");
						}
						// printf("command: %s\n",cmds[0]);
						if(strcmp(cmds[0],"AUTHOR") == 0) {
							author(cmds);
						} else if(strcmp(cmds[0],"EXIT") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "logout";
							char lb[4];
							int l = strlen(ncmd) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							if(send(cd,msg,l,0) >= 0) {
								isLoggedIn = 0;
								// cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								// cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								// cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								// cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
							FD_CLR(s_idx,&master_list);
							cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
							cse4589_print_and_log("[%s:END]\n",cmds[0]);
							close(cd);
							exit(0);
						} else if(strcmp(cmds[0],"IP") == 0) {
							ip(cmds);
						} else if (strcmp(cmds[0],"PORT") == 0) {
							getPort(cmds);
						} else if (isLoggedIn && strcmp(cmds[0],"LIST") == 0) {
							list(cmds);
						} else if(isLoggedIn == 0 && strcmp(cmds[0],"LOGIN") == 0) {
							if(firstLogin) {
								cd = socket(AF_INET, SOCK_STREAM,0);
								if(cd < 0) {
									cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
									cse4589_print_and_log("[%s:END]\n",cmds[0]);
								} else {
									getIPAddr();
									// printf("My ip: %s\n",myip);
									struct sockaddr_in serv_addr;
									char *ip = strtok(cmds[1], " ");
									char *p = strtok(NULL, "");
									bzero(&serv_addr,sizeof(serv_addr));
									serv_addr.sin_family = AF_INET;
									inet_pton(AF_INET, ip,&serv_addr.sin_addr);
									serv_addr.sin_port = htons(atoi(p));
									char cip[64];
									strcpy(cip,ip);
									if(validate_ip(&cip)) {
										if(connect(cd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) {
											cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
											cse4589_print_and_log("[%s:END]\n",cmds[0]);
										} else {
											fcntl(cd, F_SETFL, O_NONBLOCK);
											// cse4589_print_and_log("Calling update port\n");
											char msg[MAX_BUFFER_SIZE];
											char *ncmd = "updateport";
											char lb[4];
											int l = strlen(ncmd) + strlen(cport) + 5;
											sprintf(lb,"%-3d",l);
											strcpy(msg,lb);
											strcat(msg,ncmd);
											strcat(msg," ");
											strcat(msg,cport);
											if(send(cd,msg,strlen(msg),0) == strlen(msg)) {
												isLoggedIn = 1;
												firstLogin = 0;
												cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
												cse4589_print_and_log("[%s:END]\n",cmds[0]);
											} else {
												cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
												cse4589_print_and_log("[%s:END]\n",cmds[0]);
											}
										}
									} else {
										cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
										cse4589_print_and_log("[%s:END]\n",cmds[0]);
									}
								}
								FD_SET(cd,&master_list);
								if(cd > head_soc) {
									head_soc = cd;
								}
							} else {
								char *ip = strtok(cmds[1], " ");
								char *port = strtok(NULL, "");
								if(validate_number(port)) {
									char msg[MAX_BUFFER_SIZE];
									char *ncmd = "login";
									char lb[4];
									int l = strlen(ncmd) + 5;
									sprintf(lb,"%-3d",l);
									strcpy(msg,lb);
									strcat(msg,ncmd);
									if(validate_ip(ip) && send(cd,msg,l,0) >= 0) {
										isLoggedIn = 1;
										cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
										cse4589_print_and_log("[%s:END]\n",cmds[0]);
									} else {
										cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
										cse4589_print_and_log("[%s:END]\n",cmds[0]);
									}
								} else {
									cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
									cse4589_print_and_log("[%s:END]\n",cmds[0]);
								}
							}
						} else if(strcmp(cmds[0],"LOGOUT") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "logout";
							char lb[4];
							int l = strlen(ncmd) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							if(send(cd,msg,l,0) >= 0) {
								isLoggedIn = 0;
								cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								// cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								// cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						} else if(strcmp(cmds[0],"REFRESH") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "refreshlist";
							char lb[4];
							int l = strlen(ncmd) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							if(isLoggedIn == 0 || send(cd,msg,l,0) < 0) {
								cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						} else if(strcmp(cmds[0],"SEND") == 0) {
							// printf("Message to be sent: %s\n",ccmd);
							if(isLoggedIn) {
								sendMessage(ccmd,cd);
							} else {
								cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						} else if(isLoggedIn && strcmp(cmds[0],"BLOCK") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "block";
							char lb[4];
							int l = strlen(ncmd) + strlen(cmds[1]) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							strcat(msg, " ");
							strcat(msg,cmds[1]);
							char ip1[64];
							strcpy(ip1,cmds[1]);
							if(checkIP(cmds[1]) == -1 || validate_ip(&ip1) != 1 || check_block(myip,cmds[1]) == 0 || send(cd,msg,l,0) < 0) {
								cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								block(myip,cmds[1]);
								cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						} else if(isLoggedIn && strcmp(cmds[0],"UNBLOCK") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "unblock";
							char lb[4];
							int l = strlen(ncmd) + strlen(cmds[1]) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							strcat(msg, " ");
							strcat(msg,cmds[1]);
							char ip1[64];
							strcpy(ip1,cmds[1]);
							if(checkIP(cmds[1]) == -1 || validate_ip(&ip1) != 1 || check_block(myip,cmds[1]) || send(cd,msg,l,0) < 0) {
								cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								unBlock(myip,cmds[1]);
								cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						} else if(isLoggedIn && strcmp(cmds[0],"BROADCAST") == 0) {
							char msg[MAX_BUFFER_SIZE];
							char *ncmd = "broadcast";
							char lb[4];
							int l = strlen(ncmd) + strlen(cmds[1]) + 5;
							sprintf(lb,"%-3d",l);
							strcpy(msg,lb);
							strcat(msg,ncmd);
							strcat(msg, " ");
							strcat(msg,cmds[1]);
							if(send(cd,msg,l,0) < 0) {
								cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							} else {
								cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
								cse4589_print_and_log("[%s:END]\n",cmds[0]);
							}
						}
						// free(cmd);
					} else {
						// printf("update for client\n");
						char *len = (char*) malloc(sizeof(char)*BUFFER_SIZE);
						memset(len, '\0', BUFFER_SIZE);
						if(recv(s_idx, len,3, 0) <= 0){
							close(s_idx);
							// deleteClient(s_idx);
							FD_CLR(s_idx, &master_list);
						}
						else {
							int l = atoi(len);
							// printf("reading data: %d\n",l);
							char *buffer = (char *) malloc(sizeof(char)*MAX_BUFFER_SIZE);
							memset(buffer, '\0', MAX_BUFFER_SIZE);
							int rec = receiveAllData(s_idx,buffer,l);
							// printf("Received: %d\n",rec);
							// printf("Data received: %s\n",buffer);
							char *data = strtok(buffer, " ");
							int i = 0;
							char *msg[2];
							while(data != NULL) {
								msg[i] = data;
								i++;
								data = strtok(NULL, "");
							}
							// printf("command: %s\n",msg[0]);
							if(strcmp(msg[0],"updateclients") == 0) {
								// cse4589_print_and_log("%s\n",msg[1]);
								data = strtok(msg[1], " ");
								int i = 0;
								char *clientdata[3];
								if(head != NULL) {
									free(head);
									head = NULL;
								}
								while(data != NULL) {
									if(i==-1) {
										insertClient(&head,atoi(data),0,clientdata[0],clientdata[1]);
										i = 0;
									} else {
										clientdata[i++] = data;
									}
									if(i!=2) {
										data = strtok(NULL, " ");
									} else {
										data = strtok(NULL, ";");
										i = -1;
									}
								}
							} else if(strcmp(msg[0],"receivemessage") == 0) {
								char *ip = strtok(msg[1], " ");
								char *m = strtok(NULL, "");
								cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
								cse4589_print_and_log("msg from:%s\n[msg]:%s\n",ip,m);
								cse4589_print_and_log("[RECEIVED:END]\n");
							} else if(strcmp(msg[0],"bufferedmsgs") == 0) {
								char *ip = strtok(msg[1], " ");
								char *m = strtok(NULL, ";");
								while(m != NULL) {
									cse4589_print_and_log("[RECEIVED:SUCCESS]\n");
									cse4589_print_and_log("msg from:%s\n[msg]:%s\n",ip,m);
									cse4589_print_and_log("[RECEIVED:END]\n");
									ip = strtok(NULL, " ");
									m = strtok(NULL, ";");
								}
							}
						}
						free(len);
					}
				}
			}
		}
	}
}

//Function to insert client into the structure
void insertClient(struct clients **head, int port, int socket, char host[], char ip[]) {
	struct clients * client = (struct clients*)malloc(sizeof(struct clients));
	client->port = port;
	strcpy(client->ip,ip);
	strcpy(client->host,host);
	client->socket = socket;
	client->msg_sent = 0;
	client->msg_received = 0;
	client->status = 1;
	client->next = NULL;
	if(*head == NULL) {
		*head = client;
		return;
	}
	struct clients *clt = *head;
	while(clt->next != NULL) {
		clt = clt->next;
	}
	clt->next = client;
	// sort();
}

// void deleteClient(int socket) {
// 	struct clients *clt = head;
// 	struct clients *prev = NULL;
// 	while(clt != NULL && clt->socket != socket) {
// 		prev = clt;
// 		clt = clt->next;
// 	}
// 	if(clt != NULL) {
// 		prev->next = clt->next;
// 	}
// 	return;
// }

//Function to print author
void author(char *cmds[]) {
	char ubit[9] = "bandarup";
	cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
	cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n",ubit);
	cse4589_print_and_log("[%s:END]\n",cmds[0]);
}

//Function to print the IP of client/server
void ip(char *cmds[]) {
	int soc;
	soc = socket(AF_INET, SOCK_DGRAM, 0);
	if(soc < 0) {
		cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
	} else {
		struct sockaddr_in fb_serv_addr;
		fb_serv_addr.sin_family = AF_INET;
		inet_pton(AF_INET, "8.8.8.8", &(fb_serv_addr.sin_addr));
		fb_serv_addr.sin_port = htons(53);
		if(connect(soc, (struct sockaddr *)&fb_serv_addr,sizeof(fb_serv_addr)) < 0) {
			cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
			cse4589_print_and_log("[%s:END]\n",cmds[0]);
		} else {
			struct sockaddr_in addr;
			int socaddr_len = sizeof(struct sockaddr);
			if(getsockname(soc,(struct sockaddr *)&addr, &socaddr_len) < 0) {
				cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
				cse4589_print_and_log("[%s:END]\n",cmds[0]);
			} else {
				char ipaddr[INET_ADDRSTRLEN];
				inet_ntop(AF_INET,&addr.sin_addr,ipaddr,INET6_ADDRSTRLEN);
				cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
				cse4589_print_and_log("IP:%s\n",ipaddr);
				cse4589_print_and_log("[%s:END]\n",cmds[0]);
			}
		}
	}
}

//Function to get the IP of current client
void getIPAddr() {
	int soc;
	soc = socket(AF_INET, SOCK_DGRAM, 0);
	if(soc < 0) {
		// cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
	} else {
		struct sockaddr_in fb_serv_addr;
		fb_serv_addr.sin_family = AF_INET;
		inet_pton(AF_INET, "8.8.8.8", &(fb_serv_addr.sin_addr));
		fb_serv_addr.sin_port = htons(53);
		if(connect(soc, (struct sockaddr *)&fb_serv_addr,sizeof(fb_serv_addr)) < 0) {
			// cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
			// cse4589_print_and_log("[%s:END]\n",cmds[0]);
		} else {
			struct sockaddr_in addr;
			int socaddr_len = sizeof(struct sockaddr);
			if(getsockname(soc,(struct sockaddr *)&addr, &socaddr_len) < 0) {
				// cse4589_print_and_log("[%s:ERROR]\n",cmds[0]);
				// cse4589_print_and_log("[%s:END]\n",cmds[0]);
			} else {
				char ipaddr[INET_ADDRSTRLEN];
				inet_ntop(AF_INET,&addr.sin_addr,ipaddr,INET6_ADDRSTRLEN);
				strcpy(myip,ipaddr);
				// cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
				// cse4589_print_and_log("IP:%s\n",ipaddr);
				// cse4589_print_and_log("[%s:END]\n",cmds[0]);
			}
		}
	}
}

//Function to print the port of current client/server
void getPort(char *cmds[]) {
	cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
	cse4589_print_and_log("PORT:%d\n",port);
	cse4589_print_and_log("[%s:END]\n",cmds[0]);
}

//function to print the list of currently logged in clients
void list(char *cmds[]) {
	sort();
	cse4589_print_and_log("[%s:SUCCESS]\n",cmds[0]);
	struct clients *temp = head;
	int i = 1;
	while(temp != NULL) {
		cse4589_print_and_log("%-5d%-35s%-20s%-8d\n", i++, temp->host, temp->ip, temp->port);
		temp = temp->next;
	}
	cse4589_print_and_log("[%s:END]\n",cmds[0]);
}

// function to update the port of a client in server.
void updateCientPort(struct clients **head, char *port, int socket) {
	struct clients *temp = *head;
	int p = atoi(port);
	// printf("port@@: %d",p);
	while(temp != NULL) {
		if(temp->socket == socket) {
			temp->port = p;
			break;
		}
		temp = temp->next;
	}
}

void sendToAllClietns(struct clients **head,int socket, char *msg, int length) {

}

//function to sort the list of clients
void sort() {
	struct clients *temp = head;
	while(temp->next != NULL) {
		struct clients *temp2 = temp->next;
		while(temp2 != NULL) {
			if(temp->port > temp2->port) {
				struct clients *copy = (struct clients*)malloc(sizeof(struct clients));
				struct clients *n1,*n2;
				n1 = temp->next;
				n2 = temp2->next;
				*copy = *temp2;
				*temp2 = *temp;
				*temp = *copy;
				temp->next = n1;
				temp2->next = n2;
			}
			temp2 = temp2->next;
		}
		temp = temp->next;
	}
}

//function to send the list of clients to a specific client
void sendListToClient(int socket) {
	// printf("initiate send list to client\n");
	char *buffer = (char *)malloc(sizeof(char)*MAX_BUFFER_SIZE);
	struct clients *temp = head;
	int n = 0;
	while(temp != NULL) {
		if(n==0) {
			strcpy(buffer,temp->host);
		} else {
			strcat(buffer,temp->host);
		}
		strcat(buffer, " ");
		strcat(buffer,temp->ip);
		strcat(buffer, " ");
		// printf("port: %d",temp->port);
		char p[5];
		sprintf(p,"%d",temp->port);
		strcat(buffer,p);
		strcat(buffer, ";");
		temp = temp->next;
		n++;
	}
	// cse4589_print_and_log("sending client list by calling updateclients\n");
	char *msg = (char *) malloc(sizeof(char)*MAX_BUFFER_SIZE);
	char *ncmd = "updateclients";
	char lb[4];
	int l = strlen(ncmd) + strlen(buffer) + 5;
	sprintf(lb,"%-3d",l);
	strcpy(msg,lb);
	strcat(msg,ncmd);
	strcat(msg, " ");
	strcat(msg,buffer);
	// cse4589_print_and_log("Message to be sent: %s\n",msg);
	if(sendAllData(socket,msg,l) < 0) {
		cse4589_print_and_log("Failed to send client list\n");
	} else {
		// cse4589_print_and_log("Data sent\n");
	}
}

//function to send data to a client/server
int sendAllData(int socket, char *msg,int l) {
	int start = 0;
	while(start < l) {
		int sent = send(socket,msg+start,l-start,0);
		if(sent < 0) {
			return -1;
		}
		// printf("message sent\n");
		start += sent;
	}
	return 1;
}

//function to receive data from a client/server
int receiveAllData(int socket, char *msg,int l) {
	int start = 0;
	while(start < l) {
		int sent = recv(socket,msg+start,l-start,0);
		if(sent < 0) {
			return -1;
		}
		start += sent;
	}
	// printf("Total data received: %s\n",msg);
	return 1;
}

//function to send message from one client to other client
void sendMessage(char *cmds,int socket) {
	char *cmd = strtok(cmds, " ");
	char *ip = strtok(NULL, " ");
	char *message = strtok(NULL, "");
	char ip1[64];
	strcpy(ip1,ip);
	if(checkIP(ip) != -1 && validate_ip(&ip1)) {
		// printf("CMD: %s, IP: %s, message: %s\n",cmd,ip,message);
		char *ncmd = "message";
		char lb[4];
		int l = strlen(ncmd) + strlen(ip) + strlen(message) + 5;
		// printf("length: %d\n",l);
		sprintf(lb,"%-3d",l);
		char *msg = (char *) malloc(sizeof(char)*MAX_BUFFER_SIZE);
		strcpy(msg,lb);
		strcat(msg,ncmd);
		strcat(msg," ");
		strcat(msg,ip);
		strcat(msg," ");
		strcat(msg,message);
		// printf("Message to be sent: %s\n",msg);
		if(sendAllData(socket,msg,l) < 0) {
			cse4589_print_and_log("[%s:ERROR]\n",cmd);
			cse4589_print_and_log("[%s:END]\n",cmd);
		} else {
			cse4589_print_and_log("[%s:SUCCESS]\n",cmd);
			cse4589_print_and_log("[%s:END]\n",cmd);
		}
	} else {
		cse4589_print_and_log("[%s:ERROR]\n",cmd);
		cse4589_print_and_log("[%s:END]\n",cmd);
	}
}

//function to send message received to server from a client to another client
void checkAndForward(int sender_soc,char *cmd,char *msg) {
	// struct clients *temp = head;
	// printf("sender socket: %d\n",sender_soc);
	// int i = 1;
	// while(temp != NULL) {
	// 	cse4589_print_and_log("%-5d%-35s%-20s%-8d %d\n", i++, temp->host, temp->ip, temp->port,temp->socket);
	// 	temp = temp->next;
	// }
	// printf("sending message\n");
	// printf("check command: %s\n",cmd);
	char sip[64];
	getIP(&sip,sender_soc);
	char *ip = strtok(msg," ");
	char *message = strtok(NULL, "");
	int soc = checkIP(ip);
	if(check_block(ip,sip)) {
		if(checkLogin(ip)) {
			// printf("Sending message\n");
			char *msg1 = (char *) malloc(sizeof(char)*MAX_BUFFER_SIZE);
			char *ncmd = "receivemessage";
			char lb[4];
			int l = strlen(ncmd) + strlen(ip) + strlen(message) + 5;
			sprintf(lb,"%-3d",l);
			strcpy(msg1,lb);
			strcat(msg1,ncmd);
			strcat(msg1," ");
			strcat(msg1,sip);
			strcat(msg1," ");
			strcat(msg1,message);
			if(sendAllData(soc,msg1,l) < 0) {
				cse4589_print_and_log("[RELAYED:ERROR]\n");
				cse4589_print_and_log("[RELAYED:END]\n",cmd);
			} else {
				cse4589_print_and_log("[RELAYED:SUCCESS]\n");
				if(strcmp(cmd,"broadcast") != 0) {
					cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sip, ip, message);
				} else {
					cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n", sip, message);
				}
				cse4589_print_and_log("[RELAYED:END]\n");
				updateMessageCount(sender_soc,soc,1);
			}
		} else {
			cse4589_print_and_log("[RELAYED:SUCCESS]\n");
			// cse4589_print_and_log("msg from:%s, to:%s\n",sip,ip);
			// cse4589_print_and_log("[msg]:%s",message);
			if(strcmp(cmd,"broadcast") != 0) {
				cse4589_print_and_log("msg from:%s, to:%s\n[msg]:%s\n", sip, ip, message);
			} else {
				cse4589_print_and_log("msg from:%s, to:255.255.255.255\n[msg]:%s\n", sip, message);
			}
			cse4589_print_and_log("[RELAYED:END]\n");
			saveMessageToBuffer(sender_soc,soc,message);
			// updateMessageCount(sender_soc,soc,0);
		}
	}
}

//function to send broadcast message
void broadcast(int soc, char *cmd, char *msg) {
	// printf("command: %s, message: %s\n",cmd,msg);
	struct clients *clt = head;
	while(clt != NULL) {
		if(clt->socket != soc) {
			// printf("Socket: %d\n",clt->socket);
			char sip[64];
			getIP(&sip,clt->socket);
			char *message = (char *) malloc(sizeof(char)*MAX_BUFFER_SIZE);
			strcpy(message,sip);
			strcat(message, " ");
			strcat(message,msg);
			// printf("Message: %s\n",message);
			checkAndForward(soc,cmd,message);
		}
		clt = clt->next;
	}
}

//fucntion to check whether a client is logged in or not
int checkLogin(char *ip) {
	struct clients *clt = head;
	while(clt != NULL) {
		if(strcmp(clt->ip,ip) == 0) {
			return clt->status;
		}
		clt = clt->next;
	}
	return 0;
}

//function to check the ip in local copy of a client
int checkIP(char *ip) {
	// printf("CHecking ip\n");
	struct clients *temp = head;
	while(temp!=NULL) {
		// printf("IP: %s, port: %d, socket: %d\n",temp->ip,temp->port,temp->socket);
		if(strcmp(ip,temp->ip) == 0) {
			return temp->socket;
		}
		temp = temp->next;
	}
	return -1;
}

//function to update logout status of a client in server
void logout(int socket) {
	struct clients *temp = head;
	while(temp!=NULL) {
		if(socket == temp->socket) {
			temp->status = 0;
			// printf("CLient logged out\n");
			break;
		}
		temp = temp->next;
	}
}

//function to update login status of a client in server
void login(int socket) {
	struct clients *temp = head;
	while(temp!=NULL) {
		if(socket == temp->socket) {
			temp->status = 1;
			// printf("CLient logged in\n");
			break;
		}
		temp = temp->next;
	}
	sendBufferedMessages(temp->socket);
}

//function to block a client
void blockIP(int soc,char *ip) {
	char sip[64];
	getIP(sip,soc);
	if(check_block(sip,sip)) {
		struct block_list *bl = (struct block_list *)malloc(sizeof(struct block_list));
		strcpy(bl->sender_ip,sip);
		strcpy(bl->receiver_ip,ip);
		bl->next = NULL;
		if(bl_head == NULL) {
			bl_head = bl;
		} else {
			bl->next = bl_head;
			bl_head = bl;
		}
	}
}

//fucntion to update block in client side
void block(char *sip, char *rip) {
	struct block_list *bl = (struct block_list *)malloc(sizeof(struct block_list));
	strcpy(bl->sender_ip,sip);
	strcpy(bl->receiver_ip,rip);
	bl->next = NULL;
	if(bl_head == NULL) {
		bl_head = bl;
	} else {
		bl->next = bl_head;
		bl_head = bl;
	}
}

//function to unblock a client
void unBlockIP(int soc,char *ip) {
	char sip[64];
	getIP(sip,soc);
	// if(check_block(sip,sip)) {
		struct block_list *bl = bl_head;
		if(bl != NULL) {
			if(strcmp(bl->sender_ip,sip) == 0 && strcmp(bl->receiver_ip,ip) == 0) {
				bl_head = bl_head->next;
				return;
			}
			struct block_list *prev = bl;
			bl = bl->next;
			while(bl != NULL) {
				if(strcmp(bl->sender_ip,sip) == 0 && strcmp(bl->receiver_ip,ip) == 0) {
					prev->next = bl->next;
					return;
				}
				prev = bl;
				bl = bl->next;
			}
		}
	// }
}

//function to update unblock in client side
void unBlock(char *sip, char *rip) {
	struct block_list *bl = bl_head;
	if(bl != NULL) {
		if(strcmp(bl->sender_ip,sip) == 0 && strcmp(bl->receiver_ip,rip) == 0) {
			bl_head = bl_head->next;
			return;
		}
		struct block_list *prev = bl;
		bl = bl->next;
		while(bl != NULL) {
			if(strcmp(bl->sender_ip,sip) == 0 && strcmp(bl->receiver_ip,rip) == 0) {
				prev->next = bl->next;
				return;
			}
			prev = bl;
			bl = bl->next;
		}
	}
}

//function to check the block status of a client
int check_block(char *sip, char *rip) {
	struct block_list *bl = bl_head;
	while(bl != NULL) {
		if(strcmp(bl->sender_ip,sip) == 0 && strcmp(bl->receiver_ip,rip) == 0) {
			return 0;
		}
		bl = bl->next;
	}
	return 1;
}

//function to save message to buffer if client is logged out
void saveMessageToBuffer(int from,int to, char *message) {
	struct message_buffer *buff = buff_head;
	struct message_buffer *b = (struct message_buffer *)malloc(sizeof(struct message_buffer));
	b->from = from;
	b->to = to;
	strcpy(b->message,message);
	b->next = NULL;
	if(buff_head == NULL) {
		buff_head = b;
		return;
	}
	while(buff->next != NULL) {
		buff = buff->next;
	}
	buff->next = b;
	// printf("Message saved to buffer\n");
}

//function to send buffered messages to client after relogin
void sendBufferedMessages(int r) {
	char *msg = (char *)malloc(sizeof(char) * BUFF_MSG_SIZE);
	struct message_buffer *buff = buff_head;
	int i = 0;
	while(buff != NULL) {
		if(buff->to == r) {
			// updateMessageCount(-1,r,2);
			char rip[64];
			getIP(&rip,buff->from);
			if(i == 0) {
				strcpy(msg,rip);
				i = 1;
			} else {
				strcat(msg,rip);
			}
			strcat(msg," ");
			strcat(msg,buff->message);
			strcat(msg,";");
		}
		buff = buff->next;
	}
	// printf("Message created\n");
	char *ncmd = "bufferedmsgs";
	int l = strlen(ncmd) + strlen(msg) + 5;
	char *message = (char *)malloc(sizeof(char) * BUFF_MSG_SIZE);
	char lb[4];
	sprintf(lb,"%-3d",l);
	strcpy(message,lb);
	strcat(message,ncmd);
	strcat(message," ");
	strcat(message, msg);
	if(sendAllData(r,message,l) < 0) {
		printf("Sending buffered messages failed\n");
	} else {
		deleteBufferedMessages(r);
		// printf("buffered messages sent\n");
	}
	free(msg);
	free(message);
}

//function to get ip of a client based on socket number
void getIP(char *ip,int socket) {
	// printf("getting ip for socket: %d",socket);
	struct clients *temp = head;
	while(temp!=NULL) {
		if(socket == temp->socket) {
			strcpy(ip,temp->ip);
			// printf("IP: %s",ip);
			return;
		}
		temp = temp->next;
	}
}

//fucntion to delete buffered messages after sent to client
void deleteBufferedMessages(int r) {
	struct message_buffer *buff = buff_head;
	struct message_buffer *prev;
	while(buff != NULL && buff->to == r) {
		buff_head = buff_head->next;
		buff = buff->next;
	}
	prev = buff;
	if(buff != NULL) {
		buff = buff->next;
	}
	while(buff != NULL) {
		if(buff->to == r) {
			prev->next = buff->next;
		}
		buff = buff->next;
	}
}

//fucntion to display statsitics
void displayStatistics(char *cmd) {
	struct clients *temp = head;
	int i = 1;
	char *status = (char *)malloc(sizeof(char)*15);
	cse4589_print_and_log("[%s:SUCCESS]\n",cmd);
	while(temp!=NULL) {
		if(temp->status) {
			status = "logged-in";
		} else {
			status = "logged-out";
		}
		cse4589_print_and_log("%-5d%-35s%-8d%-8d%-8s\n",i++,temp->host,temp->msg_sent,temp->msg_received,status);
		temp = temp->next;
	}
	cse4589_print_and_log("[%s:END]\n",cmd);
}

//function to display blocked list of a client
void displayBlocked(char *cmd, char *ip) {
	char vip[64];
	strcpy(vip,ip);
	if(validate_ip(&vip) && checkIP(ip) != -1) {
		cse4589_print_and_log("[%s:SUCCESS]\n",cmd);
		struct block_list *bl = bl_head;
		int i = 1;
		while(bl != NULL) {
			if(strcmp(bl->sender_ip,ip) == 0) {
				struct clients *cl = head;
				while(cl != NULL) {
					if(strcmp(cl->ip,bl->receiver_ip) == 0) {
						break;
					}
					cl = cl->next;
				}
				if(cl != NULL) {
					cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",i++,cl->host,cl->ip,cl->port);
				}
			}
			bl = bl->next;
		}
		cse4589_print_and_log("[%s:END]\n",cmd);
	} else {
		cse4589_print_and_log("[%s:ERROR]\n",cmd);
		cse4589_print_and_log("[%s:END]\n",cmd);
	}
}

//fucntion to update message count
void updateMessageCount(int ssoc, int rsoc, int c) {
	// printf("update message count\n");
	struct clients *temp = head;
	while(temp!=NULL) {
		if(c == 1) {
			if(temp->socket == ssoc) {
				temp->msg_sent++;
			}
			if(temp->socket == rsoc) {
				temp->msg_received++;
			}
		} else if(c == 0){
			if(temp->socket == ssoc) {
				temp->msg_sent++;
			}
		} else {
			if(temp->socket == rsoc) {
				temp->msg_received++;
			}
		}
		temp = temp->next;
	}
}

//fucntion to vaidate port number or number in ip
int validate_number(char *str) {
   while (*str) {
      if(!isdigit(*str)){ //if the character is not a number, return false
         return 0;
      }
      str++; //point to next character
   }
   return 1;
}

//fucntion to validate ip 
int validate_ip(char *ip) { //check whether the IP is valid or not
   int i, num, dots = 0;
   char *ptr;
   if (ip == NULL)
      return 0;
      ptr = strtok(ip, "."); //cut the string using dor delimiter
      if (ptr == NULL)
         return 0;
   while (ptr) {
      if (!validate_number(ptr)) //check whether the sub string is holding only number or not
         return 0;
         num = atoi(ptr); //convert substring to number
         if (num >= 0 && num <= 255) {
            ptr = strtok(NULL, "."); //cut the next part of the string
            if (ptr != NULL)
               dots++; //increase the dot count
         } else
            return 0;
    }
    if (dots != 3) //if the number of dots are not 3, return false
       return 0;
      return 1;
}